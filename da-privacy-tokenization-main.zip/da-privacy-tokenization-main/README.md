# da-privacy-tokenization
A repository that supports how Chamberlain Group tokenizes user and device identifiers at the lakehouse edge, severs the links between real identities and tokenized data on demand (delete-me / DSAR — Data Subject Access Request), and retains anonymized analytical data.
