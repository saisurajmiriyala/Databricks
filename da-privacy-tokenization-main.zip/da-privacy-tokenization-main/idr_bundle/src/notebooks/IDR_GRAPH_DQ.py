# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# Connect to the identity database and start tracking this run.
import pandas as pd
from lakebase_utils.postgres.connection import ptk_connect, fetch_lakebase_credentials
from lakebase_utils.postgres.queryhub import ptk_execute
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint

start_global_notebook_logger()

ptk_connect(**fetch_lakebase_credentials())
spark.conf.set("spark.sql.session.timeZone", "UTC")

# Where the DQ results land: the audit-log catalog, not the raw layer. These two tables
# are an audit trail (append-only, one row per rule violation and per run count), so they
# belong with the run logs rather than among analytical data. The IDR data quality
# dashboard reads them from the same place, off the same bundle variable.
dbutils.widgets.text("AUDIT_CATALOG", "", "Catalog holding the audit trail")
AUDIT_CATALOG = dbutils.widgets.get("AUDIT_CATALOG").strip()
assert AUDIT_CATALOG, "AUDIT_CATALOG is required: the job passes it as a parameter."

DQ_SCHEMA = f"{AUDIT_CATALOG}.privacy"

# The schema is not created by the bundle, so create it here rather than fail on the
# first CREATE TABLE in a fresh environment.
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {DQ_SCHEMA}")

# Define identity tables to be evaluated in the DQ checks and counted in totals.
TABLES = [
    'account_identity',
    'user_identity',
    'account_identifier',
    'user_identifier',
    'user_account_membership',
    'user_account_membership_history',
]
log_checkpoint("Table names defined")

# Build comprehensive SQL for all DQ rule violations across identity tables.
dq_rules_sql = """
SELECT
    'RULE_1' AS rule_id,
    'deleted_at must be set when tombstoned/purged' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identity' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    concat('deletion_status=', deletion_status, ' but deleted_at is NULL') AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identity
WHERE deletion_status IN ('tombstoned', 'purged') AND deleted_at IS NULL

UNION ALL

SELECT
    'RULE_1' AS rule_id,
    'deleted_at must be set when tombstoned/purged' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identity' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    concat('deletion_status=', deletion_status, ' but deleted_at is NULL') AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identity
WHERE deletion_status IN ('tombstoned', 'purged') AND deleted_at IS NULL

UNION ALL

SELECT
    'RULE_1' AS rule_id,
    'deleted_at must be set when tombstoned/purged' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identifier' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    concat('deletion_status=', deletion_status, ' but deleted_at is NULL') AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identifier
WHERE deletion_status IN ('tombstoned', 'purged') AND deleted_at IS NULL

UNION ALL

SELECT
    'RULE_1' AS rule_id,
    'deleted_at must be set when tombstoned/purged' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identifier' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    concat('deletion_status=', deletion_status, ' but deleted_at is NULL') AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identifier
WHERE deletion_status IN ('tombstoned', 'purged') AND deleted_at IS NULL

UNION ALL

SELECT
    'RULE_2' AS rule_id,
    'deletion_reason must be set when purged' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identity' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    'deletion_status=purged but deletion_reason is NULL' AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identity
WHERE deletion_status = 'purged' AND deletion_reason IS NULL

UNION ALL

SELECT
    'RULE_2' AS rule_id,
    'deletion_reason must be set when purged' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identity' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    'deletion_status=purged but deletion_reason is NULL' AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identity
WHERE deletion_status = 'purged' AND deletion_reason IS NULL

UNION ALL

SELECT
    'RULE_2' AS rule_id,
    'deletion_reason must be set when purged' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identifier' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    'deletion_status=purged but deletion_reason is NULL' AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identifier
WHERE deletion_status = 'purged' AND deletion_reason IS NULL

UNION ALL

SELECT
    'RULE_2' AS rule_id,
    'deletion_reason must be set when purged' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identifier' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    'deletion_status=purged but deletion_reason is NULL' AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identifier
WHERE deletion_status = 'purged' AND deletion_reason IS NULL

UNION ALL

SELECT
    'RULE_3' AS rule_id,
    'identifier_type outside accepted domain' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identifier' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    concat('identifier_type=''', identifier_type, ''' not in accepted domain') AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identifier
WHERE identifier_type NOT IN ('account_id')

UNION ALL

SELECT
    'RULE_3' AS rule_id,
    'identifier_type outside accepted domain' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identifier' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    concat('identifier_type=''', identifier_type, ''' not in accepted domain') AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identifier
WHERE identifier_type NOT IN ('email', 'external_user_id', 'myq_user_id', 'phone')

UNION ALL

SELECT
    'RULE_4' AS rule_id,
    'deleted_at must be within valid range' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identity' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    concat('deleted_at=', deleted_at::text, ' created_at=', created_at::text) AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identity
WHERE deleted_at IS NOT NULL
  AND (deleted_at <= created_at OR deleted_at > CURRENT_TIMESTAMP)

UNION ALL

SELECT
    'RULE_4' AS rule_id,
    'deleted_at must be within valid range' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identity' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    concat('deleted_at=', deleted_at::text, ' created_at=', created_at::text) AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identity
WHERE deleted_at IS NOT NULL
  AND (deleted_at <= created_at OR deleted_at > CURRENT_TIMESTAMP)

UNION ALL

SELECT
    'RULE_4' AS rule_id,
    'deleted_at must be within valid range' AS rule_description,
    'cg_identity' AS schema_name,
    'account_identifier' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    NULL::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    concat('deleted_at=', deleted_at::text, ' created_at=', created_at::text) AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.account_identifier
WHERE deleted_at IS NOT NULL
  AND (deleted_at <= created_at OR deleted_at > CURRENT_TIMESTAMP)

UNION ALL

SELECT
    'RULE_4' AS rule_id,
    'deleted_at must be within valid range' AS rule_description,
    'cg_identity' AS schema_name,
    'user_identifier' AS table_name,
    NULL::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    identifier_type::text AS identifier_type,
    vendor::text AS vendor,
    concat('deleted_at=', deleted_at::text, ' created_at=', created_at::text) AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_identifier
WHERE deleted_at IS NOT NULL
  AND (deleted_at <= created_at OR deleted_at > CURRENT_TIMESTAMP)

UNION ALL

SELECT
    'RULE_5' AS rule_id,
    'valid_to must be within valid range' AS rule_description,
    'cg_identity' AS schema_name,
    'user_account_membership_history' AS table_name,
    canonical_account_id::text AS canonical_account_id,
    canonical_user_id::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    concat('valid_from=', valid_from::text, ' valid_to=', valid_to::text) AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_account_membership_history
WHERE valid_to IS NOT NULL
  AND (valid_to <= valid_from OR valid_to > CURRENT_TIMESTAMP)

UNION ALL

SELECT
    'RULE_6' AS rule_id,
    'status_changed_at does not match open history valid_from' AS rule_description,
    'cg_identity' AS schema_name,
    'user_account_membership' AS table_name,
    m.canonical_account_id::text AS canonical_account_id,
    m.canonical_user_id::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    concat(
        'status_changed_at=', m.status_changed_at::text,
        ' history_valid_from=', h.valid_from::text,
        CASE WHEN h.valid_from IS NULL THEN ' (no open history row found)' ELSE '' END
    ) AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_account_membership m
LEFT JOIN cg_identity.user_account_membership_history h
    ON  h.canonical_user_id = m.canonical_user_id
    AND h.canonical_account_id = m.canonical_account_id
    AND h.valid_to IS NULL
WHERE h.valid_from IS NULL
   OR h.valid_from <> m.status_changed_at

UNION ALL

SELECT
    'RULE_7' AS rule_id,
    'membership pair missing from history table' AS rule_description,
    'cg_identity' AS schema_name,
    'user_account_membership' AS table_name,
    m.canonical_account_id::text AS canonical_account_id,
    m.canonical_user_id::text AS canonical_user_id,
    NULL::text AS identifier_type,
    NULL::text AS vendor,
    'no matching row in user_account_membership_history for this pair' AS detail,
    CURRENT_TIMESTAMP AS checked_at
FROM cg_identity.user_account_membership m
LEFT JOIN cg_identity.user_account_membership_history h
    ON  h.canonical_user_id = m.canonical_user_id
    AND h.canonical_account_id = m.canonical_account_id
WHERE h.canonical_user_id IS NULL
"""
log_checkpoint("DQ Rule logic defined")

# Execute consolidated DQ rules SQL and retrieve violations as pandas DataFrame.
dq_rules_pdf = ptk_execute(dq_rules_sql)

# Create or verify the dq_identity_rules table.
spark.sql(
    f"""
    CREATE TABLE IF NOT EXISTS {DQ_SCHEMA}.dq_identity_rules (
        rule_id STRING,
        rule_description STRING,
        schema_name STRING,
        table_name STRING,
        canonical_account_id STRING,
        canonical_user_id STRING,
        identifier_type STRING,
        vendor STRING,
        detail STRING,
        checked_at TIMESTAMP
    )
    """
)


# Create or verify the dq_table_totals table.
spark.sql(
    f"""
    CREATE TABLE IF NOT EXISTS {DQ_SCHEMA}.dq_table_totals (
        table_name STRING,
        total_records BIGINT,
        checked_at TIMESTAMP
    )
    """
)

# Handle case where ptk_execute returned int (no violations) vs DataFrame.
rules_schema = 'rule_id string, rule_description string, schema_name string, table_name string, canonical_account_id string, canonical_user_id string, identifier_type string, vendor string, detail string, checked_at timestamp'

if dq_rules_pdf.empty:
    # No violations found - create empty DataFrame with correct schema.
    rules_sdf = spark.createDataFrame([], schema=rules_schema)
else:
    # Violations found - select and convert to Spark DataFrame.
    rules_sdf = spark.createDataFrame(dq_rules_pdf, schema=rules_schema)

# Determine run timestamp from violations or use current time if no violations.
run_checked_at = None
if rules_sdf.count() > 0:
    # Extract max checked_at timestamp from violations for run tracking.
    run_checked_at = rules_sdf.agg({'checked_at': 'max'}).collect()[0][0]
else:
    # No violations - use current timestamp for run tracking
    run_checked_at = spark.sql('SELECT current_timestamp() AS ts').collect()[0]['ts']

# Append violations to historical rules table (append mode for immutable audit trail).
rules_count = rules_sdf.count()
if rules_count > 0:
    rules_sdf.write.mode('append').saveAsTable(f'{DQ_SCHEMA}.dq_identity_rules')

# Iterate through each identity table and capture row count for baseline tracking.
totals_rows = []
for table_name in TABLES:
    # Execute count query for current table via PostgreSQL.
    count_pdf = ptk_execute(
        f"SELECT COUNT(*) AS total_records FROM cg_identity.{table_name}"
    )
    # Extract count value and build totals record for this table.
    total_records = int(count_pdf.iloc[0]['total_records'])
    totals_rows.append({
        'table_name': table_name,
        'total_records': total_records,
        'checked_at': run_checked_at,
    })

# Convert list of totals records to pandas DataFrame, then to Spark DataFrame.
totals_pdf = pd.DataFrame(totals_rows)
totals_sdf = spark.createDataFrame(totals_pdf)
log_checkpoint("Dataframe created for Data Quality metrics")

# Append totals to historical table (append mode for immutable baseline tracking).
totals_sdf.write.mode('append').saveAsTable(f'{DQ_SCHEMA}.dq_table_totals')
log_checkpoint("dataframe written into final table")

# Save a log of everything this run did.
# create_notebook_audit_log()
