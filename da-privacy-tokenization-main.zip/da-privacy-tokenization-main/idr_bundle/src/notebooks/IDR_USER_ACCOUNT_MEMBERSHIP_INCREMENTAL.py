# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# Connect to the cg_identity database and start tracking this run.
import os
from lakebase_utils.idr.hmac_util import fetch_secret_scope
from lakebase_utils.idr.resolution import add_hmacs, USER_ANCHOR_TYPE, ACCOUNT_ANCHOR_TYPE
from lakebase_utils.postgres.connection import ptk_connect, fetch_lakebase_credentials
from lakebase_utils.postgres.queryhub import ptk_execute, ptk_write_dataframe
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
from pyspark.sql import functions as F

start_global_notebook_logger()

SECRET_SCOPE = fetch_secret_scope()

ptk_connect(**fetch_lakebase_credentials())
spark.conf.set("spark.sql.session.timeZone", "UTC")

# Legacy catalog holding the source tables, set per environment by the job.
dbutils.widgets.text("LEGACY_CATALOG", "", "Legacy catalog holding the source tables")
LEGACY_CATALOG = dbutils.widgets.get("LEGACY_CATALOG").strip()

# The 30-day account-user extract, in a dev-only volume. Only dev has a value, and that
# is what picks the source: with a path, read the extract; without one, query the real
# dimensions for the same window.
dbutils.widgets.text("IDR_MEMBERSHIP_SOURCE_ROOT", "", "Volume path holding the 30-day extract")
SOURCE_ROOT = dbutils.widgets.get("IDR_MEMBERSHIP_SOURCE_ROOT").strip().rstrip("/")

# Read the account-user source and keep only UUID-valid anchors.
uuid_regex = r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$"
log_checkpoint("source data path and uuid pattern defined")

if SOURCE_ROOT:
    df_account_user = spark.read.parquet(SOURCE_ROOT)
else:
    # The dimensions hold one row per SCD2 version, so joining them whole duplicates
    # every fact row - 1,047,794 rows where only 727,693 are distinct. Each surrogate key
    # maps to exactly one natural key, so taking the distinct pair loses nothing and the
    # fact stays at its own grain.
    df_account_user = spark.sql(f"""
        SELECT
            u.user_id,
            a.account_id,
            au.role_name,
            au.account_user_status,
            au.`__START_AT`,
            au.`__END_AT`,
            au.current_record
        FROM {LEGACY_CATALOG}.gold.dim_accountuser au
        JOIN (SELECT DISTINCT user_sk, user_id       FROM {LEGACY_CATALOG}.gold.dim_user)    u
            ON au.user_sk    = u.user_sk
        JOIN (SELECT DISTINCT account_sk, account_id FROM {LEGACY_CATALOG}.gold.dim_account) a
            ON au.account_sk = a.account_sk
        WHERE au.`__START_AT` >= current_timestamp() - INTERVAL 30 DAYS
           OR au.`__END_AT`   >= current_timestamp() - INTERVAL 30 DAYS
    """)

df_source = df_account_user.filter(
    F.col("user_id").isNotNull()
    & F.col("account_id").isNotNull()
    & F.col("user_id").rlike(uuid_regex)
    & F.col("account_id").rlike(uuid_regex)
)

# Keep only the columns the history table needs (open interval => valid_to is already NULL in source __END_AT).
df_stage = df_source.select(
    "user_id",
    "account_id",
    F.col("role_name"),
    F.col("account_user_status"),
    F.col("__START_AT").alias("valid_from"),
    F.col("__END_AT").alias("valid_to"),
)
log_checkpoint("source dataframe created")
# Compute the anchor HMACs; the cg_identity tables store only HMACs, so the HMAC is the lookup key.
os.environ["IDR_PEPPER_SECRET_SCOPE"] = SECRET_SCOPE
df_hmacs = add_hmacs(
    df_stage,
    [
        ("user_id", USER_ANCHOR_TYPE, "user_hmac"),
        ("account_id", ACCOUNT_ANCHOR_TYPE, "account_hmac"),
    ],
)

# Project to the staging table's columns (HMACs + interval attributes).
df_hmacs_long = df_hmacs.select(
    F.col("user_hmac"),
    F.col("account_hmac"),
    F.col("role_name"),
    F.col("account_user_status"),
    F.col("valid_from"),
    F.col("valid_to"),
)
log_checkpoint("Project to the staging table's columns")
# Refresh the staging table (clear last run) and load this batch.
# TRUNCATE, not DELETE: DELETE never shrinks the relation and every scan pays for it.
ptk_execute("TRUNCATE public.uam_stage")
ptk_write_dataframe(df_hmacs_long, "public.uam_stage")

# The stage is refilled every run, so analyze it or the planner uses the old stats.
ptk_execute("ANALYZE public.uam_stage")

# History: close the previous OPEN interval when the batch brings a newer open interval for the same pair,
# so at most one interval stays open per pair (respects ux_uamh_one_current). Canonicals are resolved in
# Postgres by joining the staged HMACs to the identifier tables (lookup only, no minting).
ptk_execute("""
    UPDATE cg_identity.user_account_membership_history AS h
    SET valid_to = s.new_from
    FROM (
        SELECT
            ui.canonical_user_id,
            ei.canonical_account_id,
            MAX(us.valid_from) AS new_from
        FROM public.uam_stage us
        JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
        JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
        WHERE us.valid_to IS NULL
        GROUP BY ui.canonical_user_id, ei.canonical_account_id
    ) AS s
    WHERE h.canonical_user_id = s.canonical_user_id
      AND h.canonical_account_id = s.canonical_account_id
      AND h.valid_to IS NULL
      AND h.valid_from < s.new_from;
""")

# History: for intervals we already have (same pair + valid_from), apply the source's change to
# valid_to / role_name / account_user_status (e.g. an interval that was open and is now closed at source).
ptk_execute("""
    UPDATE cg_identity.user_account_membership_history AS h
    SET valid_to = s.valid_to,
        role_name = s.role_name,
        account_user_status = s.account_user_status
    FROM (
        SELECT
            ui.canonical_user_id,
            ei.canonical_account_id,
            us.role_name,
            us.account_user_status,
            us.valid_from,
            us.valid_to
        FROM public.uam_stage us
        JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
        JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
    ) AS s
    WHERE h.canonical_user_id = s.canonical_user_id
      AND h.canonical_account_id = s.canonical_account_id
      AND h.valid_from = s.valid_from
      AND h.valid_to IS DISTINCT FROM s.valid_to;
""")

# History: insert the intervals we do not have yet (antijoin on pair + valid_from).
# ON CONFLICT dedups pairs that collapse to the same canonical grain and makes re-runs idempotent.
ptk_execute("""
    INSERT INTO cg_identity.user_account_membership_history
        (canonical_user_id, canonical_account_id, role_name, account_user_status, valid_from, valid_to)
    SELECT ums.canonical_user_id, ums.canonical_account_id, ums.role_name,
           ums.account_user_status, ums.valid_from, ums.valid_to
    FROM (
        SELECT
            ui.canonical_user_id,
            ei.canonical_account_id,
            us.role_name,
            us.account_user_status,
            us.valid_from,
            us.valid_to
        FROM public.uam_stage us
        JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
        JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
    ) AS ums
    LEFT JOIN cg_identity.user_account_membership_history hm
        ON hm.canonical_user_id    = ums.canonical_user_id
       AND hm.canonical_account_id = ums.canonical_account_id
       AND hm.valid_from           = ums.valid_from
    WHERE hm.canonical_user_id IS NULL
    ON CONFLICT (canonical_user_id, canonical_account_id, valid_from) DO NOTHING;
""")

# Current: upsert from the OPEN history interval per affected pair, so status_changed_at stays in
# sync with the open valid_from (fixes RULE_6). PTK-89 fields stamped; updated_at via default + trigger.
ptk_execute("""
    INSERT INTO cg_identity.user_account_membership
        (canonical_user_id, canonical_account_id, role_name, account_user_status,
         status_changed_at, created_at, match_method, match_confidence, source_system)
    SELECT DISTINCT ON (h.canonical_user_id, h.canonical_account_id)
           h.canonical_user_id, h.canonical_account_id, h.role_name, h.account_user_status,
           h.valid_from, now(), 'deterministic', 1.000, 'dim_accountuser'
    FROM cg_identity.user_account_membership_history h
    JOIN (
        SELECT DISTINCT ui.canonical_user_id, ei.canonical_account_id
        FROM public.uam_stage us
        JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
        JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
    ) AS s ON h.canonical_user_id = s.canonical_user_id
          AND h.canonical_account_id = s.canonical_account_id
    WHERE h.valid_to IS NULL
    ORDER BY h.canonical_user_id, h.canonical_account_id, h.valid_from DESC
    ON CONFLICT (canonical_user_id, canonical_account_id) DO UPDATE SET
        role_name           = EXCLUDED.role_name,
        account_user_status = EXCLUDED.account_user_status,
        status_changed_at   = EXCLUDED.status_changed_at,
        match_method        = EXCLUDED.match_method,
        match_confidence    = EXCLUDED.match_confidence,
        source_system       = EXCLUDED.source_system;
""")

# Current: remove affected pairs that no longer have an OPEN interval (ended memberships).
ptk_execute("""
    DELETE FROM cg_identity.user_account_membership c
    USING (
        SELECT DISTINCT ui.canonical_user_id, ei.canonical_account_id
        FROM public.uam_stage us
        JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
        JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
    ) AS s
    WHERE c.canonical_user_id = s.canonical_user_id
      AND c.canonical_account_id = s.canonical_account_id
      AND NOT EXISTS (
          SELECT 1 FROM cg_identity.user_account_membership_history h
          WHERE h.canonical_user_id = c.canonical_user_id
            AND h.canonical_account_id = c.canonical_account_id
            AND h.valid_to IS NULL);
""")
