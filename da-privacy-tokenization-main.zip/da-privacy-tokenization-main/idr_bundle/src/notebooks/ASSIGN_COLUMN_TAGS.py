# Databricks notebook source
# Import standard libraries and the lakebase_utils logger for this notebook run.
from pyspark.sql import functions as F
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint

# Start the global notebook logger.
start_global_notebook_logger()

# Read the mandatory parameters supplied by the workflow. No defaults are declared, so a
# missing parameter fails the run instead of silently acting on the wrong catalog.
JOB_NAME = dbutils.widgets.get("job_name")
RESULTS_TABLE = dbutils.widgets.get("results_table")
ONLY_HIGH_CONFIDENCE = dbutils.widgets.get("only_high_confidence").strip().lower() == "true"

# Read the trigger type of this run, supplied by the workflow as {{job.trigger.type}}. A run
# started by hand from the UI or the API reports `one_time`; the table update trigger on the
# classification results table reports `table`.
TRIGGER_TYPE = dbutils.widgets.get("trigger_type").strip().lower()
TABLE_TRIGGER_TYPE = "table"
log_checkpoint("input variables defined")

# Define a reader for the comma separated scope parameters, dropping blank entries.
def csv_param(name):
    return [v.strip() for v in dbutils.widgets.get(name).split(",") if v.strip()]


# Read the scope filter. An empty schema list means every schema in the catalog and an
# empty table list means every table in the selected schemas.
TARGET_CATALOG = dbutils.widgets.get("target_catalog").strip()
TARGET_SCHEMAS = csv_param("target_schemas")
TARGET_TABLES = csv_param("target_tables")

# Decide where the catalogs in scope come from. A run given a catalog acts on exactly what
# its parameters select. A run given none is only meaningful when the classification results
# table triggered it, because then that table is the scope: every catalog it names is in
# scope. Any other trigger without a catalog is a misconfiguration, so the run fails here
# rather than falling back to a catalog nobody asked for.
DERIVE_SCOPE_FROM_RESULTS = not TARGET_CATALOG
if DERIVE_SCOPE_FROM_RESULTS and TRIGGER_TYPE != TABLE_TRIGGER_TYPE:
    raise ValueError(
        f"[{JOB_NAME}] target_catalog is empty and this run was not started by the "
        f"{RESULTS_TABLE} table update trigger (job.trigger.type={TRIGGER_TYPE!r}). "
        f"Pass target_catalog to run this job by hand."
    )


# Split a requested table into its schema and table parts. A bare name pins no schema and
# so matches in every selected schema; a leading catalog part is dropped because the
# catalog is already fixed by target_catalog.
def parse_table(entry):
    parts = entry.split(".")
    if len(parts) == 1:
        return None, parts[0]
    return parts[-2], parts[-1]


# Separate the qualified requests (schema pinned) from the bare ones (any schema).
QUALIFIED_TABLES = sorted({(s, t) for s, t in map(parse_table, TARGET_TABLES) if s})
BARE_TABLES = sorted({t for s, t in map(parse_table, TARGET_TABLES) if not s})


# Build the scope predicate for a dataframe holding schema and table name columns.
def scope_filter(schema_col, table_col):
    cond = F.lit(True)
    # Restrict to the requested schemas when any were given.
    if TARGET_SCHEMAS:
        cond = cond & schema_col.isin(TARGET_SCHEMAS)
    # Restrict to the requested tables when any were given, matching bare names in any
    # schema and qualified names only in the schema they name.
    if TARGET_TABLES:
        table_cond = F.lit(False)
        if BARE_TABLES:
            table_cond = table_cond | table_col.isin(BARE_TABLES)
        for s, t in QUALIFIED_TABLES:
            table_cond = table_cond | ((schema_col == s) & (table_col == t))
        cond = cond & table_cond
    return cond


# Define an identifier-quoting helper to survive reserved words / mixed case.
def q(i):
    return "`" + i.replace("`", "``") + "`"


spark.conf.set("spark.sql.session.timeZone", "UTC")

# Log the scope this run acts on, so the filter is visible in the run output.
log_checkpoint(f"Trigger: {TRIGGER_TYPE}, Catalog: {TARGET_CATALOG if TARGET_CATALOG else f'<from {RESULTS_TABLE}>'}")

# Load the classification detections with a non-null class_tag. The whole table is read, not
# only the rows the trigger saw change, because applying a tag that is already there is a
# no-op and a full pass also repairs anything an earlier run failed to tag.
results = (spark.table(RESULTS_TABLE)
           .select("catalog_name", "schema_name", "table_name",
                   "column_name", "class_tag", "confidence")
           .where(F.col("class_tag").isNotNull()))

# Pin the detections to the requested catalog. A run deriving its scope from the results
# table skips this, so every catalog the table names stays in scope.
if not DERIVE_SCOPE_FROM_RESULTS:
    results = results.where(F.col("catalog_name") == TARGET_CATALOG)

# Narrow the detections to the requested schemas and tables.
results = results.where(scope_filter(F.col("schema_name"), F.col("table_name")))

# Optionally restrict to HIGH confidence detections to avoid tagging weak matches.
if ONLY_HIGH_CONFIDENCE:
    results = results.where(F.col("confidence") == "HIGH")

# Derive only the tag KEY from class_tag (drop any value part).
desired = (results
           .withColumn("tag_key",
                       F.trim(F.split(F.col("class_tag"), ":").getItem(0)))
           .select("catalog_name", "schema_name", "table_name", "column_name", "tag_key")
           .dropDuplicates())

# Resolve the catalogs actually in scope from the detections themselves, so a derived run
# reads one information_schema per catalog the results table named.
CATALOGS = sorted({r["catalog_name"] for r in desired.select("catalog_name").distinct().collect()
                   if r["catalog_name"]})
print(f"[{JOB_NAME}] Catalogs in scope            : {', '.join(CATALOGS) if CATALOGS else '<none>'}")
log_checkpoint(f"Catalogs in scope: {len(CATALOGS)}")

# Load the currently applied column tags (tag_name only) from every catalog in scope.
tag_frames = []
for catalog in CATALOGS:
    # A catalog this run cannot read is reported and treated as untagged. Re-applying a tag
    # that is already there is harmless, and a real permission gap then surfaces as a FAILED
    # line below instead of being hidden here.
    try:
        tag_frames.append(spark.table(f"{q(catalog)}.information_schema.column_tags")
                          .select(F.lit(catalog).alias("catalog_name"),
                                  "schema_name", "table_name", "column_name", "tag_name"))
    except Exception as e:
        print(f"[{JOB_NAME}] WARNING cannot read {catalog}.information_schema.column_tags: "
              f"{str(e).splitlines()[0]}")

# Union the per-catalog tags into one frame, falling back to an empty one so the join below
# behaves the same when no catalog could be read.
CURRENT_SCHEMA = ("catalog_name string, schema_name string, table_name string, "
                  "column_name string, tag_name string")
current = spark.createDataFrame([], CURRENT_SCHEMA)
for frame in tag_frames:
    current = current.unionByName(frame)
current = current.dropDuplicates()

# Join desired vs. current by column + tag_name.
joined = (desired.alias("r")
          .join(
              current.alias("c"),
              on=[
                  F.col("r.catalog_name") == F.col("c.catalog_name"),
                  F.col("r.schema_name") == F.col("c.schema_name"),
                  F.col("r.table_name") == F.col("c.table_name"),
                  F.col("r.column_name") == F.col("c.column_name"),
                  F.col("r.tag_key") == F.col("c.tag_name"),
              ],
              how="left",
          )
          .select(
              F.col("r.catalog_name").alias("catalog_name"),
              F.col("r.schema_name").alias("schema_name"),
              F.col("r.table_name").alias("table_name"),
              F.col("r.column_name").alias("column_name"),
              F.col("r.tag_key").alias("tag_key"),
              F.col("c.tag_name").alias("existing_tag"),
          ))

# Split the work: rows whose tag_name already exists vs. rows still missing it.
already_ok = joined.where(F.col("existing_tag").isNotNull())
to_apply   = joined.where(F.col("existing_tag").isNull())

# Collect the pending rows to the driver for iteration.
pending = to_apply.collect()

# Log the validation summary before making any change.
print(f"[{JOB_NAME}] Missing tag (to apply)       : {len(pending)}")
log_checkpoint(f"Missing tags to apply: {len(pending)}")

# Apply the missing tags only, using the tag KEY, skipping existing ones.
applied, failed = 0, 0
fail_by_schema = {}
for i, r in enumerate(pending, start=1):
    # Build the fully qualified table name for the ALTER statement.
    fqtn = f"{q(r['catalog_name'])}.{q(r['schema_name'])}.{q(r['table_name'])}"
    # Compose the key-only SET TAGS statement.
    stmt = f"ALTER TABLE {fqtn} ALTER COLUMN {q(r['column_name'])} SET TAGS ('{r['tag_key']}')"
    # Execute the tag assignment; report and continue on permission errors.
    try:
        spark.sql(stmt)
        applied += 1
        log_checkpoint(f"Applied tag to {r['column_name']}", iteration=i, total=len(pending))
    except Exception as e:
        failed += 1
        key = f"{r['catalog_name']}.{r['schema_name']}"
        fail_by_schema[key] = fail_by_schema.get(key, 0) + 1
        error_str = str(e) if e else ""
        error_lines = error_str.split('\n') if error_str else []
        error_msg = error_lines[0] if error_lines else f"{type(e).__name__}"
        print(f"[{JOB_NAME}] FAILED {r['catalog_name']}.{r['schema_name']}.{r['table_name']}.{r['column_name']}: {error_msg}")
        if not error_msg or error_msg == f"{type(e).__name__}":
            print(f"[{JOB_NAME}] Error details: {repr(e)[:150]}")
        print(f"[{JOB_NAME}] SQL: {stmt[:150]}")
        log_checkpoint(f"FAILED tag assignment for {r['column_name']}: {error_msg}", iteration=i, total=len(pending))

# Log the final apply counts for this run.
print(f"[{JOB_NAME}] Applied now: {applied}   Failed: {failed}")
log_checkpoint(f"Tags applied: {applied}, failed: {failed}")

# Log the per-schema failure breakdown (typically missing APPLY TAG / USE / ASSIGN).
if fail_by_schema:
    print(f"[{JOB_NAME}] Failures by schema:")
    log_checkpoint(f"Found {len(fail_by_schema)} schemas with failures")
    for s, n in sorted(fail_by_schema.items()):
        print(f"[{JOB_NAME}]   {s}: {n}")
        log_checkpoint(f"Schema {s}: {n} failures")
else:
    log_checkpoint("No failures - all tags applied successfully")
