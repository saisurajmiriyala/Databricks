# Databricks notebook source
# Import standard libraries and the lakebase_utils logger for this notebook run.
from pyspark.sql import functions as F
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint


# Start the global notebook logger.
start_global_notebook_logger()

# Read the mandatory parameters supplied by the workflow. No defaults are declared, so a
# missing parameter fails the run instead of silently acting on the wrong catalog.
JOB_NAME = dbutils.widgets.get("job_name")
CLASS_TAG_PREFIX = dbutils.widgets.get("class_tag_prefix")
MASK_SCHEMA = dbutils.widgets.get("mask_schema")
MASK_VALUE = dbutils.widgets.get("mask_value")

# Read the classification results table and the confidence filter. Both are only used when
# this run has to derive its own scope, so it selects the same columns ASSIGN_COLUMN_TAGS did.
RESULTS_TABLE = dbutils.widgets.get("results_table")
ONLY_HIGH_CONFIDENCE = dbutils.widgets.get("only_high_confidence").strip().lower() == "true"

# Read the trigger type of this run, supplied by the workflow as {{job.trigger.type}}. A run
# started by hand from the UI or the API reports `one_time`; the table update trigger on the
# classification results table reports `table`.
TRIGGER_TYPE = dbutils.widgets.get("trigger_type").strip().lower()
TABLE_TRIGGER_TYPE = "table"
log_checkpoint("All input Varaiables defined")

# Define a reader for the comma separated scope parameters, dropping blank entries.
def csv_param(name):
    return [v.strip() for v in dbutils.widgets.get(name).split(",") if v.strip()]


# Read the scope filter. An empty schema list means every schema in the catalog and an
# empty table list means every table in the selected schemas.
TARGET_CATALOG = dbutils.widgets.get("target_catalog").strip()
TARGET_SCHEMAS = csv_param("target_schemas")
TARGET_TABLES = csv_param("target_tables")

# Decide where the catalogs in scope come from. A run given a catalog acts on exactly what
# its parameters select. A run given none is only meaningful when the classification results
# table triggered it, because then that table is the scope: every catalog it names is in
# scope. Any other trigger without a catalog is a misconfiguration, so the run fails here
# rather than falling back to a catalog nobody asked for.
DERIVE_SCOPE_FROM_RESULTS = not TARGET_CATALOG
if DERIVE_SCOPE_FROM_RESULTS and TRIGGER_TYPE != TABLE_TRIGGER_TYPE:
    raise ValueError(
        f"[{JOB_NAME}] target_catalog is empty and this run was not started by the "
        f"{RESULTS_TABLE} table update trigger (job.trigger.type={TRIGGER_TYPE!r}). "
        f"Pass target_catalog to run this job by hand."
    )


# Split a requested table into its schema and table parts. A bare name pins no schema and
# so matches in every selected schema; a leading catalog part is dropped because the
# catalog is already fixed by the scope it belongs to.
def parse_table(entry):
    parts = entry.split(".")
    if len(parts) == 1:
        return None, parts[0]
    return parts[-2], parts[-1]


# Build the scope predicate for a dataframe holding schema and table name columns, given the
# schemas and tables one scope selects.
def scope_filter(schemas, tables, schema_col, table_col):
    cond = F.lit(True)
    # Restrict to the requested schemas when any were given.
    if schemas:
        cond = cond & schema_col.isin(schemas)
    # Restrict to the requested tables when any were given, matching bare names in any
    # schema and qualified names only in the schema they name.
    if tables:
        parsed = list(map(parse_table, tables))
        bare = sorted({t for s, t in parsed if not s})
        qualified = sorted({(s, t) for s, t in parsed if s})
        table_cond = F.lit(False)
        if bare:
            table_cond = table_cond | table_col.isin(bare)
        for s, t in qualified:
            table_cond = table_cond | ((schema_col == s) & (table_col == t))
        cond = cond & table_cond
    return cond


spark.conf.set("spark.sql.session.timeZone", "UTC")

# Define the naming convention for the generated objects. These are deliberately not
# parameters: changing a prefix would orphan the policies created by earlier runs, which
# the reconciliation would then recreate under the new name.
MASK_FUNCTION_PREFIX = "mask_"
POLICY_PREFIX = "mask_"

# Define the column types a mask UDF can be generated for. Complex and semi-structured
# types are left out because a scalar redaction of them is not meaningful.
SUPPORTED_TYPE_PREFIXES = (
    "STRING", "VARCHAR", "CHAR",
    "TINYINT", "SMALLINT", "INT", "BIGINT",
    "FLOAT", "DOUBLE", "DECIMAL",
    "DATE", "TIMESTAMP",
    "BOOLEAN",
)
log_checkpoint("Prefixes defined")
# Read who the mask applies to and who is exempt from it, both supplied by the workflow
# as comma separated lists. The exempt one is the service principal the target runs as.
raw_widget = dbutils.widgets.get("policy_principals")
raw_principals = raw_widget.strip().strip("'\"` ")
POLICY_PRINCIPALS = [
    p.strip() for p in raw_principals.split(",") if p.strip()
]
log_checkpoint("Policy principals parsed")

raw_exempt = dbutils.widgets.get("policy_exempt_principals").strip().strip("'\"` ")
POLICY_EXEMPT_PRINCIPALS = [
    p.strip() for p in raw_exempt.split(",") if p.strip()
]

# Derive whether this run is allowed to write. An empty exemption list is treated as a
# misconfiguration rather than a strict deny, because silently masking the pipelines'
# own service principal would break every downstream job.
APPLY_POLICIES = bool(POLICY_PRINCIPALS) and bool(POLICY_EXEMPT_PRINCIPALS)

# Define an identifier-quoting helper to survive reserved words / mixed case.
def q(i):
    return "`" + i.replace("`", "``") + "`"

# Define a string-literal helper for principal names in the policy statements.
def lit(s):
    return "'" + s.replace("'", "''") + "'"

# Define a helper that turns any identifier fragment into a safe, stable slug.
def slug(text):
    return "".join(c if c.isalnum() else "_" for c in text.lower()).strip("_")


# Define the policy name for a tag / column type pair. The type is part of the name
# because a tag whose columns have several types needs one policy per type.
def policy_name_for(tag_name, data_type):
    return f"{POLICY_PREFIX}{slug(tag_name)}__{slug(data_type)}"


# Define the mask UDF name for a column type. Unity Catalog has no function
# overloading, so each type needs its own uniquely named function.
def function_name_for(data_type):
    return f"{MASK_FUNCTION_PREFIX}{slug(data_type)}"


# Define what the mask returns: a redaction literal for text, a typed NULL otherwise.
def mask_return_for(data_type):
    if data_type.startswith(("STRING", "VARCHAR", "CHAR")):
        return lit(MASK_VALUE)
    return f"CAST(NULL AS {data_type})"


# Define whether a mask UDF can be generated for a column type at all.
def is_supported(data_type):
    return data_type.startswith(SUPPORTED_TYPE_PREFIXES)


# Determine the securable the policies of one scope are attached to. Narrowing the scope
# narrows where the policies live, so a run limited to a few tables does not leave catalog
# wide policies behind that would go on masking everything else.
def securable_level(schemas, tables):
    if tables:
        return "TABLE"
    if schemas:
        return "SCHEMA"
    return "CATALOG"


# Build the securable a column's policy belongs on, as a (quoted, plain) pair. The plain
# form is only used for logging.
def securable_for(catalog, level, schema_name, table_name):
    if level == "TABLE":
        return (f"{q(catalog)}.{q(schema_name)}.{q(table_name)}",
                f"{catalog}.{schema_name}.{table_name}")
    if level == "SCHEMA":
        return (f"{q(catalog)}.{q(schema_name)}", f"{catalog}.{schema_name}")
    return (q(catalog), catalog)


# Resolve the scopes this run acts on, as (catalog, schemas, tables) triples.
if not DERIVE_SCOPE_FROM_RESULTS:
    # A catalog was given, so the parameters are the scope, exactly as they arrived.
    SCOPES = [(TARGET_CATALOG, TARGET_SCHEMAS, TARGET_TABLES)]
else:
    # No catalog was given and the results table triggered this run, so that table is the
    # scope: every table it holds a detection for, grouped by the catalog it lives in. The
    # whole table is read, not only the rows the trigger saw change, so a pass also covers
    # anything an earlier run failed to protect.
    detections = (spark.table(RESULTS_TABLE)
                  .select("catalog_name", "schema_name", "table_name", "class_tag", "confidence")
                  .where(F.col("class_tag").isNotNull()))
    if ONLY_HIGH_CONFIDENCE:
        detections = detections.where(F.col("confidence") == "HIGH")
    detections = detections.where(
        scope_filter(TARGET_SCHEMAS, TARGET_TABLES, F.col("schema_name"), F.col("table_name"))
    ).select("catalog_name", "schema_name", "table_name")
    # Group the detected tables by catalog. Each table is pinned by name, so every derived
    # scope attaches its policies at table level.
    tables_by_catalog = {}
    for r in detections.distinct().collect():
        if not (r["catalog_name"] and r["schema_name"] and r["table_name"]):
            continue
        tables_by_catalog.setdefault(r["catalog_name"], set()).add(
            f"{r['schema_name']}.{r['table_name']}"
        )
    SCOPES = [(c, [], sorted(ts)) for c, ts in sorted(tables_by_catalog.items())]

# Log the scope this run acts on, so the filter is visible in the run output.
scope_info = f"Trigger: {TRIGGER_TYPE}, Source: {RESULTS_TABLE if DERIVE_SCOPE_FROM_RESULTS else 'parameters'}, Scopes: {len(SCOPES)}"
log_checkpoint(scope_info)

# Group the distinct tag / type pairs by the securable their policy is created on. At
# catalog level every row of a scope collapses into a single securable; at schema or table
# level the same pair can appear under several, each needing its own policy. The key carries
# the catalog and the level so the statements below know where each policy goes.
by_securable = {}
for catalog, schemas, tables in SCOPES:
    level = securable_level(schemas, tables)
    log_checkpoint(f"Processing catalog: {catalog} (level={level})")

    # Load every class.* tag currently applied to a column in this catalog, together with the
    # data types of the columns carrying it, narrowed to the requested scope.
    try:
        tagged = (spark.table(f"{q(catalog)}.information_schema.column_tags")
                  .where(F.col("tag_name").startswith(CLASS_TAG_PREFIX))
                  .where(scope_filter(schemas, tables, F.col("schema_name"), F.col("table_name")))
                  .select("schema_name", "table_name", "column_name", "tag_name"))
        log_checkpoint(f"Successfully loaded column_tags for {catalog}")
    except Exception as e:
        log_checkpoint(f"WARNING: Cannot read {catalog}.information_schema.column_tags: {str(e).splitlines()[0]}")
        continue

    # Read table types so external tables can be filtered out — policies can only be created
    # ON MANAGED tables, not on EXTERNAL tables or VIEWs.
    try:
        tables_info = (spark.table(f"{q(catalog)}.information_schema.tables")
                       .select("table_schema", "table_name", "table_type"))
        log_checkpoint(f"Successfully loaded tables info for {catalog}")
    except Exception as e:
        log_checkpoint(f"WARNING: Cannot read {catalog}.information_schema.tables: {str(e).splitlines()[0]}")
        continue

    # Use full_data_type so parameterised types keep their precision. Only MANAGED tables.
    try:
        columns = (spark.table(f"{q(catalog)}.information_schema.columns")
                   .alias("cols")
                   .join(
                       tables_info.alias("ti"),
                       on=[
                           F.col("cols.table_schema") == F.col("ti.table_schema"),
                           F.col("cols.table_name") == F.col("ti.table_name"),
                       ],
                       how="inner",
                   )
                   .where(F.col("ti.table_type") == "MANAGED")
                   .select(
                       F.col("cols.table_schema").alias("schema_name"),
                       F.col("cols.table_name").alias("table_name"),
                       F.col("cols.column_name").alias("column_name"),
                       F.upper(F.col("cols.full_data_type")).alias("data_type"),
                   ))
        log_checkpoint(f"Successfully loaded columns for {catalog} (MANAGED tables only)")
    except Exception as e:
        log_checkpoint(f"WARNING: Cannot read {catalog}.information_schema.columns: {str(e).splitlines()[0]}")
        continue

    # Join tags to column types. An inner join drops tagged columns the catalog can no longer
    # resolve, so an unknown type is never mistaken for a maskable one. Schema and table are
    # kept so each pair can be routed to the securable its policy belongs on.
    tag_types = (tagged.alias("t")
                 .join(
                     columns.alias("c"),
                     on=[
                         F.col("t.schema_name") == F.col("c.schema_name"),
                         F.col("t.table_name") == F.col("c.table_name"),
                         F.col("t.column_name") == F.col("c.column_name"),
                     ],
                     how="inner",
                 )
                 .select(
                     F.col("t.schema_name").alias("schema_name"),
                     F.col("t.table_name").alias("table_name"),
                     F.col("t.tag_name").alias("tag_name"),
                     F.col("c.data_type").alias("data_type"),
                 ))

    tag_count = 0
    for r in tag_types.distinct().collect():
        quoted, plain = securable_for(catalog, level, r["schema_name"], r["table_name"])
        key = (catalog, level, quoted, plain)
        by_securable.setdefault(key, set()).add((r["tag_name"], r["data_type"]))
        tag_count += 1
    log_checkpoint(f"Processed {tag_count} tag/type pairs for {catalog}")

# Reduce to the distinct tag / type pairs actually present. A tag carried by columns of
# several types produces several pairs, and therefore several policies.
pairs = sorted({p for ps in by_securable.values() for p in ps})

# Split the pairs by whether a mask UDF can be generated for that column type.
desired = [(t, d) for t, d in pairs if is_supported(d)]
unsupported = [(t, d) for t, d in pairs if not is_supported(d)]

# Work out per securable which policies are still missing. SHOW EFFECTIVE POLICIES also
# reports the ones inherited from a parent, so a schema or table scoped run does not
# duplicate a policy an existing catalog wide one already applies.
missing_by_securable = {}
for key in sorted(by_securable):
    catalog, level, quoted, plain = key
    existing_rows = spark.sql(f"SHOW EFFECTIVE POLICIES ON {level} {quoted}").collect()
    existing_policies = {r[0] for r in existing_rows}
    still_missing = sorted((t, d) for t, d in by_securable[key]
                           if is_supported(d) and policy_name_for(t, d) not in existing_policies)
    if still_missing:
        missing_by_securable[key] = still_missing
        log_checkpoint(f"Found {len(still_missing)} missing policies on {plain}")
    else:
        log_checkpoint(f"No missing policies on {plain} (all {len(by_securable[key])} already exist)")

# Flatten the pending work for the counts below. The same pair can occur more than once
# when the run is scoped to several catalogs, schemas or tables.
missing = [p for ps in missing_by_securable.values() for p in ps]

# Log the validation summary before making any change.
tags_seen = sorted({t for t, _ in pairs})
for key in sorted(missing_by_securable):
    for t, d in missing_by_securable[key]:
        print(f"[{JOB_NAME}]   MISSING {policy_name_for(t, d)} on {key[3]} <- {t} ({d})")

# Call out tags carried by more than one column type, since those get several policies
# and rely on Unity Catalog matching each column to the UDF that fits its type.
multi_type = sorted({t for t in tags_seen if len({d for tt, d in pairs if tt == t}) > 1})
if multi_type:
    print(f"[{JOB_NAME}] Multi-type tags                : {len(multi_type)}")
    for t in multi_type:
        types = ", ".join(sorted(d for tt, d in pairs if tt == t))
        print(f"[{JOB_NAME}]   MULTI-TYPE {t}: {types}")

# Report tag/type pairs no mask UDF can be generated for, so the gap stays visible.
if unsupported:
    print(f"[{JOB_NAME}] Skipped (unsupported type)     : {len(unsupported)}")
    for t, d in unsupported:
        print(f"[{JOB_NAME}]   SKIPPED {t} ({d})")

# Log who stays exempt, or stop before writing anything if the parameter came in empty.
if APPLY_POLICIES:
    print(f"[{JOB_NAME}] Exempt principals              : {', '.join(POLICY_EXEMPT_PRINCIPALS)}")
else:
    print(f"[{JOB_NAME}] policy_exempt_principals is empty; validate-only run, nothing applied.")

# Create one typed masking UDF per column type, then apply the missing policies.
applied, failed = 0, 0
if APPLY_POLICIES and missing_by_securable:
    # Collect the column types still to cover per catalog, since a policy has to reference a
    # mask UDF that lives in the same catalog as the securable it is attached to.
    types_by_catalog = {}
    for (catalog, _level, _quoted, _plain), ps in missing_by_securable.items():
        types_by_catalog.setdefault(catalog, set()).update(d for _, d in ps)

    for catalog, data_types in sorted(types_by_catalog.items()):
        # Ensure the schema holding the mask UDFs exists before any policy references them.
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {q(catalog)}.{q(MASK_SCHEMA)}")
        except Exception as e:
            print(f"[{JOB_NAME}] WARNING cannot create schema {catalog}.{MASK_SCHEMA}: {str(e).splitlines()[0]}")
            continue

        # Create one UDF per distinct column type in the pending work, each with a signature
        # that matches the columns it will mask.
        for data_type in sorted(data_types):
            fq = f"{q(catalog)}.{q(MASK_SCHEMA)}.{q(function_name_for(data_type))}"
            try:
                spark.sql(
                    f"CREATE FUNCTION IF NOT EXISTS {fq}(v {data_type}) "
                    f"RETURNS {data_type} RETURN {mask_return_for(data_type)}"
                )
            except Exception as e:
                print(f"[{JOB_NAME}] WARNING cannot create mask function {fq}: {str(e).splitlines()[0]}")

    # Compose the principal clauses: everyone in scope, minus the exempt service principal.
    to_clause = ", ".join(q(p) for p in POLICY_PRINCIPALS)
    except_clause = " EXCEPT " + ", ".join(q(p) for p in POLICY_EXEMPT_PRINCIPALS)
    log_checkpoint(f"Schemas and UDFs created, principal clauses composed")

    # Create the policies one securable at a time, so a scoped run only touches the
    # catalogs, schemas or tables the filter selected.
    for key in sorted(missing_by_securable):
        catalog, level, quoted, plain = key
        policy_count = 0
        for tag, data_type in missing_by_securable[key]:
            # Compose the default-deny column mask policy for this tag / column type pair.
            name = policy_name_for(tag, data_type)
            fq_function = f"{q(catalog)}.{q(MASK_SCHEMA)}.{q(function_name_for(data_type))}"
            stmt = (
                f"CREATE POLICY {q(name)} "
                f"ON {level} {quoted} "
                f"COMMENT 'PRV-59 default-deny masking for {tag} ({data_type})' "
                f"COLUMN MASK {fq_function} "
                f"TO {to_clause}{except_clause} "
                f"FOR TABLES "
                f"MATCH COLUMNS has_tag('{tag}') AS masked_column "
                f"ON COLUMN masked_column"
            )
            # Execute the policy creation; report and continue on permission errors.
            try:
                spark.sql(stmt)
                applied += 1
                policy_count += 1
                log_checkpoint(f"Created policy: {name} on {plain}")
            except Exception as e:
                failed += 1
                error_str = str(e) if e else ""
                error_lines = error_str.split('\n') if error_str else []
                error_msg = error_lines[0] if error_lines else f"{type(e).__name__}"
                log_checkpoint(f"FAILED to create {name} on {plain}: {error_msg}")
        log_checkpoint(f"Completed {plain}: {policy_count} policies created")

# Log the final apply counts for this run.
print(f"[{JOB_NAME}] Applied now: {applied}   Failed: {failed}")
log_checkpoint(f"Policies applied: {applied}, failed: {failed}")