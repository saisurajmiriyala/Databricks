# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# PRV-98 bootstrap load: expects cg_identity empty and unindexed, which is why ON CONFLICT is replaced by DISTINCT ON and a pre-upsert CTE.

# Connect to the cg_identity database and start tracking this run.
import os
from lakebase_utils.idr.resolution import add_hmacs, USER_ANCHOR_TYPE, ACCOUNT_ANCHOR_TYPE
from lakebase_utils.idr.hmac_util import fetch_secret_scope
from lakebase_utils.postgres.connection import ptk_connect, fetch_lakebase_credentials
from lakebase_utils.postgres.queryhub import ptk_execute
# One COPY per Spark partition instead of collecting the DataFrame to the driver.
from lakebase_utils.postgres.bulkload import load_uc_to_lakebase
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
from pyspark.sql import functions as F

start_global_notebook_logger()

# Secret scope derived from the workspace this notebook runs in.
_SECRET_SCOPE = fetch_secret_scope()
ptk_connect(**fetch_lakebase_credentials())
spark.conf.set("spark.sql.session.timeZone", "UTC")

# Whole account-user history, 42,423,193 rows; the join silently drops the ~21% of fact rows whose surrogate key is missing from a dimension.
# Legacy catalog holding the source tables, set per environment by the job.
dbutils.widgets.text("LEGACY_CATALOG", "", "Legacy catalog holding the source tables")
LEGACY_CATALOG = dbutils.widgets.get("LEGACY_CATALOG").strip()

# Root of the full-history extracts, in a dev-only volume. Only dev has a value, and that
# is what picks the source: with a path, read the extracts; without one, query the real
# dimensions, with no day window.
dbutils.widgets.text("IDR_HISTORICAL_SOURCE_ROOT", "", "Volume path holding the historical extracts")
SOURCE_ROOT = dbutils.widgets.get("IDR_HISTORICAL_SOURCE_ROOT").strip().rstrip("/")

uuid_regex = r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$"
log_checkpoint("source data path and uuid pattern defined")

if SOURCE_ROOT:
    df_account_user = (
        spark.read
        .format("parquet")
        .option("header", "true")
        .option("inferSchema", "true")
        .load(f"{SOURCE_ROOT}/accountuser/")
    )
else:
    # Same query as the incremental notebook without its day window, so the two agree on
    # shape. The dimensions hold one row per SCD2 version, so joining them whole
    # duplicates every fact row - 54,977,543 rows against 42,423,193 real ones. Each
    # surrogate key maps to exactly one natural key, so taking the distinct pair loses
    # nothing.
    df_account_user = spark.sql(f"""
        SELECT
            u.user_id,
            a.account_id,
            au.role_name,
            au.account_user_status,
            au.`__START_AT`,
            au.`__END_AT`,
            au.current_record
        FROM {LEGACY_CATALOG}.gold.dim_accountuser au
        JOIN (SELECT DISTINCT user_sk, user_id       FROM {LEGACY_CATALOG}.gold.dim_user)    u
            ON au.user_sk    = u.user_sk
        JOIN (SELECT DISTINCT account_sk, account_id FROM {LEGACY_CATALOG}.gold.dim_account) a
            ON au.account_sk = a.account_sk
    """)

# Keep only the columns the history table needs (open interval => valid_to is already NULL in source __END_AT).
df_source = df_account_user.filter(
    F.col("user_id").isNotNull()
    & F.col("account_id").isNotNull()
    & F.col("user_id").rlike(uuid_regex)
    & F.col("account_id").rlike(uuid_regex)
)

df_stage = df_source.select(
    "user_id",
    "account_id",
    F.col("role_name"),
    F.col("account_user_status"),
    F.col("__START_AT").alias("valid_from"),
    F.col("__END_AT").alias("valid_to"),
)

log_checkpoint("source dataframe created")
# Compute the anchor HMACs; the cg_identity tables store only HMACs, so the HMAC is the lookup key.
os.environ["IDR_PEPPER_SECRET_SCOPE"] = _SECRET_SCOPE
df_hmacs = add_hmacs(
    df_stage,
    [
        ("user_id", USER_ANCHOR_TYPE, "user_hmac"),
        ("account_id", ACCOUNT_ANCHOR_TYPE, "account_hmac"),
    ],
)

# Project to the staging table's columns (HMACs + interval attributes).
df_hmacs_long = df_hmacs.select(
    F.col("user_hmac"),
    F.col("account_hmac"),
    F.col("role_name"),
    F.col("account_user_status"),
    F.col("valid_from"),
    F.col("valid_to"),
)
log_checkpoint("Project to the staging table's columns")
# Shares the incremental's stage, so the two must never run at the same time.
load_uc_to_lakebase("df_hmacs_long", "public.uam_stage",
                    source_df=df_hmacs_long, mode="truncate")

# History: insert the intervals we do not have (antijoin on pair + valid_from); DISTINCT ON dedups within the batch, which ON CONFLICT cannot do here without a unique index.
ptk_execute(f"""
    INSERT INTO cg_identity.user_account_membership_history
        (canonical_user_id, canonical_account_id, role_name, account_user_status, valid_from, valid_to)
    SELECT ums.canonical_user_id, ums.canonical_account_id, ums.role_name,
           ums.account_user_status, ums.valid_from, ums.valid_to
    FROM (
        SELECT DISTINCT ON (ui.canonical_user_id, ei.canonical_account_id, us.valid_from)
            ui.canonical_user_id,
            ei.canonical_account_id,
            us.role_name,
            us.account_user_status,
            us.valid_from,
            us.valid_to
        FROM public.uam_stage us
        JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
        JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
        ORDER BY ui.canonical_user_id, ei.canonical_account_id, us.valid_from,
                 us.valid_to NULLS FIRST
    ) AS ums
    LEFT JOIN cg_identity.user_account_membership_history hm
        ON hm.canonical_user_id    = ums.canonical_user_id
       AND hm.canonical_account_id = ums.canonical_account_id
       AND hm.valid_from           = ums.valid_from
    WHERE hm.canonical_user_id IS NULL;
""")

# Current: pre-upsert form (UPDATE, then INSERT the pairs it did not touch via RETURNING) because the bare DDL has no unique index for ON CONFLICT.
ptk_execute(f"""
    WITH src AS (
        SELECT DISTINCT ON (h.canonical_user_id, h.canonical_account_id)
               h.canonical_user_id, h.canonical_account_id, h.role_name,
               h.account_user_status, h.valid_from
        FROM cg_identity.user_account_membership_history h
        JOIN (
            SELECT DISTINCT ui.canonical_user_id, ei.canonical_account_id
            FROM public.uam_stage us
            JOIN cg_identity.user_identifier    ui ON us.user_hmac    = ui.identifier_value_hmac
            JOIN cg_identity.account_identifier ei ON us.account_hmac = ei.identifier_value_hmac
        ) AS s ON h.canonical_user_id = s.canonical_user_id
              AND h.canonical_account_id = s.canonical_account_id
        WHERE h.valid_to IS NULL
        ORDER BY h.canonical_user_id, h.canonical_account_id, h.valid_from DESC
    ),
    upd AS (
        UPDATE cg_identity.user_account_membership c
        SET role_name           = src.role_name,
            account_user_status = src.account_user_status,
            status_changed_at   = src.valid_from,
            match_method        = 'deterministic',
            match_confidence    = 1.000,
            source_system       = 'dim_accountuser'
        FROM src
        WHERE c.canonical_user_id    = src.canonical_user_id
          AND c.canonical_account_id = src.canonical_account_id
        RETURNING c.canonical_user_id, c.canonical_account_id
    )
    INSERT INTO cg_identity.user_account_membership
        (canonical_user_id, canonical_account_id, role_name, account_user_status,
         status_changed_at, created_at, match_method, match_confidence, source_system)
    SELECT src.canonical_user_id, src.canonical_account_id, src.role_name,
           src.account_user_status, src.valid_from, now(), 'deterministic', 1.000, 'dim_accountuser'
    FROM src
    WHERE NOT EXISTS (
        SELECT 1 FROM upd u
        WHERE u.canonical_user_id    = src.canonical_user_id
          AND u.canonical_account_id = src.canonical_account_id
    );
""")
