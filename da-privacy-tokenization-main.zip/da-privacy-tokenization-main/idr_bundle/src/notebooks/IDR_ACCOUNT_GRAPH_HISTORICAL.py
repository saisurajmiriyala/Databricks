# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# PRV-98 bootstrap load: expects cg_identity empty and unindexed, and mints a fresh canonical per person, so it duplicates everything against a populated graph.

# Connect to the identity database and start tracking this run.
import os
from lakebase_utils.idr.resolution import add_hmacs
from lakebase_utils.idr.hmac_util import fetch_secret_scope
from lakebase_utils.postgres.connection import ptk_connect, fetch_lakebase_credentials
from lakebase_utils.postgres.queryhub import ptk_execute
# One COPY per Spark partition; ptk_write_dataframe collects to the driver and does not survive this batch size.
from lakebase_utils.postgres.bulkload import load_uc_to_lakebase
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
from lakebase_utils.idr.normalize import NULL_IDENTIFIER_TOKENS
from pyspark.sql import Window
from pyspark.sql import functions as F

start_global_notebook_logger()

# Secret scope derived from the workspace this notebook runs in.
_SECRET_SCOPE = fetch_secret_scope()
# Open the connection to the Lakebase Postgres database.
ptk_connect(**fetch_lakebase_credentials())

# Legacy catalog holding the source tables, set per environment by the job.
dbutils.widgets.text("LEGACY_CATALOG", "", "Legacy catalog holding the source tables")
LEGACY_CATALOG = dbutils.widgets.get("LEGACY_CATALOG").strip()

# Root of the full-history extracts, in a dev-only volume. Only dev has a value, and that
# is what picks the source: with a path, read the extracts; without one, query the real
# tables, with no day window.
dbutils.widgets.text("IDR_HISTORICAL_SOURCE_ROOT", "", "Volume path holding the historical extracts")
SOURCE_ROOT = dbutils.widgets.get("IDR_HISTORICAL_SOURCE_ROOT").strip().rstrip("/")

if SOURCE_ROOT:
    # Full-history extracts: 29,383,398 user rows and 39,599,173 account-user rows,
    # against the incremental's 1,092,856 and 1,109,079.
    df_users = spark.read.format("parquet").load(f"{SOURCE_ROOT}/users/")
    df_account_users = spark.read.format("parquet").load(f"{SOURCE_ROOT}/accounts_users/")
else:
    # The users feed. Same query in the other three notebooks that read it; they have to agree.
    # Raw f-string: the phone regex needs its backslashes to reach the SQL literal.
    df_users = spark.sql(rf"""
        WITH contact_current AS (
            SELECT Id, User_ID__c
            FROM (
                SELECT Id,
                       User_ID__c,
                       ROW_NUMBER() OVER (PARTITION BY Id ORDER BY SystemModstamp DESC) AS rn
                FROM {LEGACY_CATALOG}.silver_data_lake.salesforce_contact_stage
                WHERE NOT IsDeleted
            )
            WHERE rn = 1
        ),
        users AS (
            SELECT DISTINCT
                UPPER(TRIM(up.UserId)) AS UpperUserId,
                up.AnalyticsId         AS external_userid_firebase
            FROM {LEGACY_CATALOG}.myq_sql.cgi_usersprofile up
            JOIN {LEGACY_CATALOG}.myq_sql.cgi_accountuser cau
                ON up.UserId = cau.UserId
            JOIN {LEGACY_CATALOG}.myq_sql.cgi_account acc
                ON cau.AccountId = acc.AccountId
        ),
        membership AS (
            SELECT UpperUserId, Email
            FROM (
                SELECT
                    UPPER(TRIM(UserId)) AS UpperUserId,
                    Email,
                    ROW_NUMBER() OVER (
                        PARTITION BY UPPER(TRIM(UserId)) ORDER BY crt_dttm DESC
                    ) AS rn
                FROM {LEGACY_CATALOG}.myq_sql.aspnet_membership
                WHERE UserId IS NOT NULL AND TRIM(UserId) <> ''
            )
            WHERE rn = 1
        ),
        contact AS (
            SELECT
                UPPER(TRIM(User_ID__c)) AS UpperUserId,
                MAX(Id)                 AS external_user_id,
                COUNT(DISTINCT Id)      AS n_contacts
            FROM contact_current
            WHERE User_ID__c IS NOT NULL AND TRIM(User_ID__c) <> ''
            GROUP BY UPPER(TRIM(User_ID__c))
        ),
        user_email_sf AS (
            SELECT
                m.UpperUserId              AS myq_user_id,
                m.Email                    AS email,
                c.external_user_id         AS external_userid_salesforce,
                r.external_userid_firebase,
                c.n_contacts,
                CASE
                    WHEN m.Email IS NOT NULL AND TRIM(m.Email) <> ''
                     AND c.external_user_id IS NOT NULL AND TRIM(c.external_user_id) <> ''
                        THEN 'email_and_external'
                    WHEN m.Email IS NOT NULL AND TRIM(m.Email) <> ''
                        THEN 'email_only'
                    WHEN c.external_user_id IS NOT NULL AND TRIM(c.external_user_id) <> ''
                        THEN 'external_only'
                    ELSE 'none'
                END AS coverage
            FROM membership m
            JOIN users r ON m.UpperUserId = r.UpperUserId
            LEFT JOIN contact c ON m.UpperUserId = c.UpperUserId
        ),
        tmp_phones AS (
            SELECT
                UPPER(TRIM(upf.UserId)) AS userid,
                CASE
                    WHEN upf.MobilePhone IS NULL    THEN NULL
                    WHEN TRIM(upf.MobilePhone) = '' THEN NULL
                    ELSE REGEXP_REPLACE(TRIM(upf.MobilePhone), '[\\s\\(\\)\\-\\+]', '')
                END AS clean_phone
            FROM {LEGACY_CATALOG}.myq_sql.cgi_userpartnerfunctions upf
            JOIN {LEGACY_CATALOG}.myq_sql.aspnet_membership mem
                ON upf.UserId = mem.UserId
            WHERE upf.PartnerFunctionCode = 'AG'
              AND mem.IsActive
        ),
        v_users AS (
            SELECT DISTINCT * EXCEPT (n_contacts, coverage, userid)
            FROM user_email_sf AS u
            LEFT JOIN tmp_phones AS p ON u.myq_user_id = p.userid
            WHERE n_contacts = 1
              AND coverage = 'email_and_external'
              AND external_userid_firebase IS NOT NULL
        )
        SELECT * FROM v_users
    """)

    # Which user belongs to which account.
    df_account_users = spark.sql(rf"""
        SELECT DISTINCT
            acc.AccountId AS account_id,
            up.UserId     AS user_id
        FROM {LEGACY_CATALOG}.myq_sql.cgi_accountuser cau
        JOIN {LEGACY_CATALOG}.myq_sql.cgi_account acc
            ON cau.AccountId = acc.AccountId
        JOIN {LEGACY_CATALOG}.myq_sql.cgi_usersprofile up
            ON cau.UserId = up.UserId
        WHERE NOT cau.IsDeleted
    """)

# One row per person. The source can hand us the same user twice, and dropping an arbitrary
# copy loses the phone whenever only one copy carries it - so order the copies to put a
# usable phone first and keep that one. row_number, not rank: ties still have to collapse to
# a single row. The trailing ordering columns only break ties, so a rerun keeps the same row.
# The phone criterion only applies when the source carries the column: the dev extracts are
# read as-is and one without a phone column still has to collapse its duplicates, not fail.
_dedup_order = []
if "clean_phone" in df_users.columns:
    _phone_value = F.trim(F.col("clean_phone").cast("string"))
    _dedup_order = [
        F.col("clean_phone").isNull() | F.lower(_phone_value).isin(*sorted(NULL_IDENTIFIER_TOKENS)),
        _phone_value.asc_nulls_last(),
    ]

df_users = (
    df_users
    .withColumn(
        "user_row",
        F.row_number().over(
            Window.partitionBy("myq_user_id").orderBy(
                *_dedup_order,
                F.col("email").asc_nulls_last(),
                F.col("external_userid_salesforce").asc_nulls_last(),
                F.col("external_userid_firebase").asc_nulls_last(),
            )
        ),
    )
    .filter(F.col("user_row") == 1)
    .drop("user_row")
)

log_checkpoint("Users and account users source data frames created")
# Turn each person's details into safe, anonymous keys and group them by person.
os.environ["IDR_PEPPER_SECRET_SCOPE"] = _SECRET_SCOPE
_hmac_specs = [
    ("myq_user_id",                "myq_user_id",   "anchor_hmac"),
    ("email",                      "email",            "email_hmac"),
    ("external_userid_salesforce", "external_user_id", "sf_hmac"),
    ("external_userid_firebase",   "external_user_id", "firebase_hmac"),
]
if "clean_phone" in df_users.columns:
    _hmac_specs.append(("clean_phone", "phone", "phone_hmac"))

df_hmacs = add_hmacs(df_users, _hmac_specs)

# Group each person's identifiers under one key and mint one candidate canonical for all of them.
df_persons = (
    df_hmacs
    .withColumn(
        "person_key",
        F.coalesce("anchor_hmac", "email_hmac", "sf_hmac", "firebase_hmac"),
    )
    .filter(F.col("person_key").isNotNull())
)
log_checkpoint("grouping the hamc values per identifier")

# Give each unique person one brand-new ID of their own.
df_person_canon = (
    df_persons.select("person_key").distinct()
    .withColumn("canonical_user_id", F.expr("uuid()"))
)
# ADDED (PRV-98): checkpoint requested in review.
log_checkpoint("generating canonical id's")

# List every one of a person's IDs (email, etc.) next to their single person ID, dropping blanks and repeats.
_identifier_hmac_cols = [out_col for _src, _itype, out_col in _hmac_specs]
df_user_identifiers = (
    df_persons.join(df_person_canon, "person_key")
    .select("canonical_user_id", *_identifier_hmac_cols)
    .unpivot(
        ids=["canonical_user_id"],
        values=_identifier_hmac_cols,
        variableColumnName="src",
        valueColumnName="identifier_value_hmac",
    )
    .filter(F.col("identifier_value_hmac").isNotNull())
    .withColumn(
        "identifier_type",
        F.when(F.col("src") == "anchor_hmac", F.lit("myq_user_id"))
        .when(F.col("src") == "email_hmac", F.lit("email"))
        .when(F.col("src") == "sf_hmac", F.lit("external_user_id"))
        .when(F.col("src") == "firebase_hmac", F.lit("external_user_id"))
        .when(F.col("src") == "phone_hmac", F.lit("phone")),
    )
    .withColumn(
        "vendor",
        F.when(F.col("src") == "sf_hmac", F.lit("salesforce"))
        .when(F.col("src") == "firebase_hmac", F.lit("firebase"))
        .otherwise(F.lit("")),
    )
    .select("canonical_user_id", "identifier_value_hmac", "vendor", "identifier_type")
    .dropDuplicates(["identifier_type", "vendor", "identifier_value_hmac"])
)
log_checkpoint("List every one of a person's IDs (email, etc.) next to their single person ID, dropping blanks and repeats.")

# Shares the incremental's stage, so the two must never run at the same time.
load_uc_to_lakebase("df_user_identifiers", "public.user_identifier",
                    source_df=df_user_identifiers, mode="truncate")

# Insert brand-new people; the incremental's resolve step is gone, it matched nothing against an empty graph.
ptk_execute(f"""
    INSERT INTO cg_identity.user_identity (canonical_user_id)
    SELECT DISTINCT s.canonical_user_id
    FROM "public".user_identifier as s
    LEFT JOIN cg_identity.user_identity as ii
        ON ii.canonical_user_id = s.canonical_user_id
    WHERE ii.canonical_user_id IS NULL
""")

# Insert the new identifiers we have not stored yet.
ptk_execute(f"""
    INSERT INTO cg_identity.user_identifier (canonical_user_id, identifier_value_hmac, identifier_type, vendor, source_system, match_method, match_confidence)
    SELECT DISTINCT s.canonical_user_id, s.identifier_value_hmac, s.identifier_type, COALESCE(s.vendor, '') as vendor, 'idr_historical', 'deterministic', 1.000
    FROM "public".user_identifier as s
    LEFT JOIN cg_identity.user_identifier as ii
        ON ii.identifier_value_hmac = s.identifier_value_hmac
        AND ii.identifier_type      = s.identifier_type
        AND ii.vendor               = COALESCE(s.vendor, '')
    WHERE ii.canonical_user_id IS NULL
""")

# Turn the account details into safe, anonymous keys and stage them.
df_hmacs_accounts = add_hmacs(df_account_users, [
    ("account_id", "account_id", "account_id_hmac"),
    ("user_id", "myq_user_id", "user_id_hmac")
])

# Give each account a brand-new ID and keep its safe account and user keys.
df_accounts_hmac_canonical = df_hmacs_accounts.select(
    F.col("account_id_hmac").alias("account_id"),
    F.col("user_id_hmac").alias("user_id"),
    F.expr("uuid()").alias("canonical_account_id")
)
log_checkpoint("Give each account a brand-new ID")
load_uc_to_lakebase("df_accounts_hmac_canonical", "public.user_accounts",
                    source_df=df_accounts_hmac_canonical, mode="truncate")

# Insert brand-new accounts into the account identity table.
ptk_execute(f"""
  INSERT INTO cg_identity.account_identity (canonical_account_id)
  SELECT min(ua.canonical_account_id::text)::uuid as canonical_account_id
  FROM "public".user_accounts as ua
  LEFT JOIN cg_identity.account_identifier as ai
    ON ai.identifier_value_hmac = ua.account_id
    AND ai.identifier_type = 'account_id'
  WHERE ai.canonical_account_id is null
    AND ua.account_id is not null
  GROUP by ua.account_id
""")

# Insert the new account identifiers we have not stored yet.
ptk_execute(f"""
    INSERT INTO cg_identity.account_identifier (canonical_account_id, identifier_value_hmac, identifier_type, vendor, source_system, match_method, match_confidence)
    SELECT min(ua.canonical_account_id::text)::uuid, ua.account_id, 'account_id', '', 'idr_historical', 'deterministic', 1.000
    FROM "public".user_accounts as ua
    LEFT JOIN cg_identity.account_identifier as ai
        ON ai.identifier_value_hmac = ua.account_id
        AND ai.identifier_type = 'account_id'
        AND ai.vendor = ''
    WHERE ai.canonical_account_id is null
        AND ua.account_id is not null
    GROUP BY ua.account_id
""")
