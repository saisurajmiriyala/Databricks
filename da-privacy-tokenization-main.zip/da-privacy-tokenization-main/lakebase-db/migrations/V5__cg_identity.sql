-- cg_identity.set_updated_at is created first: table triggers below depend on it existing.
CREATE OR REPLACE FUNCTION cg_identity.set_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$
;

-- cg_identity.account_identity definition

CREATE TABLE cg_identity.account_identity (
	canonical_account_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	dsar_request_id uuid NULL,
	CONSTRAINT account_identity_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text])))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_identity.account_identity for each row execute function cg_identity.set_updated_at();


-- cg_identity.user_identity definition

CREATE TABLE cg_identity.user_identity (
	canonical_user_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	dsar_request_id uuid NULL,
	CONSTRAINT user_identity_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text])))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_identity.user_identity for each row execute function cg_identity.set_updated_at();


-- cg_identity.account_identifier definition

CREATE TABLE cg_identity.account_identifier (
	identifier_type text NOT NULL,
	vendor text DEFAULT ''::text NOT NULL,
	identifier_value_hmac text NOT NULL,
	canonical_account_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	CONSTRAINT account_identifier_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text])))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_identity.account_identifier for each row execute function cg_identity.set_updated_at();


-- cg_identity.user_account_membership definition

CREATE TABLE cg_identity.user_account_membership (
	canonical_user_id uuid NOT NULL,
	canonical_account_id uuid NOT NULL,
	role_name text NULL, -- Relationship role from source role_name; NULL when source role is unknown.
	account_user_status text NOT NULL, -- Lifecycle state: active / removed / suspended.
	status_changed_at timestamptz DEFAULT now() NOT NULL, -- When the lifecycle value last changed (source __START_AT).
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL
);

-- Column comments

COMMENT ON COLUMN cg_identity.user_account_membership.role_name IS 'Relationship role from source role_name; NULL when source role is unknown.';
COMMENT ON COLUMN cg_identity.user_account_membership.account_user_status IS 'Lifecycle state: active / removed / suspended.';
COMMENT ON COLUMN cg_identity.user_account_membership.status_changed_at IS 'When the lifecycle value last changed (source __START_AT).';

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_identity.user_account_membership for each row execute function cg_identity.set_updated_at();


-- cg_identity.user_account_membership_history definition

CREATE TABLE cg_identity.user_account_membership_history (
	membership_history_id int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL,
	canonical_user_id uuid NOT NULL,
	canonical_account_id uuid NOT NULL,
	role_name text NULL,
	account_user_status text NOT NULL,
	valid_from timestamptz NOT NULL,
	valid_to timestamptz NULL, -- End of interval; NULL means still current.
	recorded_at timestamptz DEFAULT now() NOT NULL
);
COMMENT ON TABLE cg_identity.user_account_membership_history IS 'Membership status intervals over time; valid_to IS NULL = current.';

-- Column comments

COMMENT ON COLUMN cg_identity.user_account_membership_history.valid_to IS 'End of interval; NULL means still current.';


-- cg_identity.user_identifier definition

CREATE TABLE cg_identity.user_identifier (
	identifier_type text NOT NULL,
	vendor text DEFAULT ''::text NOT NULL,
	identifier_value_hmac text NOT NULL,
	canonical_user_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	CONSTRAINT user_identifier_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text])))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_identity.user_identifier for each row execute function cg_identity.set_updated_at();


-- cg_identity.link_account definition

CREATE OR REPLACE FUNCTION cg_identity.link_account(p_canonical_account_id uuid, p_type text, p_vendor text, p_hmac text)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_existing uuid;
BEGIN
    -- Insert only if the canonical account is active (same CTE trick as link_user).
    WITH active_check AS (
        SELECT canonical_account_id
        FROM   cg_identity.account_identity
        WHERE  canonical_account_id = p_canonical_account_id
          AND  deletion_status      = 'active'
    )
    INSERT INTO cg_identity.account_identifier
        (identifier_type, vendor, identifier_value_hmac, canonical_account_id)
    SELECT p_type, p_vendor, p_hmac, p_canonical_account_id
    FROM   active_check
    ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING;

    IF NOT FOUND THEN
        -- Check whether NOT FOUND means the canonical is gone (error)
        -- or just that the identifier already existed (fall through).
        IF NOT EXISTS (
            SELECT 1 FROM cg_identity.account_identity
            WHERE  canonical_account_id = p_canonical_account_id
              AND  deletion_status      = 'active'
        ) THEN
            RAISE EXCEPTION 'canonical_not_found_or_tombstoned'
                USING ERRCODE = 'P0002',
                      DETAIL  = format('canonical_account_id=%s', p_canonical_account_id);
        END IF;
    END IF;

    -- Make sure the identifier belongs to the expected canonical, not someone else's.
    SELECT canonical_account_id INTO v_existing
    FROM   cg_identity.account_identifier
    WHERE  identifier_type       = p_type
      AND  vendor                = p_vendor
      AND  identifier_value_hmac = p_hmac;

    IF v_existing <> p_canonical_account_id THEN
        RAISE EXCEPTION 'identifier_conflict'
            USING ERRCODE = 'P0003',
                  DETAIL  = format(
                      'identifier_type=%s vendor=%s already linked to canonical_account_id=%s',
                      p_type, p_vendor, v_existing);
    END IF;
END;
$function$
;

-- cg_identity.link_account_identifiers_batch definition

CREATE OR REPLACE FUNCTION cg_identity.link_account_identifiers_batch(p_canonical_ids uuid[], p_types text[], p_vendors text[], p_hmacs text[])
 RETURNS TABLE(idx integer, status text, detail text)
 LANGUAGE plpgsql
AS $function$
#variable_conflict use_column
DECLARE
    v_n int := COALESCE(array_length(p_canonical_ids, 1), 0);
    v_linked int;
BEGIN
    IF v_n = 0 THEN
        RETURN;
    END IF;

    IF COALESCE(array_length(p_types, 1), 0) <> v_n
       OR COALESCE(array_length(p_vendors, 1), 0) <> v_n
       OR COALESCE(array_length(p_hmacs, 1), 0) <> v_n THEN
        RAISE EXCEPTION 'link_account_identifiers_batch array length mismatch'
            USING ERRCODE = '2202E';
    END IF;

    WITH input AS (
        SELECT ord::int AS idx, t.canonical_account_id, t.identifier_type, t.vendor, t.hmac
        FROM unnest(p_canonical_ids, p_types, p_vendors, p_hmacs)
             WITH ORDINALITY AS t(canonical_account_id, identifier_type, vendor, hmac, ord)
    ),
    valid AS (
        SELECT DISTINCT ON (i.identifier_type, i.vendor, i.hmac)
               i.canonical_account_id, i.identifier_type, i.vendor, i.hmac
        FROM input i
        JOIN cg_identity.account_identity ident
          ON ident.canonical_account_id = i.canonical_account_id
         AND ident.deletion_status = 'active'
        ORDER BY i.identifier_type, i.vendor, i.hmac, i.idx
    ),
    ins AS (
        INSERT INTO cg_identity.account_identifier AS ai
            (identifier_type, vendor, identifier_value_hmac, canonical_account_id)
        SELECT v.identifier_type, v.vendor, v.hmac, v.canonical_account_id
        FROM valid v
        ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING
        RETURNING ai.canonical_account_id
    )
    SELECT COUNT(*) INTO v_linked FROM ins;

    RETURN QUERY
    WITH input AS (
        SELECT ord::int AS idx, t.canonical_account_id, t.identifier_type, t.vendor, t.hmac
        FROM unnest(p_canonical_ids, p_types, p_vendors, p_hmacs)
             WITH ORDINALITY AS t(canonical_account_id, identifier_type, vendor, hmac, ord)
    )
    SELECT i.idx,
           CASE
               WHEN ident.canonical_account_id IS NULL THEN 'canonical_missing'
               WHEN ai.canonical_account_id IS NULL THEN 'missing'
               WHEN ai.canonical_account_id <> i.canonical_account_id THEN 'conflict'
               ELSE 'ok'
           END AS status,
           CASE
               WHEN ident.canonical_account_id IS NULL
                   THEN format('canonical_account_id=%s', i.canonical_account_id)
               WHEN ai.canonical_account_id IS NULL
                   THEN format('identifier_type=%s vendor=%s not linked', i.identifier_type, i.vendor)
               WHEN ai.canonical_account_id <> i.canonical_account_id
                   THEN format('identifier_type=%s vendor=%s already linked to canonical_account_id=%s',
                               i.identifier_type, i.vendor, ai.canonical_account_id)
               ELSE NULL
           END AS detail
    FROM input i
    LEFT JOIN cg_identity.account_identity ident
      ON ident.canonical_account_id = i.canonical_account_id
     AND ident.deletion_status = 'active'
    LEFT JOIN cg_identity.account_identifier ai
      ON ai.identifier_type = i.identifier_type
     AND ai.vendor = i.vendor
     AND ai.identifier_value_hmac = i.hmac
    ORDER BY i.idx;
END;
$function$
;

-- cg_identity.link_account_batch definition

CREATE OR REPLACE FUNCTION cg_identity.link_account_batch(p_canonical_account_id uuid, p_types text[], p_vendors text[], p_hmacs text[])
 RETURNS TABLE(idx integer, status text, detail text)
 LANGUAGE sql
AS $function$
    SELECT *
    FROM cg_identity.link_account_identifiers_batch(
        array_fill(p_canonical_account_id, ARRAY[COALESCE(array_length(p_types, 1), 0)]),
        p_types, p_vendors, p_hmacs);
$function$
;


-- cg_identity.link_user definition

CREATE OR REPLACE FUNCTION cg_identity.link_user(p_canonical_user_id uuid, p_type text, p_vendor text, p_hmac text)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_existing uuid;
BEGIN
    -- Try to insert the new identifier, but only if the canonical is active.
    -- We use a CTE so we verify existence and insert in a single statement,
    -- avoiding an extra round-trip to the database.
    -- If the canonical is inactive or missing, the CTE returns no rows and
    -- the INSERT is skipped entirely.
    WITH active_check AS (
        SELECT canonical_user_id
        FROM   cg_identity.user_identity
        WHERE  canonical_user_id = p_canonical_user_id
          AND  deletion_status   = 'active'
    )
    INSERT INTO cg_identity.user_identifier
        (identifier_type, vendor, identifier_value_hmac, canonical_user_id)
    SELECT p_type, p_vendor, p_hmac, p_canonical_user_id
    FROM   active_check
    ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING;

    -- NOT FOUND can mean two things:
    --   (a) The canonical does not exist or is deleted → we must raise an error.
    --   (b) The identifier already existed (ON CONFLICT suppressed the insert)
    --       → we need to check who it belongs to before deciding what to do.
    IF NOT FOUND THEN
        IF NOT EXISTS (
            SELECT 1 FROM cg_identity.user_identity
            WHERE  canonical_user_id = p_canonical_user_id
              AND  deletion_status   = 'active'
        ) THEN
            -- Case (a): the canonical is gone. Raise an error.
            RAISE EXCEPTION 'canonical_not_found_or_tombstoned'
                USING ERRCODE = 'P0002',
                      DETAIL  = format('canonical_user_id=%s', p_canonical_user_id);
        END IF;
        -- Case (b): canonical is fine, identifier already existed. Fall through
        -- to the ownership check below.
    END IF;

    -- Verify that the identifier (whether newly inserted or pre-existing)
    -- belongs to the expected canonical. If it belongs to someone else,
    -- we have a conflict — the same identifier cannot point to two people.
    SELECT canonical_user_id INTO v_existing
    FROM   cg_identity.user_identifier
    WHERE  identifier_type       = p_type
      AND  vendor                = p_vendor
      AND  identifier_value_hmac = p_hmac;

    IF v_existing <> p_canonical_user_id THEN
        RAISE EXCEPTION 'identifier_conflict'
            USING ERRCODE = 'P0003',
                  DETAIL  = format(
                      'identifier_type=%s vendor=%s already linked to canonical_user_id=%s',
                      p_type, p_vendor, v_existing);
    END IF;
END;
$function$
;

-- cg_identity.link_user_identifiers_batch definition

CREATE OR REPLACE FUNCTION cg_identity.link_user_identifiers_batch(p_canonical_ids uuid[], p_types text[], p_vendors text[], p_hmacs text[])
 RETURNS TABLE(idx integer, status text, detail text)
 LANGUAGE plpgsql
AS $function$
#variable_conflict use_column
DECLARE
    v_n int := COALESCE(array_length(p_canonical_ids, 1), 0);
    v_linked int;
BEGIN
    IF v_n = 0 THEN
        RETURN;
    END IF;

    IF COALESCE(array_length(p_types, 1), 0) <> v_n
       OR COALESCE(array_length(p_vendors, 1), 0) <> v_n
       OR COALESCE(array_length(p_hmacs, 1), 0) <> v_n THEN
        RAISE EXCEPTION 'link_user_identifiers_batch array length mismatch'
            USING ERRCODE = '2202E';
    END IF;

    -- Statement 1: attach identifiers whose target canonical exists and is
    -- active. ON CONFLICT DO NOTHING keeps pre-existing owners untouched.
    WITH input AS (
        SELECT ord::int AS idx, t.canonical_user_id, t.identifier_type, t.vendor, t.hmac
        FROM unnest(p_canonical_ids, p_types, p_vendors, p_hmacs)
             WITH ORDINALITY AS t(canonical_user_id, identifier_type, vendor, hmac, ord)
    ),
    valid AS (
        SELECT DISTINCT ON (i.identifier_type, i.vendor, i.hmac)
               i.canonical_user_id, i.identifier_type, i.vendor, i.hmac
        FROM input i
        JOIN cg_identity.user_identity ident
          ON ident.canonical_user_id = i.canonical_user_id
         AND ident.deletion_status = 'active'
        ORDER BY i.identifier_type, i.vendor, i.hmac, i.idx
    ),
    ins AS (
        INSERT INTO cg_identity.user_identifier AS ui
            (identifier_type, vendor, identifier_value_hmac, canonical_user_id)
        SELECT v.identifier_type, v.vendor, v.hmac, v.canonical_user_id
        FROM valid v
        ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING
        RETURNING ui.canonical_user_id
    )
    SELECT COUNT(*) INTO v_linked FROM ins;

    -- Statement 2: read back the owner of every identifier and report the
    -- per-row outcome.
    RETURN QUERY
    WITH input AS (
        SELECT ord::int AS idx, t.canonical_user_id, t.identifier_type, t.vendor, t.hmac
        FROM unnest(p_canonical_ids, p_types, p_vendors, p_hmacs)
             WITH ORDINALITY AS t(canonical_user_id, identifier_type, vendor, hmac, ord)
    )
    SELECT i.idx,
           CASE
               WHEN ident.canonical_user_id IS NULL THEN 'canonical_missing'
               WHEN ui.canonical_user_id IS NULL THEN 'missing'
               WHEN ui.canonical_user_id <> i.canonical_user_id THEN 'conflict'
               ELSE 'ok'
           END AS status,
           CASE
               WHEN ident.canonical_user_id IS NULL
                   THEN format('canonical_user_id=%s', i.canonical_user_id)
               WHEN ui.canonical_user_id IS NULL
                   THEN format('identifier_type=%s vendor=%s not linked', i.identifier_type, i.vendor)
               WHEN ui.canonical_user_id <> i.canonical_user_id
                   THEN format('identifier_type=%s vendor=%s already linked to canonical_user_id=%s',
                               i.identifier_type, i.vendor, ui.canonical_user_id)
               ELSE NULL
           END AS detail
    FROM input i
    LEFT JOIN cg_identity.user_identity ident
      ON ident.canonical_user_id = i.canonical_user_id
     AND ident.deletion_status = 'active'
    LEFT JOIN cg_identity.user_identifier ui
      ON ui.identifier_type = i.identifier_type
     AND ui.vendor = i.vendor
     AND ui.identifier_value_hmac = i.hmac
    ORDER BY i.idx;
END;
$function$
;

-- cg_identity.link_user_batch definition

CREATE OR REPLACE FUNCTION cg_identity.link_user_batch(p_canonical_user_id uuid, p_types text[], p_vendors text[], p_hmacs text[])
 RETURNS TABLE(idx integer, status text, detail text)
 LANGUAGE sql
AS $function$
    SELECT *
    FROM cg_identity.link_user_identifiers_batch(
        array_fill(p_canonical_user_id, ARRAY[COALESCE(array_length(p_types, 1), 0)]),
        p_types, p_vendors, p_hmacs);
$function$
;

-- cg_identity.recover_account definition

CREATE OR REPLACE FUNCTION cg_identity.recover_account(p_type text, p_vendor text, p_hmac text)
 RETURNS uuid
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_id           uuid;
    v_ai_status    text;
    v_ident_status text;
BEGIN
    SELECT ai.canonical_account_id, ai.deletion_status, ident.deletion_status
    INTO   v_id, v_ai_status, v_ident_status
    FROM   cg_identity.account_identifier ai
    JOIN   cg_identity.account_identity   ident USING (canonical_account_id)
    WHERE  ai.identifier_type       = p_type
      AND  ai.vendor                = p_vendor
      AND  ai.identifier_value_hmac = p_hmac;

    IF NOT FOUND THEN
        RETURN NULL;
    END IF;

    IF v_ai_status <> 'active' OR v_ident_status <> 'active' THEN
        RAISE EXCEPTION 'identity_tombstoned'
            USING ERRCODE = 'P0001',
                  DETAIL  = format(
                      'identifier_type=%s vendor=%s identifier_status=%s identity_status=%s',
                      p_type, p_vendor, v_ai_status, v_ident_status);
    END IF;

    RETURN v_id;
END;
$function$
;

-- cg_identity.recover_user definition

CREATE OR REPLACE FUNCTION cg_identity.recover_user(p_type text, p_vendor text, p_hmac text)
 RETURNS uuid
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_id           uuid;
    v_ui_status    text;
    v_ident_status text;
BEGIN
    -- Index-only probe on ux_user_identifier, joined to the identity row to
    -- read both lifecycle flags in one round trip.
    SELECT ui.canonical_user_id, ui.deletion_status, ident.deletion_status
    INTO   v_id, v_ui_status, v_ident_status
    FROM   cg_identity.user_identifier ui
    JOIN   cg_identity.user_identity   ident USING (canonical_user_id)
    WHERE  ui.identifier_type       = p_type
      AND  ui.vendor                = p_vendor
      AND  ui.identifier_value_hmac = p_hmac;

    IF NOT FOUND THEN
        RETURN NULL;                       -- genuine miss; caller may mint
    END IF;

    IF v_ui_status <> 'active' OR v_ident_status <> 'active' THEN
        RAISE EXCEPTION 'identity_tombstoned'
            USING ERRCODE = 'P0001',
                  DETAIL  = format(
                      'identifier_type=%s vendor=%s identifier_status=%s identity_status=%s',
                      p_type, p_vendor, v_ui_status, v_ident_status);
    END IF;

    RETURN v_id;
END;
$function$
;

-- cg_identity.resolve_account definition

CREATE OR REPLACE FUNCTION cg_identity.resolve_account(p_type text, p_vendor text, p_hmac text, p_minted uuid)
 RETURNS uuid
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_id           uuid;
    v_ai_status    text;
    v_ident_status text;
BEGIN
    SELECT ai.canonical_account_id, ai.deletion_status, acct.deletion_status
    INTO   v_id, v_ai_status, v_ident_status
    FROM   cg_identity.account_identifier ai
    JOIN   cg_identity.account_identity   acct USING (canonical_account_id)
    WHERE  ai.identifier_type          = p_type
      AND  ai.vendor                   = p_vendor
      AND  ai.identifier_value_hmac    = p_hmac;

    IF FOUND THEN
        IF v_ai_status <> 'active' OR v_ident_status <> 'active' THEN
            RAISE EXCEPTION 'identity_tombstoned'
                USING ERRCODE = 'P0001',
                      DETAIL  = format(
                          'identifier_type=%s vendor=%s identity_status=%s identifier_status=%s',
                          p_type, p_vendor, v_ident_status, v_ai_status);
        END IF;
        RETURN v_id;
    END IF;

    WITH ins_child AS (
        INSERT INTO cg_identity.account_identifier
            (identifier_type, vendor, identifier_value_hmac, canonical_account_id)
        VALUES (p_type, p_vendor, p_hmac, p_minted)
        ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING
        RETURNING canonical_account_id
    ),
    ins_parent AS (
        INSERT INTO cg_identity.account_identity (canonical_account_id)
        SELECT p_minted WHERE EXISTS (SELECT 1 FROM ins_child)
    )
    SELECT canonical_account_id INTO v_id FROM ins_child;

    IF v_id IS NOT NULL THEN
        RETURN v_id;
    END IF;

    SELECT ai.canonical_account_id, ai.deletion_status, acct.deletion_status
    INTO   v_id, v_ai_status, v_ident_status
    FROM   cg_identity.account_identifier ai
    JOIN   cg_identity.account_identity   acct USING (canonical_account_id)
    WHERE  ai.identifier_type          = p_type
      AND  ai.vendor                   = p_vendor
      AND  ai.identifier_value_hmac    = p_hmac;

    IF v_ai_status <> 'active' OR v_ident_status <> 'active' THEN
        RAISE EXCEPTION 'identity_tombstoned'
            USING ERRCODE = 'P0001',
                  DETAIL  = format(
                      'identifier_type=%s vendor=%s identity_status=%s identifier_status=%s',
                      p_type, p_vendor, v_ident_status, v_ai_status);
    END IF;
    RETURN v_id;
END;
$function$
;

-- cg_identity.resolve_account_batch definition

CREATE OR REPLACE FUNCTION cg_identity.resolve_account_batch(p_types text[], p_vendors text[], p_hmacs text[], p_minted uuid[])
 RETURNS TABLE(idx integer, canonical_account_id uuid, status text)
 LANGUAGE plpgsql
AS $function$
#variable_conflict use_column
DECLARE
    v_n int := COALESCE(array_length(p_types, 1), 0);
    v_inserted int;
BEGIN
    IF v_n = 0 THEN
        RETURN;
    END IF;

    IF COALESCE(array_length(p_vendors, 1), 0) <> v_n
       OR COALESCE(array_length(p_hmacs, 1), 0) <> v_n
       OR COALESCE(array_length(p_minted, 1), 0) <> v_n THEN
        RAISE EXCEPTION 'resolve_account_batch array length mismatch'
            USING ERRCODE = '2202E';
    END IF;

    WITH input AS (
        SELECT ord::int AS idx, t.identifier_type, t.vendor, t.hmac, t.minted
        FROM unnest(p_types, p_vendors, p_hmacs, p_minted)
             WITH ORDINALITY AS t(identifier_type, vendor, hmac, minted, ord)
    ),
    miss AS (
        SELECT DISTINCT ON (i.identifier_type, i.vendor, i.hmac)
               i.identifier_type, i.vendor, i.hmac, i.minted
        FROM input i
        WHERE NOT EXISTS (
            SELECT 1
            FROM cg_identity.account_identifier ai
            WHERE ai.identifier_type = i.identifier_type
              AND ai.vendor = i.vendor
              AND ai.identifier_value_hmac = i.hmac
        )
        ORDER BY i.identifier_type, i.vendor, i.hmac, i.idx
    ),
    ins_child AS (
        INSERT INTO cg_identity.account_identifier AS ai
            (identifier_type, vendor, identifier_value_hmac, canonical_account_id)
        SELECT m.identifier_type, m.vendor, m.hmac, m.minted
        FROM miss m
        ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING
        RETURNING ai.canonical_account_id
    ),
    ins_parent AS (
        INSERT INTO cg_identity.account_identity AS ident (canonical_account_id)
        SELECT DISTINCT ic.canonical_account_id
        FROM ins_child ic
        ON CONFLICT (canonical_account_id) DO NOTHING
        RETURNING ident.canonical_account_id
    )
    SELECT COUNT(*) INTO v_inserted FROM ins_parent;

    RETURN QUERY
    WITH input AS (
        SELECT ord::int AS idx, t.identifier_type, t.vendor, t.hmac
        FROM unnest(p_types, p_vendors, p_hmacs)
             WITH ORDINALITY AS t(identifier_type, vendor, hmac, ord)
    )
    SELECT i.idx,
           CASE
               WHEN ai.canonical_account_id IS NULL THEN NULL
               WHEN ai.deletion_status <> 'active' OR ident.deletion_status <> 'active' THEN NULL
               ELSE ai.canonical_account_id
           END AS canonical_account_id,
           CASE
               WHEN ai.canonical_account_id IS NULL THEN 'missing'
               WHEN ai.deletion_status <> 'active' OR ident.deletion_status <> 'active' THEN 'tombstoned'
               ELSE 'ok'
           END AS status
    FROM input i
    LEFT JOIN cg_identity.account_identifier ai
      ON ai.identifier_type = i.identifier_type
     AND ai.vendor = i.vendor
     AND ai.identifier_value_hmac = i.hmac
    LEFT JOIN cg_identity.account_identity ident
      ON ident.canonical_account_id = ai.canonical_account_id;
END;
$function$
;

-- cg_identity.resolve_user definition

CREATE OR REPLACE FUNCTION cg_identity.resolve_user(p_type text, p_vendor text, p_hmac text, p_minted uuid)
 RETURNS uuid
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_id           uuid;
    v_ui_status    text;  -- deletion status of the identifier row
    v_ident_status text;  -- deletion status of the canonical identity row
BEGIN
    -- STEP 1: Check if we already know this identifier.
    SELECT ui.canonical_user_id, ui.deletion_status, ident.deletion_status
    INTO   v_id, v_ui_status, v_ident_status
    FROM   cg_identity.user_identifier  ui
    JOIN   cg_identity.user_identity    ident USING (canonical_user_id)
    WHERE  ui.identifier_type        = p_type
      AND  ui.vendor                 = p_vendor
      AND  ui.identifier_value_hmac  = p_hmac;

    IF FOUND THEN
        IF v_ui_status <> 'active' OR v_ident_status <> 'active' THEN
            RAISE EXCEPTION 'identity_tombstoned'
                USING ERRCODE = 'P0001',
                      DETAIL  = format(
                          'identifier_type=%s vendor=%s identity_status=%s identifier_status=%s',
                          p_type, p_vendor, v_ident_status, v_ui_status);
        END IF;
        RETURN v_id;
    END IF;

    -- STEP 2: Brand new identifier — race-safe find-or-insert (see V17).
    WITH ins_child AS (
        INSERT INTO cg_identity.user_identifier
            (identifier_type, vendor, identifier_value_hmac, canonical_user_id)
        VALUES (p_type, p_vendor, p_hmac, p_minted)
        ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING
        RETURNING canonical_user_id
    ),
    ins_parent AS (
        INSERT INTO cg_identity.user_identity (canonical_user_id)
        SELECT p_minted WHERE EXISTS (SELECT 1 FROM ins_child)
    )
    SELECT canonical_user_id INTO v_id FROM ins_child;

    IF v_id IS NOT NULL THEN
        RETURN v_id;
    END IF;

    -- STEP 3: Lost the race — re-read the winner's canonical.
    SELECT ui.canonical_user_id, ui.deletion_status, ident.deletion_status
    INTO   v_id, v_ui_status, v_ident_status
    FROM   cg_identity.user_identifier  ui
    JOIN   cg_identity.user_identity    ident USING (canonical_user_id)
    WHERE  ui.identifier_type        = p_type
      AND  ui.vendor                 = p_vendor
      AND  ui.identifier_value_hmac  = p_hmac;

    IF v_ui_status <> 'active' OR v_ident_status <> 'active' THEN
        RAISE EXCEPTION 'identity_tombstoned'
            USING ERRCODE = 'P0001',
                  DETAIL  = format(
                      'identifier_type=%s vendor=%s identity_status=%s identifier_status=%s',
                      p_type, p_vendor, v_ident_status, v_ui_status);
    END IF;
    RETURN v_id;
END;
$function$
;

-- cg_identity.resolve_user_batch definition

CREATE OR REPLACE FUNCTION cg_identity.resolve_user_batch(p_types text[], p_vendors text[], p_hmacs text[], p_minted uuid[])
 RETURNS TABLE(idx integer, canonical_user_id uuid, status text)
 LANGUAGE plpgsql
AS $function$
#variable_conflict use_column
DECLARE
    v_n int := COALESCE(array_length(p_types, 1), 0);
    v_inserted int;
BEGIN
    IF v_n = 0 THEN
        RETURN;
    END IF;

    IF COALESCE(array_length(p_vendors, 1), 0) <> v_n
       OR COALESCE(array_length(p_hmacs, 1), 0) <> v_n
       OR COALESCE(array_length(p_minted, 1), 0) <> v_n THEN
        RAISE EXCEPTION 'resolve_user_batch array length mismatch'
            USING ERRCODE = '2202E';
    END IF;

    -- Statement 1: insert the misses. A tombstoned identifier already has a
    -- row, so NOT EXISTS keeps it out of the mint path. DISTINCT ON collapses
    -- duplicate identifiers within the batch to a single minted UUID.
    -- ON CONFLICT DO NOTHING absorbs concurrent winners from other sessions.
    WITH input AS (
        SELECT ord::int AS idx, t.identifier_type, t.vendor, t.hmac, t.minted
        FROM unnest(p_types, p_vendors, p_hmacs, p_minted)
             WITH ORDINALITY AS t(identifier_type, vendor, hmac, minted, ord)
    ),
    miss AS (
        SELECT DISTINCT ON (i.identifier_type, i.vendor, i.hmac)
               i.identifier_type, i.vendor, i.hmac, i.minted
        FROM input i
        WHERE NOT EXISTS (
            SELECT 1
            FROM cg_identity.user_identifier ui
            WHERE ui.identifier_type = i.identifier_type
              AND ui.vendor = i.vendor
              AND ui.identifier_value_hmac = i.hmac
        )
        ORDER BY i.identifier_type, i.vendor, i.hmac, i.idx
    ),
    ins_child AS (
        INSERT INTO cg_identity.user_identifier AS ui
            (identifier_type, vendor, identifier_value_hmac, canonical_user_id)
        SELECT m.identifier_type, m.vendor, m.hmac, m.minted
        FROM miss m
        ON CONFLICT (identifier_type, vendor, identifier_value_hmac) DO NOTHING
        RETURNING ui.canonical_user_id
    ),
    ins_parent AS (
        INSERT INTO cg_identity.user_identity AS ident (canonical_user_id)
        SELECT DISTINCT ic.canonical_user_id
        FROM ins_child ic
        ON CONFLICT (canonical_user_id) DO NOTHING
        RETURNING ident.canonical_user_id
    )
    SELECT COUNT(*) INTO v_inserted FROM ins_parent;

    -- Statement 2: single read of all N inputs under a fresh snapshot (race
    -- losers now see the committed winner) computing the per-row outcome.
    -- 'missing' is defensive — it means the identifier vanished between the
    -- two statements (concurrent hard delete); callers treat it like a null.
    RETURN QUERY
    WITH input AS (
        SELECT ord::int AS idx, t.identifier_type, t.vendor, t.hmac
        FROM unnest(p_types, p_vendors, p_hmacs)
             WITH ORDINALITY AS t(identifier_type, vendor, hmac, ord)
    )
    SELECT i.idx,
           CASE
               WHEN ui.canonical_user_id IS NULL THEN NULL
               WHEN ui.deletion_status <> 'active' OR ident.deletion_status <> 'active' THEN NULL
               ELSE ui.canonical_user_id
           END AS canonical_user_id,
           CASE
               WHEN ui.canonical_user_id IS NULL THEN 'missing'
               WHEN ui.deletion_status <> 'active' OR ident.deletion_status <> 'active' THEN 'tombstoned'
               ELSE 'ok'
           END AS status
    FROM input i
    LEFT JOIN cg_identity.user_identifier ui
      ON ui.identifier_type = i.identifier_type
     AND ui.vendor = i.vendor
     AND ui.identifier_value_hmac = i.hmac
    LEFT JOIN cg_identity.user_identity ident
      ON ident.canonical_user_id = ui.canonical_user_id;
END;
$function$
;
