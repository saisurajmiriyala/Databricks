-- Databricks OIDC service principal access, parameterized by environment.
-- dev is resolved at deploy time via the Flyway placeholder -placeholders.env=dev|qa|prod

GRANT CONNECT ON DATABASE databricks_postgres TO databricks_postgres_dev;

GRANT CONNECT ON DATABASE databricks_postgres TO chamberlain_dev;

GRANT USAGE ON SCHEMA cg_identity TO chamberlain_dev;
GRANT USAGE ON SCHEMA cg_vault    TO chamberlain_dev;
GRANT USAGE ON SCHEMA cg_audit    TO chamberlain_dev;
GRANT USAGE ON SCHEMA public      TO chamberlain_dev;

-- Schema usage

GRANT USAGE ON SCHEMA cg_identity TO databricks_postgres_dev;
GRANT USAGE ON SCHEMA cg_vault    TO databricks_postgres_dev;
GRANT USAGE ON SCHEMA cg_audit    TO databricks_postgres_dev;
GRANT USAGE ON SCHEMA public      TO databricks_postgres_dev;

-- Table privileges — current tables

GRANT SELECT, INSERT, UPDATE, DELETE                   ON ALL TABLES IN SCHEMA cg_identity TO databricks_postgres_dev;
GRANT SELECT, INSERT, UPDATE, DELETE                   ON ALL TABLES IN SCHEMA cg_vault    TO databricks_postgres_dev;
GRANT SELECT, INSERT                                   ON ALL TABLES IN SCHEMA cg_audit    TO databricks_postgres_dev;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE         ON ALL TABLES IN SCHEMA public       TO databricks_postgres_dev;

-- Table privileges — future tables (a blanket grant above only covers tables
-- that exist at migration time; without this, any table created afterwards
-- has zero Databricks access until someone notices and backfills a grant)

ALTER DEFAULT PRIVILEGES IN SCHEMA cg_identity
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO databricks_postgres_dev;
ALTER DEFAULT PRIVILEGES IN SCHEMA cg_vault
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO databricks_postgres_dev;
ALTER DEFAULT PRIVILEGES IN SCHEMA cg_audit
    GRANT SELECT, INSERT ON TABLES TO databricks_postgres_dev;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON TABLES TO databricks_postgres_dev;


-- Function execution — IDR resolution API used by the ingestion pipeline

GRANT EXECUTE ON FUNCTION cg_identity.link_account(uuid, text, text, text)                           TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.link_account_batch(uuid, text[], text[], text[])               TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.link_account_identifiers_batch(uuid[], text[], text[], text[]) TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.link_user(uuid, text, text, text)                              TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.link_user_batch(uuid, text[], text[], text[])                  TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.link_user_identifiers_batch(uuid[], text[], text[], text[])    TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.recover_account(text, text, text)                              TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.recover_user(text, text, text)                                 TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.resolve_account(text, text, text, uuid)                        TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.resolve_account_batch(text[], text[], text[], uuid[])          TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.resolve_user(text, text, text, uuid)                           TO databricks_postgres_dev;
GRANT EXECUTE ON FUNCTION cg_identity.resolve_user_batch(text[], text[], text[], uuid[])             TO databricks_postgres_dev;

ALTER DEFAULT PRIVILEGES IN SCHEMA cg_identity
    GRANT EXECUTE ON FUNCTIONS TO databricks_postgres_dev;


