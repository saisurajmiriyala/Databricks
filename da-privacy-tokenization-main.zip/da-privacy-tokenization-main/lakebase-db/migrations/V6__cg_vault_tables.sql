-- cg_vault.vault_account_id definition

CREATE TABLE cg_vault.vault_account_id (
	canonical_internal_id uuid NOT NULL,
	identifier_type text NOT NULL,
	real_value text NULL,
	"token" text NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	audit_id int8 NULL,
	CONSTRAINT vault_account_id_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text]))),
	CONSTRAINT vault_account_id_identifier_type_check CHECK ((identifier_type = 'account_id'::text))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_vault.vault_account_id for each row execute function cg_identity.set_updated_at();


-- cg_vault.vault_email definition

CREATE TABLE cg_vault.vault_email (
	canonical_internal_id uuid NOT NULL,
	identifier_type text NOT NULL,
	real_value text NULL,
	"token" text NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	audit_id int8 NULL,
	CONSTRAINT vault_email_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text]))),
	CONSTRAINT vault_email_identifier_type_check CHECK ((identifier_type = 'email'::text))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_vault.vault_email for each row execute function cg_identity.set_updated_at();


-- cg_vault.vault_external_user_id definition

CREATE TABLE cg_vault.vault_external_user_id (
	canonical_internal_id uuid NOT NULL,
	identifier_type text NOT NULL,
	real_value text NULL,
	"token" text NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	audit_id int8 NULL,
	CONSTRAINT vault_external_user_id_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text]))),
	CONSTRAINT vault_external_user_id_identifier_type_check CHECK ((identifier_type = 'external_user_id'::text))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_vault.vault_external_user_id for each row execute function cg_identity.set_updated_at();


-- cg_vault.vault_ip_address definition

CREATE TABLE cg_vault.vault_ip_address (
	canonical_internal_id uuid NOT NULL,
	identifier_type text NOT NULL,
	real_value text NULL,
	"token" text NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	audit_id int8 NULL,
	CONSTRAINT vault_ip_address_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text]))),
	CONSTRAINT vault_ip_address_identifier_type_check CHECK ((identifier_type = 'ip_address'::text))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_vault.vault_ip_address for each row execute function cg_identity.set_updated_at();


-- cg_vault.vault_myq_user_id definition

CREATE TABLE cg_vault.vault_myq_user_id (
	canonical_internal_id uuid NOT NULL,
	identifier_type text NOT NULL,
	real_value text NULL,
	"token" text NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	audit_id int8 NULL,
	CONSTRAINT vault_myq_user_id_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text]))),
	CONSTRAINT vault_myq_user_id_identifier_type_check CHECK ((identifier_type = 'myq_user_id'::text))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_vault.vault_myq_user_id for each row execute function cg_identity.set_updated_at();


-- cg_vault.vault_phone definition

CREATE TABLE cg_vault.vault_phone (
	canonical_internal_id uuid NOT NULL,
	identifier_type text NOT NULL,
	real_value text NULL,
	"token" text NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	updated_at timestamptz DEFAULT now() NOT NULL,
	deletion_status text DEFAULT 'active'::text NOT NULL,
	deleted_at timestamptz NULL,
	deletion_reason text NULL,
	source_system text NULL,
	match_method text NULL,
	match_confidence numeric(4, 3) NULL,
	dsar_request_id uuid NULL,
	audit_id int8 NULL,
	CONSTRAINT vault_phone_deletion_status_check CHECK ((deletion_status = ANY (ARRAY['active'::text, 'tombstoned'::text, 'purged'::text]))),
	CONSTRAINT vault_phone_identifier_type_check CHECK ((identifier_type = 'phone'::text))
);

-- Table Triggers

create trigger trg_set_updated_at before
update
    on
    cg_vault.vault_phone for each row execute function cg_identity.set_updated_at();
