-- cg_audit.detokenize_log definition
CREATE TABLE cg_audit.detokenize_log (
	log_id int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL,
	"timestamp" timestamptz DEFAULT now() NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	requester text NOT NULL,
	approver text NULL,
	reason_code text NOT NULL,
	element_type text NOT NULL,
	"scope" text NULL,
	token_hash bpchar(64) NOT NULL,
	value_hash bpchar(64) NOT NULL,
	session_id uuid NULL,
	api_surface text NULL,
	CONSTRAINT chk_detokenize_log_token_hash_sha256 CHECK ((token_hash ~ '^[0-9a-f]{64}$'::text)),
	CONSTRAINT chk_detokenize_log_value_hash_sha256 CHECK ((value_hash ~ '^[0-9a-f]{64}$'::text))
);
