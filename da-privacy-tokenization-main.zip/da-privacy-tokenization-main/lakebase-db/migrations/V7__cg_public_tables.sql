DROP TABLE IF EXISTS public.customers;
DROP TABLE IF EXISTS public.department;
DROP TABLE IF EXISTS public.gate_user_accounts;
DROP TABLE IF EXISTS public.gate_user_identifier;
DROP TABLE IF EXISTS public.playing_with_lakebase;
DROP TABLE IF EXISTS public.ptk_accountuser;
DROP TABLE IF EXISTS public.ptk_user;
DROP TABLE IF EXISTS public.tax;
DROP TABLE IF EXISTS public.temperature;
DROP TABLE IF EXISTS public.test_stage_dev;
DROP TABLE IF EXISTS public.uam_stage;
DROP TABLE IF EXISTS public.uam_stage_hist;
DROP TABLE IF EXISTS public.user_accounts;
DROP TABLE IF EXISTS public.user_accounts_hist;
DROP TABLE IF EXISTS public.user_identifier;
DROP TABLE IF EXISTS public.user_identifier_hist;
DROP TABLE IF EXISTS public.vault_stage;




-- public.gate_user_accounts definition

CREATE TABLE public.gate_user_accounts (
	account_id text NULL,
	user_id text NULL,
	canonical_account_id uuid NULL,
	canonical_user_id uuid NULL
);

-- public.gate_user_identifier definition

CREATE TABLE public.gate_user_identifier (
	canonical_user_id uuid NULL,
	identifier_value_hmac text NULL,
	identifier_type text NULL,
	vendor text NULL
);

-- public.uam_stage definition

CREATE TABLE public.uam_stage (
	user_hmac text NOT NULL,
	account_hmac text NOT NULL,
	role_name text NULL,
	account_user_status text NOT NULL,
	valid_from timestamptz NOT NULL,
	valid_to timestamptz NULL
);

-- public.user_accounts definition

CREATE TABLE public.user_accounts (
	account_id text NULL,
	user_id text NULL,
	canonical_account_id uuid NULL,
	canonical_user_id uuid NULL
);

-- public.user_identifier definition

CREATE TABLE public.user_identifier (
	canonical_user_id uuid NULL,
	identifier_value_hmac text NULL,
	identifier_type text NULL,
	vendor text NULL
);

-- public.vault_stage definition

CREATE TABLE public.vault_stage (
	identifier_type text NOT NULL,
	real_value text NOT NULL,
	identifier_hmac_value text NOT NULL,
	"token" text NOT NULL
);
