# Databricks notebook source

# DISCOVER_LANDING_TABLES (PRV-56)
# First task of the gate batch job. Lists the tables that exist in the Landing catalog,
# keeps only the ones that changed since the gate last processed them, and queues that
# list in the gate_current_process_batch table, which TOKENIZE_GATE_RUN reads to process
# the tables one by one. There is no allowlist on purpose: everything that lands must go
# through the gate, so the catalog itself is the list of work. TABLE_LIMIT exists only
# to keep test runs small.
#
# What counts as "changed" is the Delta commit version of the source table. It is the only
# signal that moves if, and only if, something was committed to the table. The
# last_altered column of information_schema is NOT usable: it also moves when just the
# metadata changes - the column-tagging job bumps it - so it would send unchanged tables
# through the gate on every sweep.
#
# The version each table was processed at is written by the gate itself, into
# gate_metadata_source, and only after the run finishes cleanly. A table whose run failed
# keeps its old version, so the next sweep picks it up again instead of losing it.
#
# The whole decision is made in SQL: the listing, the changed-since-last-sweep comparison
# and the queueing are plain queries. Python only fetches the per-table commit version,
# because DESCRIBE HISTORY works one table at a time and no catalog view exposes the
# version in bulk.

import concurrent.futures

from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint

# Start tracking what this run does: the logger times the notebook's functions and
# log_checkpoint marks the steps and branches in between. The log volume is resolved
# from the workspace, so no secret widget is needed here.
start_global_notebook_logger()

# No environment defaults on purpose: every value below comes from the job
# configuration (resources/TOKENIZE_GATE_BATCH.yml), so a run can never silently
# point at the wrong catalog.
dbutils.widgets.text("LANDING_CATALOG", "", "Landing catalog to sweep")
# Which part of the catalog to look at. While the gate is being rolled out we point it at
# one schema at a time instead of the whole catalog, which holds hundreds of tables.
# Leave it empty to sweep everything.
dbutils.widgets.text("LANDING_SCHEMA", "", "Only sweep this schema (empty = the whole catalog)")
dbutils.widgets.text("STATE_CATALOG", "", "Catalog holding the gate metadata tables")
dbutils.widgets.text("TARGET_SCHEMA", "", "Schema holding the gate metadata tables")
dbutils.widgets.text("GATE_METADATA_TABLE", "gate_metadata_source", "Processed-versions table")
dbutils.widgets.text("GATE_BATCH_TABLE", "gate_current_process_batch", "Queue table for TOKENIZE_GATE_RUN")
dbutils.widgets.text("TABLE_LIMIT", "5", "Max tables per sweep (0 = all)")
dbutils.widgets.dropdown("FORCE_ALL", "false", ["true", "false"], "Sweep every table, ignoring what was already processed")
# Tables the continuous gate job (TOKENIZE_GATE_STREAMING) owns. The sweep must skip
# them: two gates reading the same table share the same checkpoint, and two writers on
# one bookmark means duplicated rows in the clone.
dbutils.widgets.text("EXCLUDE_TABLES", "", "schema.table owned by the continuous gate job, comma-separated")

LANDING_CATALOG = dbutils.widgets.get("LANDING_CATALOG").strip()
LANDING_SCHEMA = dbutils.widgets.get("LANDING_SCHEMA").strip()
STATE_CATALOG = dbutils.widgets.get("STATE_CATALOG").strip()
TARGET_SCHEMA = dbutils.widgets.get("TARGET_SCHEMA").strip()
TABLE_LIMIT = int(dbutils.widgets.get("TABLE_LIMIT"))
FORCE_ALL = dbutils.widgets.get("FORCE_ALL") == "true"
EXCLUDE_TABLES = {t.strip() for t in dbutils.widgets.get("EXCLUDE_TABLES").split(",") if t.strip()}
assert LANDING_CATALOG, "LANDING_CATALOG is required (the job configuration sets it)"
assert STATE_CATALOG and TARGET_SCHEMA, "STATE_CATALOG and TARGET_SCHEMA are required (the job configuration sets them)"
assert "," not in LANDING_SCHEMA, "LANDING_SCHEMA takes a single schema, or empty for the whole catalog"

# Where the sweep remembers how far each table was processed...
STATE_TABLE = f"{STATE_CATALOG}.{TARGET_SCHEMA}.{dbutils.widgets.get('GATE_METADATA_TABLE').strip()}"
# ...and where it queues the work of the current run for TOKENIZE_GATE_RUN.
BATCH_TABLE = f"{STATE_CATALOG}.{TARGET_SCHEMA}.{dbutils.widgets.get('GATE_BATCH_TABLE').strip()}"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {STATE_CATALOG}.{TARGET_SCHEMA}")
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {STATE_TABLE} (
        source_table   STRING,
        source_version BIGINT,
        swept_at       TIMESTAMP
    ) USING delta
""")
log_checkpoint(f"metadata tables ready in {STATE_CATALOG}.{TARGET_SCHEMA}")

# Every managed table in scope, in a stable order so a capped test sweep picks the same
# tables every time. Narrowing by schema here, and not later, is what keeps the sweep
# from asking hundreds of tables for their version when we only care about one schema.
# The tables the continuous gate job owns are left out in the same query - and never
# silently: the list is printed, so a table missing from the sweep is never a mystery.
scope = f"{LANDING_CATALOG}.{LANDING_SCHEMA}" if LANDING_SCHEMA else LANDING_CATALOG
schema_filter = f"AND table_schema = '{LANDING_SCHEMA}'" if LANDING_SCHEMA else ""
exclude_filter = ""
if EXCLUDE_TABLES:
    print(f"discover: excluded (owned by the continuous gate job): {', '.join(sorted(EXCLUDE_TABLES))}")
    log_checkpoint(f"branch: {len(EXCLUDE_TABLES)} tables excluded (owned by the continuous gate job)")
    exclude_filter = "AND table_schema || '.' || table_name NOT IN ({})".format(
        ", ".join(f"'{name}'" for name in sorted(EXCLUDE_TABLES))
    )
tables = spark.sql(f"""
    SELECT table_schema, table_name
    FROM {LANDING_CATALOG}.information_schema.tables
    WHERE table_type = 'MANAGED'
      AND table_schema <> 'information_schema'
      {schema_filter}
      {exclude_filter}
    ORDER BY table_schema, table_name
""").collect()

# A schema that matches nothing is almost always a typo. Say so instead of reporting a
# clean sweep of zero tables.
assert tables or not LANDING_SCHEMA, (
    f"FAILED: no managed tables in {scope} outside EXCLUDE_TABLES. Check LANDING_SCHEMA, "
    "or leave it empty to sweep the whole catalog."
)
log_checkpoint(f"{len(tables)} managed tables listed in {scope}")


def current_version(row):
    """Latest data-changing Delta commit version of a table, or None when the history
    cannot be read.

    Maintenance commits are skipped: the daily VACUUM / OPTIMIZE pass bumps the version
    of every table without adding a row, and counting those would re-queue the whole
    schema each morning - crowding the real work out of TABLE_LIMIT. The list is a
    blacklist on purpose: an operation we do not recognise counts as a change, so at
    worst a table goes through the gate again rather than PII sitting unprocessed. A
    table whose data commits all aged out of the history returns None and is sent
    through, same as an unreadable history."""
    name = f"{LANDING_CATALOG}.`{row['table_schema']}`.`{row['table_name']}`"
    try:
        return spark.sql(f"""
            SELECT MAX(version) AS version
            FROM (DESCRIBE HISTORY {name})
            WHERE operation NOT IN ('VACUUM START', 'VACUUM END', 'OPTIMIZE', 'COMPUTE STATISTICS')
        """).first()["version"]
    except Exception as error:
        print(f"discover: cannot read the history of {row['table_schema']}.{row['table_name']}: {error}")
        return None


# Kept out of the logger's timing wrapper on purpose: 16 threads calling a wrapped
# function would each rewrite the log file per call, once per table, for hundreds of
# tables. The checkpoint after the pool covers this step in one line.
current_version._is_profiled = True

# One metadata call per table, so ask for them a few at a time instead of one after
# another - the catalog holds hundreds of tables.
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
    versions = list(pool.map(current_version, tables))
log_checkpoint(f"source versions fetched for {len(tables)} tables")

# The fetched versions become a view, so the decision below is a plain SQL query.
spark.createDataFrame(
    [(row["table_schema"], row["table_name"], version) for row, version in zip(tables, versions)],
    "table_schema string, table_name string, source_version bigint",
).createOrReplaceTempView("landing_versions")

# Keep the tables that are new to the gate or that got a new commit since the last sweep.
# A table whose history could not be read keeps a NULL version: it is sent through
# rather than risk leaving personal data sitting in Landing without ever passing the
# gate, and the gate records nothing for it, so the next sweep looks at it again.
spark.sql(f"""
    CREATE OR REPLACE TEMP VIEW landing_changed AS
    SELECT v.table_schema, v.table_name, v.source_version
    FROM landing_versions AS v
    LEFT JOIN {STATE_TABLE} AS s
        ON s.source_table = v.table_schema || '.' || v.table_name
    WHERE {'TRUE' if FORCE_ALL else 'FALSE'}    -- FORCE_ALL ignores the state table
       OR v.source_version IS NULL              -- history unreadable: send it through
       OR s.source_version IS NULL              -- the gate never processed this table
       OR v.source_version > s.source_version   -- new commits since the last sweep
""")

# Queue the work for TOKENIZE_GATE_RUN. Rebuilt from scratch on every sweep, so the
# batch table only ever holds the current run's work list - never a stale one.
spark.sql(f"""
    CREATE OR REPLACE TABLE {BATCH_TABLE} (
        source_catalog STRING,
        source_schema  STRING,
        source_table   STRING,
        source_version BIGINT,
        load_mode      STRING
    ) USING delta
""")
# The sweep always queues incremental runs: the streaming checkpoint is what reads
# just the new commits. Full runs (snapshots, backfill) come from the manual batch
# job, which names its table directly instead of going through this queue.
spark.sql(f"""
    INSERT INTO {BATCH_TABLE}
    SELECT '{LANDING_CATALOG}', table_schema, table_name, source_version, 'incremental'
    FROM landing_changed
    ORDER BY table_schema, table_name
    {f'LIMIT {TABLE_LIMIT}' if TABLE_LIMIT else ''}
""")

# Never let a partial run read as full coverage: say exactly what was left out.
changed = spark.sql("SELECT COUNT(*) AS how_many FROM landing_changed").first()["how_many"]
selected = spark.sql(f"""
    SELECT source_schema, source_table, source_version
    FROM {BATCH_TABLE}
    ORDER BY source_schema, source_table
""").collect()
print(f"discover: {len(tables)} tables in {scope}, {len(tables) - changed} unchanged since the last sweep")
print(f"discover: {changed} to process, sweeping {len(selected)}")
log_checkpoint(f"{changed} tables to process, {len(tables) - changed} unchanged, sweeping {len(selected)}")
if LANDING_SCHEMA:
    print(f"discover: WARNING only schema '{LANDING_SCHEMA}' was looked at, the rest of "
          f"{LANDING_CATALOG} was not swept")
    log_checkpoint(f"branch: only schema '{LANDING_SCHEMA}' was swept")
if FORCE_ALL:
    print("discover: WARNING FORCE_ALL is on, the state table was ignored")
    log_checkpoint("branch: FORCE_ALL on, the state table was ignored")
if len(selected) < changed:
    print(f"discover: WARNING {changed - len(selected)} changed tables skipped by TABLE_LIMIT={TABLE_LIMIT}")
    log_checkpoint(f"branch: TABLE_LIMIT={TABLE_LIMIT} left {changed - len(selected)} changed tables out")
# Prints only inside the loop: a log_checkpoint per selected table gets expensive when
# the whole catalog is swept (each call scans the notebook namespace and writes to the
# log volume), and the queued-summary checkpoint below already marks the step.
for row in selected:
    version_label = row["source_version"] if row["source_version"] is not None else "unknown"
    print(f"discover: {row['source_schema']}.{row['source_table']} (version {version_label})")
print(f"discover: queued {len(selected)} tables in {BATCH_TABLE}")
log_checkpoint(f"{len(selected)} tables queued in {BATCH_TABLE}")
