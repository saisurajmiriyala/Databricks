# Databricks notebook source

# TOKENIZE_GATE_RUN (PRV-57 / PTK-33 / PRV-56)
# One run of the privacy gate. It takes a work list of tables and, for each one, finds
# the personal data by itself, swaps identifiers (emails, phones, ids) for safe tokens,
# blurs sensitive details (birth date, zip code, IP), and saves a clean copy of the
# table where no personal data is left. The same value always gets the same token, so
# joins keep working downstream.
#
# Where the work list comes from:
#   - The batch job: DISCOVER_LANDING_TABLES queues every changed Landing table in the
#     gate_current_process_batch table - one row per table with where it lives, the
#     commit version the discover saw, and the load mode to use. SOURCE_TABLE left
#     empty is what tells this run to read that queue and process its rows one by one.
#   - A direct run (TOKENIZE_GATE_STREAMING): SOURCE_TABLE names one table, LOAD_MODE
#     picks the mode, and the queue is not read at all.
#
# Where the clone lands: RAW_CATALOG.<source schema>.<table> by default - the raw
# catalog mirrors the source schema name, so the raw layout reads like the landing
# layout. CLONE_SCHEMA overrides that with one fixed schema for every clone (dev pins
# it to 'privacy' while the gate is validated; qa/prod leave it empty and mirror).
# The gate's own state lives apart from the clones, all of it in
# STATE_CATALOG.TARGET_SCHEMA: the queue, the processed-versions table and the
# gate_checkpoints volume - dev points STATE_CATALOG at the audit-log catalog,
# qa/prod at their raw catalog.
#
# Two load modes:
#   - full: read the whole table, overwrite the clone. For snapshots and backfill.
#   - incremental: read only the rows added since the last run (the checkpoint is the
#     bookmark), append them to the clone. For append-only Landing tables. The bookmark
#     only advances when a batch finishes cleanly, so nothing is missed and nothing is
#     processed twice.
#
# Note: the gate stages identities in its own public.gate_user_identifier /
# public.gate_user_accounts tables (V49__gate_staging_tables.sql) - separate from the
# ones IDR stages into, so the two jobs no longer collide. The gate's jobs (the batch
# job and the streaming job) still share those tables, so they must not overlap -
# max_concurrent_runs=1 covers each job on its own, not across the two.
# Within one run the tables go through strictly one after another, and every staging
# load wipes the staging table before use, so one table's rows never leak into the
# next one's. Those staging loads go through the shared lakebase-utils loaders, picked
# by batch size: load_uc_to_lakebase (bulk, on the executors) for a full run and for
# the first pass over a table, ptk_write_dataframe (driver-side) for the incremental
# batches after that.

# COMMAND ----------

import os

# Create the input boxes for the job: where to read and where to write. No environment
# defaults on purpose: every value comes from the job configuration (resources/*.yml),
# so a run can never silently point at the wrong catalog. The only defaults kept are
# behavioural, not environmental: DRY_RUN defaults to safe. The database credentials
# take no widgets at all - see the secrets block below.
dbutils.widgets.text("SOURCE_CATALOG", "", "Source catalog (direct runs)")
dbutils.widgets.text("SOURCE_SCHEMA", "", "Source schema (direct runs)")
dbutils.widgets.text("SOURCE_TABLE", "", "Source table (empty = process the queued batch)")
dbutils.widgets.text("RAW_CATALOG", "", "Raw layered catalog (clones land here)")
dbutils.widgets.text("CLONE_SCHEMA", "", "Fixed schema for the clones (empty = mirror the source schema)")
dbutils.widgets.text("STATE_CATALOG", "", "Catalog holding the gate state (metadata tables, checkpoints)")
dbutils.widgets.text("TARGET_SCHEMA", "", "Schema holding the gate metadata tables")
dbutils.widgets.text("GATE_METADATA_TABLE", "gate_metadata_source", "Processed-versions table")
dbutils.widgets.text("GATE_BATCH_TABLE", "gate_current_process_batch", "Queue table written by the discover task")
dbutils.widgets.dropdown("DRY_RUN", "true", ["true", "false"], "Dry run (skip writes to Raw)")
dbutils.widgets.dropdown("LOAD_MODE", "full", ["full", "incremental"], "Load mode for direct runs (queued tables carry their own)")
dbutils.widgets.text("IDR_SCHEMA", "", "IDR schema in Lakebase")

# COMMAND ----------

# Read what the user typed in the boxes.
SOURCE_CATALOG = dbutils.widgets.get("SOURCE_CATALOG").strip()
SOURCE_SCHEMA = dbutils.widgets.get("SOURCE_SCHEMA").strip()
SOURCE_TABLE = dbutils.widgets.get("SOURCE_TABLE").strip()
RAW_CATALOG = dbutils.widgets.get("RAW_CATALOG").strip()
CLONE_SCHEMA = dbutils.widgets.get("CLONE_SCHEMA").strip()
STATE_CATALOG = dbutils.widgets.get("STATE_CATALOG").strip()
TARGET_SCHEMA = dbutils.widgets.get("TARGET_SCHEMA").strip()
DRY_RUN = dbutils.widgets.get("DRY_RUN") == "true"
LOAD_MODE = dbutils.widgets.get("LOAD_MODE").strip()

# How many rows detection samples to confirm a column's content. Fixed: it is a
# detection internal, not an operational knob.
SAMPLE_ROWS = 1000
IDR_SCHEMA = dbutils.widgets.get("IDR_SCHEMA").strip()
assert "," not in SOURCE_TABLE, (
    "SOURCE_TABLE takes a single table; leave it empty to process the queued batch"
)
assert LOAD_MODE in ("full", "incremental"), f"LOAD_MODE must be full or incremental, got '{LOAD_MODE}'"
assert RAW_CATALOG and STATE_CATALOG and TARGET_SCHEMA, (
    "RAW_CATALOG, STATE_CATALOG and TARGET_SCHEMA are required (the job configuration sets them)"
)
assert IDR_SCHEMA, "IDR_SCHEMA is required (the job configuration sets it)"
assert not SOURCE_TABLE or (SOURCE_CATALOG and SOURCE_SCHEMA), (
    "SOURCE_CATALOG and SOURCE_SCHEMA are required when SOURCE_TABLE is set"
)

# Tell the identity library which schema to use (must happen before importing it).
os.environ["IDR_SCHEMA"] = IDR_SCHEMA

# COMMAND ----------

# Bring in the tools this notebook uses.
import uuid
import pandas as pd

from pyspark.sql import functions as F
from lakebase_utils.gate.detection import detect_treatments, MATCH_THRESHOLD, VALUE_RE, VENDOR_KEYWORDS
from lakebase_utils.idr.resolution import load_peppers
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
# ptk_read_dataframe is avoided on purpose: the shared connection returns dict rows,
# and pd.read_sql_query iterates each dict as its KEYS - every cell silently becomes
# the column name. ptk_fetchall hands the dict rows back untouched.
from lakebase_utils.postgres.connection import ptk_connect
from lakebase_utils.postgres.queryhub import ptk_execute, ptk_fetchone
# Modules, not names, for two kinds of functions the logger's timing wrapper must
# never touch (a module attribute is never wrapped):
# - everything run_gate and stage_into_lakebase call: those two functions travel into
#   the foreachBatch process, and the wrapper carries the IPython shell, which cannot
#   be serialized there;
# - hmac_util: the wrapper prints a function's first argument into the log, and
#   compute_hmac_or_none takes the secret pepper first - wrapped, it would write the
#   pepper in plaintext to the log volume, once per sampled value.
from lakebase_utils import generalize
from lakebase_utils.idr import hmac_util, normalize, resolution
from lakebase_utils.postgres import bulkload, connection, queryhub, vault

# Start tracking what this run does. The logger times every notebook-level function,
# and log_checkpoint marks the steps in between. The functions that travel into
# foreachBatch are kept out of its reach - see run_gate for how and why.
start_global_notebook_logger()

# Keep each violation tied to the Databricks job run that detected it. Interactive
# notebook runs do not have a job run id, so give those a unique id of their own.
try:
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    RUN_ID = (
        str(ctx.currentRunId().get().id())
        if ctx.currentRunId().isDefined()
        else str(uuid.uuid4())
    )
except Exception:
    RUN_ID = str(uuid.uuid4())
log_checkpoint(f"run_id: {RUN_ID}")

# Violations contain the full offending source row as JSON. Keeping the evidence in
# one append-only table gives every source shape a stable audit schema.
AUDIT_LEAK_SCHEMA = "privacy"
AUDIT_LEAK_TABLE = f"{STATE_CATALOG}.{AUDIT_LEAK_SCHEMA}.pii_leak_log"
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {STATE_CATALOG}.{AUDIT_LEAK_SCHEMA}")
spark.sql(f"""CREATE TABLE IF NOT EXISTS {AUDIT_LEAK_TABLE} (
    checked_at TIMESTAMP, run_id STRING, source_catalog STRING, source_schema STRING,
    source_table STRING, column_name STRING, violation_type STRING, severity STRING,
    record STRING) USING DELTA
    TBLPROPERTIES ('delta.appendOnly' = 'true')""")

# Read the database credentials once, on the driver. No widgets involved: the secret
# scope is resolved from the workspace and the key names follow from it - the same way
# the vault and IDR notebooks read them. Kept as plain strings in a dict because
# run_gate re-connects from them inside foreachBatch, where dbutils does not exist.
SECRET_SCOPE = hmac_util.fetch_secret_scope()
LAKEBASE_CREDENTIALS = connection.fetch_lakebase_credentials()
# The pepper reads the same scope; pinned here so every later lookup agrees.
os.environ["IDR_PEPPER_SECRET_SCOPE"] = SECRET_SCOPE

# Connection for the queries this notebook sends from the driver.
ptk_connect(**LAKEBASE_CREDENTIALS)

# Fixed settings: which vault table and token prefix belongs to each kind of identifier.
VAULTS = {
    "email":            ("cg_vault.vault_email",            "eml_"),
    "phone":            ("cg_vault.vault_phone",            "phn_"),
    "myq_user_id":      ("cg_vault.vault_myq_user_id",      "usr_"),
    "account_id":       ("cg_vault.vault_account_id",       "acc_"),
    "external_user_id": ("cg_vault.vault_external_user_id", "xui_"),
}
SOURCE_SYSTEM = "tokenize_gate_batch"


def stage_into_lakebase(source_df, target_table):
    """Empty a gate staging table and load this batch's rows into it.

    Returns how many rows were staged.

    Module-qualified library calls on purpose: this function travels with run_gate
    into the foreachBatch process - see the import block at the top.
    """
    if BULK_STAGING:
        # "gate batch" is just the label the loader prints. mode="delete" because
        # TRUNCATE is not allowed on Lakebase. 8 connections at a time, fewer than the
        # loader's default, so the database is not overwhelmed.
        return bulkload.load_uc_to_lakebase(
            "gate batch",
            target_table,
            source_df=source_df,
            mode="delete",
            repartition=8,
        )["rows_written"]

    # Bring the rows over first, empty the table after: if bringing them fails, the
    # table still has its previous contents instead of being left empty.
    # Pandas on purpose: for a few thousand rows, one connection and one COPY finish
    # before the distributed loader is done opening its eight.
    staged = source_df.toPandas()
    queryhub.ptk_execute(f"DELETE FROM {target_table}")
    queryhub.ptk_write_dataframe(staged, target_table)
    return len(staged)


# Keep the logger's timing wrapper off this function: it is serialized into the
# foreachBatch process, and the wrapper carries the IPython shell, which cannot be
# serialized there.
stage_into_lakebase._is_profiled = True

# Where the identity graph keeps each kind of identifier it already knows.
GRAPH_TABLES = {
    "myq_user_id": "user_identifier",
    "email": "user_identifier",
    "phone": "user_identifier",
    "external_user_id": "user_identifier",
    "account_id": "account_identifier",
}


def confirm_detections(proposals):
    """Double-check the columns detection wants to tokenize. Can only take columns off
    the list, never add one.

    Two questions per column:
    - Do the values look like real myQ ids? Catches columns whose name says "account id"
      but whose values are free text like 'demo' or 'testimport'.
    - Does the identity graph already know these values? This is the only way to tell a
      real user id apart from any other id, because in these tables everything looks the
      same (UUIDs everywhere).

    When there is not enough to judge with, the column is left as detection proposed it.
    Every decision is printed.
    """
    candidates = [p for p in proposals if p["action"] == "tokenize" and p["target"] in GRAPH_TABLES]
    if not candidates:
        return proposals

    # Take a random sample of the columns to check (random, so a mostly-empty column
    # still shows its values). _source_system comes along when the table has it, to
    # tell below where the table's data comes from.
    sample_cols = [p["column"] for p in candidates] + (
        ["_source_system"] if "_source_system" in source_columns else []
    )
    sampled = (
        spark.table(fq_source)
        .select([F.col(c).cast("string").alias(c) for c in sample_cols])
        .orderBy(F.rand())
        .limit(SAMPLE_ROWS)
        .toPandas()
    )

    # Is this table ours (myQ) or from an outside system like Braze or Salesforce?
    # Outside systems write their ids in their own format, so the "does it look like a
    # myQ id" question only makes sense for our own tables.
    hint = fq_source.lower()
    if "_source_system" in sampled.columns:
        hint += " " + " ".join(str(v).lower() for v in sampled["_source_system"].dropna().unique()[:5])
    table_vendor = next((v for v in VENDOR_KEYWORDS if v in hint), None)

    # Does the graph know enough of each kind of identifier to have an opinion? Counting
    # the whole table would mean reading millions of rows; stopping at 1000 answers the
    # only question we have.
    populations = {}
    for element in {p["target"] for p in candidates}:
        row = ptk_fetchone(
            f"""SELECT count(*) AS n FROM (
                    SELECT 1 FROM "{IDR_SCHEMA}".{GRAPH_TABLES[element]}
                    WHERE identifier_type = %s AND deletion_status = 'active'
                    LIMIT 1000
                ) AS sample""",
            (element,),
        )
        populations[element] = int(next(iter(row.values())) if row else 0)

    confirmed = []
    for proposal in proposals:
        if proposal not in candidates:
            confirmed.append(proposal)
            continue

        column, element = proposal["column"], proposal["target"]
        values = [str(v).strip() for v in sampled[column].dropna().tolist() if str(v).strip()]
        if not values:
            confirmed.append(proposal)
            continue

        # First question: do the values look like real myQ ids? Only asked for account
        # ids in our own tables (outside systems use their own formats).
        if element == "account_id" and not proposal["vendor"] and not table_vendor:
            shaped = sum(bool(VALUE_RE["myq_user_id"].match(v)) for v in values) / len(values)
            if shaped < MATCH_THRESHOLD:
                print(f"detect: DROPPED '{column}' - only {shaped:.1%} of its values look "
                      f"like an account id minted by myQ")
                confirmed.append({**proposal, "action": "pass", "target": None,
                                  "signal": f"shape_unconfirmed:{element}",
                                  "match_ratio": round(shaped, 3)})
                continue

        # Second question: does the graph already know these values? Only asked when the
        # graph has at least 1000 of that kind - with less than that it has no basis to
        # say no, and saying no wrongly would leave real personal data unprotected.
        if populations[element] < 1_000 or element not in PEPPERS:
            print(f"detect: '{column}' not graph-checked "
                  f"(graph holds {populations[element]} '{element}' rows)")
            confirmed.append(proposal)
            continue

        hashed = {h for h in (hmac_util.compute_hmac_or_none(PEPPERS[element], element, v) for v in values) if h}
        if not hashed:
            confirmed.append(proposal)
            continue
        # vendor is part of the lookup so each value is a direct index hit instead of a
        # walk over every stored identifier of this type.
        row = ptk_fetchone(
            f"""SELECT count(DISTINCT identifier_value_hmac) AS n
                FROM "{IDR_SCHEMA}".{GRAPH_TABLES[element]}
                WHERE identifier_type = %s AND vendor = %s AND deletion_status = 'active'
                  AND identifier_value_hmac = ANY(%s)""",
            (element, proposal["vendor"] or "", list(hashed)),
        )
        known = int(next(iter(row.values())) if row else 0) / len(hashed)

        # Any exact hit confirms the column. An HMAC match has no false positives: k
        # matches are k real registered identifiers sitting in this column, and
        # dropping it would send them to Raw in plaintext - the one failure this gate
        # exists to prevent. A real identifier column can still score low when the
        # graph's coverage is partial (sources not yet ingested, brand-new users,
        # service accounts), so no ratio is low enough to justify a veto. The graph
        # only vetoes when it recognises NONE of up to 1000 sampled values while
        # holding at least 1000 identifiers of that type - that is what says "a
        # different kind of id that just looks the same". The cost of the opposite
        # mistake is only some spurious identities registered in the graph.
        if known > 0:
            print(f"detect: '{column}' confirmed by the graph ({known:.1%} of its values are known {element}s)")
            confirmed.append({**proposal, "signal": f"name+graph:{element}",
                              "match_ratio": round(known, 3)})
        else:
            # Right name, right look, but the graph has met none of these values - so
            # it is some other kind of id that just looks the same.
            print(f"detect: DROPPED '{column}' - the graph knows none of its "
                  f"{len(hashed)} sampled values as {element}s")
            confirmed.append({**proposal, "action": "pass", "target": None,
                              "signal": f"graph_unknown:{element}", "match_ratio": round(known, 3)})

    return confirmed


# The gate never decides that two identifiers belong to the same person. Each one is
# handled on its own. Saying who is who is another job's work (PRV-19), fed by the real
# identity systems - not guessed from what happens to sit together in a row. The guess
# is often wrong: a record is usually created by one person and edited later by another,
# and joining them would register two people as one, for good. If a link is missing from
# the graph, it gets fixed there, not here.

def run_gate(df):
    """Steps 4-12 on one batch of rows: hash, honour delete-me, resolve identities,
    tokenize, generalize, and prove no real value survived. Returns the tokens-only
    clone of the batch.

    In full mode the batch is the whole table; in incremental mode it is one micro-batch
    of newly added rows. Every step is idempotent (the graph and the vault find-or-insert,
    the staging is wiped before use), so re-running a batch after a failure is harmless.

    Self-contained on purpose: in incremental mode this runs inside foreachBatch, which
    serverless executes in a separate Python process. The notebook's global Spark session,
    dbutils and database connection do not exist there - so the session comes from the
    batch itself, the connection is re-established from the plain credential strings, and
    every library call is module-qualified (see the import block at the top). The prints
    are the batch's log: no log_checkpoint in here, because it does nothing in the
    foreachBatch process (no notebook shell) and on the driver each call costs a full
    namespace scan plus a volume write - too much once per column.
    """

    spark = df.sparkSession
    # Re-establish the Lakebase connection in whichever process runs this batch.
    connection.ptk_connect(**LAKEBASE_CREDENTIALS)

    counts = None

    if tokenize_map:
        # 4. Turn each identifier into a safe, anonymous key (nobody can read the real
        #    value from it). No caching here on purpose: serverless rejects persist/cache,
        #    so the batch size (maxBytesPerTrigger) is what keeps the recomputation of
        #    these UDFs affordable.
        df = resolution.add_hmacs(
            df, [(c, e, f"{c}__hmac") for c, e in tokenize_map.items()], peppers=PEPPERS
        )

        # 5. Count the rows and, per column, how many real values it holds - all in one pass,
        #    because the key step above is a Python UDF that every pass re-runs. Taken before
        #    the delete-me step, so these are the numbers the batch arrived with. The vault
        #    step and the safety checks below compare against them to tell a column that was
        #    always empty from one that lost its values on the way.
        count_columns = [F.count(F.lit(1)).alias("n_rows")]
        for column in tokenize_map:
            count_columns.append(F.count(F.col(column)).alias(f"values_{column}"))
        counts = df.agg(*count_columns).first()

        # 6. Honour delete-me / DSAR. If any identifier of a row belongs to a person or an
        #    account that was deleted, the whole row is dropped here: it is not tokenized,
        #    it never reaches Raw, and no new identity is created for it. This happens
        #    before anything is written, so a deleted person is never brought back.
        deleted_keys = queryhub.ptk_fetchall("""
            SELECT ui.identifier_value_hmac
            FROM cg_identity.user_identifier ui
            LEFT JOIN cg_identity.user_identity u ON u.canonical_user_id = ui.canonical_user_id
            WHERE ui.deletion_status <> 'active'
               OR COALESCE(u.deletion_status, 'active') <> 'active'
            UNION
            SELECT ai.identifier_value_hmac
            FROM cg_identity.account_identifier ai
            LEFT JOIN cg_identity.account_identity a ON a.canonical_account_id = ai.canonical_account_id
            WHERE ai.deletion_status <> 'active'
               OR COALESCE(a.deletion_status, 'active') <> 'active'
        """)
        if deleted_keys:
            # Through pandas (Arrow), like every other read-back in this notebook.
            deleted = spark.createDataFrame(
                pd.DataFrame(deleted_keys, columns=["identifier_value_hmac"]).astype("string"),
                "identifier_value_hmac string",
            )
            for column in tokenize_map:
                df = df.join(
                    deleted,
                    F.col(f"{column}__hmac") == deleted.identifier_value_hmac,
                    "left_anti",
                )
            # How many rows were dropped is NOT counted here on purpose: it would be a
            # full extra pass over the batch, re-running the HMAC UDFs, just to log a
            # number. The per-column kept counts at the end already show the effect.
            print(f"delete-me: {len(deleted_keys)} tombstoned identifiers excluded")

    if user_cols:
        # 7. Find each person in the identity graph: anyone we already know keeps their
        #    id, anyone new gets a fresh one. One identifier at a time - see the note
        #    above this function for why the gate never joins them.

        # One row per identifier found in the batch: what it is and where it came from.
        identifier_structs = []
        for column, element in user_cols.items():
            identifier_structs.append(
                F.struct(
                    F.col(f"{column}__hmac").alias("identifier_value_hmac"),
                    F.lit(vendor_map[column]).alias("vendor"),
                    F.lit(element).alias("identifier_type"),
                )
            )
        # Each identifier gets its own fresh id. The database step below groups by that
        # id, so separate ids is what keeps two people from being merged into one.
        staged_identifiers = (
            df.select(F.explode(F.array(*identifier_structs)).alias("identifier"))
            .select("identifier.*")
            .where(F.col("identifier_value_hmac").isNotNull())
            .dropDuplicates(["identifier_type", "vendor", "identifier_value_hmac"])
            .withColumn("canonical_user_id", F.expr("uuid()"))
        )

        # Empty the staging area and load this batch of people into the database.
        staged = stage_into_lakebase(staged_identifiers, "public.gate_user_identifier")
        print(f"identity: staged {staged} identifier rows")

        # If we have seen any of a person's identifiers before, the stored canonical
        # wins (the official user id first); otherwise the person is new and keeps its
        # freshly minted candidate. Each INSERT below resolves this inline with window
        # functions, in a single pass over staging - no shared CTE: a CTE that holds the
        # resolved batch gets materialized and spills to disk once the identity tables
        # grow. An UPDATE back into staging is no better - it rewrites every staged row
        # in random order, one remote page read per row on Lakebase, with an hours-long
        # row-lock window that deadlocks concurrent writers. Staging is read-only from
        # here on.

        # Add the people we have never seen before to the identity list.
        queryhub.ptk_execute("""
            INSERT INTO "cg_identity".user_identity (canonical_user_id)
            SELECT DISTINCT r.canonical_user_id
            FROM (
                SELECT COALESCE(
                           MIN(e.canonical_user_id::text) FILTER (WHERE e.identifier_type = 'myq_user_id')
                               OVER (PARTITION BY s.canonical_user_id),
                           MIN(e.canonical_user_id::text)
                               OVER (PARTITION BY s.canonical_user_id),
                           s.canonical_user_id::text
                       )::uuid AS canonical_user_id
                FROM "public".gate_user_identifier s
                LEFT JOIN "cg_identity".user_identifier e
                       ON e.identifier_type       = s.identifier_type
                      AND e.vendor                = COALESCE(s.vendor, '')
                      AND e.identifier_value_hmac = s.identifier_value_hmac
                      AND e.deletion_status       = 'active'
            ) AS r
            LEFT JOIN "cg_identity".user_identity AS ii
                ON ii.canonical_user_id = r.canonical_user_id
            WHERE ii.canonical_user_id IS NULL
        """)

        # Save the identifiers we did not have stored yet.
        queryhub.ptk_execute(f"""
            INSERT INTO "cg_identity".user_identifier
                (canonical_user_id, identifier_value_hmac, identifier_type, vendor,
                 source_system, match_method, match_confidence)
            SELECT DISTINCT r.canonical_user_id, r.identifier_value_hmac, r.identifier_type,
                   r.vendor, '{SOURCE_SYSTEM}', 'deterministic', 1.000
            FROM (
                SELECT s.identifier_value_hmac,
                       s.identifier_type,
                       COALESCE(s.vendor, '') AS vendor,
                       COALESCE(
                           MIN(e.canonical_user_id::text) FILTER (WHERE e.identifier_type = 'myq_user_id')
                               OVER (PARTITION BY s.canonical_user_id),
                           MIN(e.canonical_user_id::text)
                               OVER (PARTITION BY s.canonical_user_id),
                           s.canonical_user_id::text
                       )::uuid AS canonical_user_id
                FROM "public".gate_user_identifier s
                LEFT JOIN "cg_identity".user_identifier e
                       ON e.identifier_type       = s.identifier_type
                      AND e.vendor                = COALESCE(s.vendor, '')
                      AND e.identifier_value_hmac = s.identifier_value_hmac
                      AND e.deletion_status       = 'active'
            ) AS r
            LEFT JOIN "cg_identity".user_identifier AS ii
                ON ii.identifier_value_hmac = r.identifier_value_hmac
                AND ii.identifier_type      = r.identifier_type
                AND ii.vendor               = r.vendor
            WHERE ii.canonical_user_id IS NULL
        """)

        # Bring back the final person ids and attach them to the rows of the table. Read
        # from cg_identity, not the staging table: staging never receives the resolved id
        # any more, but by now every identifier of this batch - new or already known - has
        # its correct canonical sitting in cg_identity.user_identifier. The rows go through
        # pandas, not a Python list: createDataFrame on a list pickles it row by row, which
        # is what dominates the runtime once a batch resolves millions of identities.
        # Pandas hands Spark one Arrow transfer instead.
        person_rows = pd.DataFrame(
            queryhub.ptk_fetchall("""
                SELECT DISTINCT s.identifier_value_hmac, ui.canonical_user_id::text AS canonical_user_id
                FROM public.gate_user_identifier s
                JOIN cg_identity.user_identifier ui
                    ON ui.identifier_type       = s.identifier_type
                   AND ui.vendor                = COALESCE(s.vendor, '')
                   AND ui.identifier_value_hmac = s.identifier_value_hmac
                WHERE ui.deletion_status = 'active'
            """),
            columns=["identifier_value_hmac", "canonical_user_id"],
        ).astype("string")
        person_map = spark.createDataFrame(
            person_rows, "identifier_value_hmac string, canonical_user_id string"
        )
        # Attach the person id next to each column, one by one. A row has no single
        # "owner" - two of its columns can be two different people - so every column
        # gets the id of the value it actually holds.
        for column in user_cols:
            keyed = person_map.select(
                F.col("identifier_value_hmac").alias(f"__key__{column}"),
                F.col("canonical_user_id").alias(f"canonical_user_id__{column}"),
            )
            df = df.join(
                keyed, F.col(f"{column}__hmac") == F.col(f"__key__{column}"), "left"
            ).drop(f"__key__{column}")

        # How many identities came back to join on. Counted on the map, which is already
        # in the driver, instead of on the batch: counting the batch would be another full
        # pass re-running the HMAC UDFs. An empty map is the one failure worth naming here,
        # because then no person column can be tokenized at all.
        print(f"identity: {len(person_rows)} identities read back for the join")
        assert len(person_rows), "FAILED: no identity came back from the staging table"

    if account_cols:
        # 8. Same for accounts. The staged pairs still carry the person next to each
        #    account, but only the account is resolved here: who belongs to which
        #    account is kept by the IDR membership job, not by the gate.
        pair_structs = []
        for account_column in account_cols:
            account_key = F.col(f"{account_column}__hmac")
            if user_cols:
                for user_column in user_cols:
                    pair_structs.append(F.struct(
                        account_key.alias("account_id"),
                        F.col(f"{user_column}__hmac").alias("user_id"),
                        F.col(f"canonical_user_id__{user_column}").alias("canonical_user_id"),
                    ))
            else:
                pair_structs.append(F.struct(
                    account_key.alias("account_id"),
                    F.lit(None).cast("string").alias("user_id"),
                    F.lit(None).cast("string").alias("canonical_user_id"),
                ))

        staged_accounts = (
            df.select(F.explode(F.array(*pair_structs)).alias("pair"))
            .select("pair.*")
            .where(F.col("account_id").isNotNull())
            .distinct()
            # Fresh id per pair; the database step below keeps one per account.
            .withColumn("canonical_account_id", F.expr("uuid()"))
        )
        # Same staging pattern as the people step above.
        stage_into_lakebase(staged_accounts, "public.gate_user_accounts")

        # Add the accounts we have never seen before to the account list.
        queryhub.ptk_execute("""
            INSERT INTO "cg_identity".account_identity (canonical_account_id)
            SELECT min(ua.canonical_account_id::text)::uuid
            FROM "public".gate_user_accounts AS ua
            LEFT JOIN "cg_identity".account_identifier AS ai
                ON ai.identifier_value_hmac = ua.account_id
                AND ai.identifier_type = 'account_id'
                AND ai.deletion_status = 'active'
            WHERE ai.canonical_account_id IS NULL AND ua.account_id IS NOT NULL
            GROUP BY ua.account_id
        """)

        # Save the account identifiers we did not have stored yet.
        queryhub.ptk_execute(f"""
            INSERT INTO "cg_identity".account_identifier
                (canonical_account_id, identifier_value_hmac, identifier_type, vendor,
                 source_system, match_method, match_confidence)
            SELECT min(ua.canonical_account_id::text)::uuid, ua.account_id, 'account_id', '',
                   '{SOURCE_SYSTEM}', 'deterministic', 1.000
            FROM "public".gate_user_accounts AS ua
            LEFT JOIN "cg_identity".account_identifier AS ai
                ON ai.identifier_value_hmac = ua.account_id
                AND ai.identifier_type = 'account_id'
                AND ai.vendor = ''
                AND ai.deletion_status = 'active'
            WHERE ai.canonical_account_id IS NULL AND ua.account_id IS NOT NULL
            GROUP BY ua.account_id
        """)

        # Bring back the final account ids and attach them to the rows of the table,
        # through pandas for the same reason as the person map above.
        account_rows = pd.DataFrame(
            queryhub.ptk_fetchall("""
                SELECT DISTINCT ua.account_id, ai.canonical_account_id::text AS canonical_account_id
                FROM public.gate_user_accounts ua
                JOIN cg_identity.account_identifier ai
                  ON ai.identifier_value_hmac = ua.account_id
                 AND ai.identifier_type = 'account_id'
                 AND ai.deletion_status = 'active'
            """),
            columns=["account_id", "canonical_account_id"],
        ).astype("string")
        account_map = spark.createDataFrame(
            account_rows, "account_key string, canonical_account_id string"
        )
        # One canonical column per account column, same as the people above.
        for column in account_cols:
            keyed = account_map.select(
                F.col("account_key").alias(f"__key__{column}"),
                F.col("canonical_account_id").alias(f"canonical_account_id__{column}"),
            )
            df = df.join(
                keyed, F.col(f"{column}__hmac") == F.col(f"__key__{column}"), "left"
            ).drop(f"__key__{column}")

        # The person-account relationship is NOT written from here. The table that held
        # it (user_account_edge) was removed from the database in V58: the graph keeps
        # that relationship in user_account_membership, maintained by the IDR membership
        # job together with its history - a direct insert here would bypass that history.

    # 9. Swap each identifier column for its token. The vault hands back the existing token
    #    or creates one if the value is new - the same value always gets the same token.
    #    A column that cannot be tokenized is BLANKED: the clone keeps the column, but with
    #    NULL instead of the real values. Losing data beats leaking identifiers.
    skipped_columns = set()
    for column, element in tokenize_map.items():
        vault_table, prefix = VAULTS[element]
        # Each column tokenizes against the id of its own value, attached in steps 7-8.
        id_column = (
            f"canonical_account_id__{column}" if element == "account_id"
            else f"canonical_user_id__{column}"
        )

        # Pull the distinct (identity, value) pairs of this column to the driver. The
        # micro-batch cap bounds how big this can get.
        candidates = (
            df.select(
                F.col(id_column).cast("string").alias("canonical_internal_id"),
                F.col(column).cast("string").alias("source_value"),
            )
            .where(F.col(column).isNotNull() & F.col(id_column).isNotNull())
            .distinct()
            .toPandas()
        )

        # Normalize before the vault, so formatting differences cannot mint different
        # tokens: "S.Reyes@X.com" and "s.reyes@x.com" are the same email and must get
        # the same token everywhere. A value that cannot be normalized gets no token
        # and ends up NULL in the clone - dropping beats leaking.
        candidates["real_value"] = candidates["source_value"].map(
            lambda v: normalize.normalize_or_none(element, v)
        )
        candidates = candidates.dropna(subset=["real_value"])

        if candidates.empty and counts[f"values_{column}"] > 0:
            # Nothing tokenizable: either no row resolved an identity to hang the tokens
            # on, or no value survived normalization. Blank the column instead of letting
            # the real values through: the clone keeps the column, empty, and the log
            # says how many values were withheld.
            print(f"vault: BLANKED '{column}' - no {id_column} resolved or no value "
                  f"normalizable; {counts[f'values_{column}']} real values withheld")
            df = df.withColumn(column, F.lit(None).cast(df.schema[column].dataType))
            skipped_columns.add(column)
            continue

        # Find-or-insert on the normalized value: one vault row per distinct value, sent
        # in chunks so a wide batch never becomes one huge statement against Lakebase.
        distinct_values = (
            candidates[["canonical_internal_id", "real_value"]]
            .drop_duplicates(subset=["real_value"])
        )

        # How many distinct values go to the vault per round-trip. The vault looks its values up
        # with "real_value = ANY(array)" and inserts them in one statement, so the array IS the
        # payload: a table like cgi_account (31M distinct emails) sent whole is what makes
        # Lakebase fall over. Chunking keeps every statement small and the memory flat, at the
        # cost of more round-trips - which are cheap point lookups on an indexed column.
        VAULT_CHUNK_ROWS = 50_000
        tokens = pd.concat(
            [
                vault.vault_find_or_insert(
                    vault_table, element, prefix,
                    df_candidates=distinct_values.iloc[start:start + VAULT_CHUNK_ROWS],
                    source_system=SOURCE_SYSTEM,
                    # Loaded on the driver and carried into the batch: the vault must
                    # not fetch secrets here, foreachBatch has no notebook context.
                    pepper=PEPPERS[element],
                )
                for start in range(0, len(distinct_values), VAULT_CHUNK_ROWS)
            ],
            ignore_index=True,
        ) if len(distinct_values) else distinct_values.assign(token=None)

        # Swap the column for its token, joining back on the ORIGINAL value: every raw
        # variant of the same normalized value maps to the same token.
        if len(tokens):
            mapping = candidates.merge(tokens[["real_value", "token"]], on="real_value")
            token_map = spark.createDataFrame(
                mapping[["source_value", "token"]].drop_duplicates(subset=["source_value"])
            ).withColumnRenamed("token", "new_token")
            df = (
                df.join(token_map, df[column].cast("string") == token_map.source_value, "left")
                .drop(column, "source_value")
                .withColumnRenamed("new_token", column)
            )
        print(f"vault: '{column}' -> {len(tokens)} tokens in {vault_table}")

    # 10. Blur the sensitive details: birth date becomes just the year, zip code keeps only
    #     the first digits, IP keeps only the network part.
    if generalize_map:
        df = generalize.apply_generalization(df, generalize_map)

    # Masking of names and similar fields is handled elsewhere (PTK-36), not in this notebook.

    # 11. Remove the internal helper columns and put the columns back in their original
    #     order, so the output really is a clone of the source table.
    helper_columns = [f"canonical_user_id__{c}" for c in user_cols]
    helper_columns += [f"canonical_account_id__{c}" for c in account_cols]
    helper_columns += [f"{c}__hmac" for c in tokenize_map]
    df = df.drop(*helper_columns).select(*source_columns)

    # 12. Safety checks, all counted in one pass over the output. They only police the
    #     columns the gate promised to tokenize; descriptive columns such as names keep
    #     their plaintext on purpose and are protected read-side instead. A failed assert
    #     aborts the batch - in incremental mode that also stops the bookmark, so the
    #     same rows are re-read on the next run instead of being lost.
    tokenized_columns = [c for c in tokenize_map if c not in skipped_columns]

    # What a value of each kind still looks like when it was NOT tokenized. Used to prove a
    # tokenized column no longer holds a real value. The phone shape has to match the whole
    # value, because a hex token contains ten digits in a row often enough to matter.
    PLAINTEXT_SHAPE = {
        "email": r"@",
        "phone": r"^\+?1?[-. (]*\d{3}[-. )]*\d{3}[-. ]*\d{4}(\.0)?$",
    }

    check_columns = []
    for column in tokenized_columns:
        element = tokenize_map[column]
        token_shape = f"^{VAULTS[element][1]}[0-9a-f]{{32}}$"
        check_columns.append(
            F.count(F.when(F.col(column).isNotNull() & ~F.col(column).rlike(token_shape), 1))
            .alias(f"wrong_shape_{column}")
        )
        check_columns.append(F.count(F.col(column)).alias(f"kept_{column}"))
        if element in PLAINTEXT_SHAPE:
            check_columns.append(
                F.count(F.when(F.col(column).rlike(PLAINTEXT_SHAPE[element]), 1))
                .alias(f"plaintext_{column}")
            )
    checks = df.agg(*check_columns).first() if check_columns else None

    # A tokenized column must hold only tokens of its own kind, so a phone token can never
    # end up sitting in an email column by accident.
    for column in tokenized_columns:
        wrong = checks[f"wrong_shape_{column}"]
        if wrong:
            (
                df.filter(
                    F.col(column).isNotNull()
                    & ~F.col(column).rlike(
                        f"^{VAULTS[tokenize_map[column]][1]}[0-9a-f]{{32}}$"
                    )
                )
                .withColumn("checked_at", F.current_timestamp())
                .withColumn("run_id", F.lit(RUN_ID))
                .withColumn("source_catalog", F.lit(RAW_CATALOG))
                .withColumn("source_schema", F.lit(clone_schema))
                .withColumn("source_table", F.lit(table))
                .withColumn("column_name", F.lit(column))
                .withColumn("violation_type", F.lit("wrong_token_shape"))
                .withColumn("severity", F.lit("SEV2"))
                .withColumn("record", F.to_json(F.struct(*source_columns)))
                .select(
                    "checked_at",
                    "run_id",
                    "source_catalog",
                    "source_schema",
                    "source_table",
                    "column_name",
                    "violation_type",
                    "severity",
                    "record",
                )
                .write.format("delta")
                .mode("append")
                .saveAsTable(AUDIT_LEAK_TABLE)
            )
        assert not wrong, f"FAILED: '{column}' holds {wrong} values that are not its own token"

    # ...and it must not look like a real value any more.
    for column in tokenized_columns:
        if tokenize_map[column] in PLAINTEXT_SHAPE:
            plaintext = checks[f"plaintext_{column}"]
            if plaintext:
                (
                    df.filter(
                        F.col(column).rlike(
                            PLAINTEXT_SHAPE[tokenize_map[column]]
                        )
                    )
                    .withColumn("checked_at", F.current_timestamp())
                    .withColumn("run_id", F.lit(RUN_ID))
                    .withColumn("source_catalog", F.lit(RAW_CATALOG))
                    .withColumn("source_schema", F.lit(clone_schema))
                    .withColumn("source_table", F.lit(table))
                    .withColumn("column_name", F.lit(column))
                    .withColumn("violation_type", F.lit("plaintext_shape"))
                    .withColumn("severity", F.lit("SEV2"))
                    .withColumn("record", F.to_json(F.struct(*source_columns)))
                    .select(
                        "checked_at",
                        "run_id",
                        "source_catalog",
                        "source_schema",
                        "source_table",
                        "column_name",
                        "violation_type",
                        "severity",
                        "record",
                    )
                    .write.format("delta")
                    .mode("append")
                    .saveAsTable(AUDIT_LEAK_TABLE)
                )
            assert not plaintext, f"FAILED: '{column}' still holds {plaintext} real-looking values"

    # A column that had values but came back empty means the vault returned no token for any
    # of them, usually because two columns of the same kind competed for the same vault row.
    for column in tokenized_columns:
        had = counts[f"values_{column}"]
        assert not had or checks[f"kept_{column}"], \
            f"FAILED: '{column}' lost all of its {had} values, the vault returned no token"

    # Partial losses are legal but never silent: a value is dropped when it cannot be
    # normalized, or when its identity already holds another value of the same element
    # (the vault is keyed one row per identity per element, so the second one is refused).
    for column in tokenized_columns:
        lost = counts[f"values_{column}"] - checks[f"kept_{column}"]
        if lost:
            print(f"vault: WARNING '{column}' kept {checks[f'kept_{column}']} of "
                  f"{counts[f'values_{column}']} values, {lost} got no token")

    # No helper column may survive.
    assert not [c for c in df.columns if c.startswith("canonical_") or c.endswith("__hmac")], \
        "FAILED: an internal column reached the output"

    return df


# Keep the logger's timing wrapper off this function too: foreachBatch serializes it,
# and the wrapper cannot travel (see stage_into_lakebase).
run_gate._is_profiled = True


def path_exists(path):
    try:
        dbutils.fs.ls(path)
        return True
    except Exception:
        return False


# The gate metadata tables, created and owned by DISCOVER_LANDING_TABLES: the batch
# table holds the work the last discover queued, the metadata table remembers how far
# each table was processed.
BATCH_TABLE = f"{STATE_CATALOG}.{TARGET_SCHEMA}.{dbutils.widgets.get('GATE_BATCH_TABLE').strip()}"
METADATA_TABLE = f"{STATE_CATALOG}.{TARGET_SCHEMA}.{dbutils.widgets.get('GATE_METADATA_TABLE').strip()}"

# 1. Build the work list: one entry per table with where it lives, the commit version
#    it covers (None when nobody is keeping score), and the load mode to run it in.
if SOURCE_TABLE:
    # Direct run (the streaming job): one table, from the widgets. No version on
    # purpose: direct runs do not take part in the discover's bookkeeping, so they
    # record nothing in the metadata table.
    work_list = [{
        "catalog": SOURCE_CATALOG,
        "schema": SOURCE_SCHEMA,
        "table": SOURCE_TABLE,
        "version": None,
        "mode": LOAD_MODE,
    }]
else:
    # Queued run: the batch the discover queued, in the same stable order it selected.
    assert spark.catalog.tableExists(BATCH_TABLE), (
        f"FAILED: {BATCH_TABLE} does not exist. Run the discover task first, or set "
        "SOURCE_TABLE to gate a single table directly."
    )
    work_list = [
        {
            "catalog": row["source_catalog"],
            "schema": row["source_schema"],
            "table": row["source_table"],
            "version": row["source_version"],
            "mode": row["load_mode"],
        }
        for row in spark.table(BATCH_TABLE).orderBy("source_schema", "source_table").collect()
    ]
    for item in work_list:
        assert item["mode"] in ("full", "incremental"), (
            f"FAILED: {BATCH_TABLE} queues {item['schema']}.{item['table']} "
            f"with load mode '{item['mode']}'"
        )

print(f"gate: {len(work_list)} tables to process")
log_checkpoint(f"work list ready: {len(work_list)} tables")

# One table at a time, strictly in order: the runs share the Lakebase staging tables,
# so two tables must never be in flight at once. A table that fails is recorded and
# skipped - the ones after it still run, its old version stays in the metadata table,
# and the next discover picks it up again. The run itself still ends red at the bottom.
failed_tables = []
for position, item in enumerate(work_list, start=1):
    table = item["table"]
    mode = item["mode"]
    fq_source = f"{item['catalog']}.{item['schema']}.{table}"
    # The clone mirrors the source schema name inside the raw catalog, unless the job
    # configuration pins every clone to one fixed schema (dev does, while the gate is
    # validated).
    clone_schema = CLONE_SCHEMA or item["schema"]
    target = f"{RAW_CATALOG}.{clone_schema}.{table}"
    print(f"gate: [{position}/{len(work_list)}] {fq_source} ({mode})")
    log_checkpoint(f"gate start: {fq_source} ({mode})", iteration=position, total=len(work_list))

    try:
        # Create the clone's schema if it is missing (unless this is a dry run).
        if not DRY_RUN:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {RAW_CATALOG}.{clone_schema}")

        # 2. Remember the source column order, so the copy we write at the end is a real
        #    clone and not a reshuffled version of it. Both load modes need it.
        source_columns = spark.table(fq_source).columns

        # 3. Look at the table and decide, column by column, what needs tokens and what
        #    needs blurring. It checks the catalog tags first, then the column name, then
        #    a sample of the actual values - so a column with emails inside gets caught
        #    even with an odd name. Detection runs once per table, against the table
        #    itself: the treatments stay fixed for every batch of this table's run.
        detections = detect_treatments(spark, fq_source, SAMPLE_ROWS)

        # The secret keys used to hash identifiers. Loaded here because the second
        # opinion below already needs them.
        PEPPERS = load_peppers({d["target"] for d in detections if d["action"] == "tokenize"})

        # 3b. Second opinion on that list, asking the identity graph. Detection only sees
        #     names and what values look like, and here that is not enough: in these
        #     tables almost every column holds ids that look exactly alike, so a column
        #     of harmless internal ids can pass for user ids. The graph knows which
        #     values are actually people. This lives in the notebook, not in the shared
        #     library, so changing it can never break the other jobs that use the library.
        detections = confirm_detections(detections)

        tokenize_map = {}
        generalize_map = {}
        vendor_map = {}
        for detection in detections:
            if detection["action"] == "tokenize":
                tokenize_map[detection["column"]] = detection["target"]
                vendor_map[detection["column"]] = detection["vendor"]
            elif detection["action"] == "generalize":
                generalize_map[detection["column"]] = detection["target"]

        # What the gate decided, and why. A column that looked like an identifier by its
        # name but whose values did not confirm it is left alone on purpose - it shows up
        # here so a column missing from the tokenize list is never a mystery.
        print(f"detect: tokenize={tokenize_map}")
        print(f"detect: generalize={generalize_map}")
        print(f"detect: vendors={ {c: v for c, v in vendor_map.items() if v} }")
        for detection in detections:
            if detection["action"] == "pass" and detection["signal"] != "none":
                print(f"detect: '{detection['column']}' left as it is ({detection['signal']})")

        # Separate the columns that belong to a person from the ones that belong to an
        # account.
        user_cols = {c: e for c, e in tokenize_map.items() if e != "account_id"}
        account_cols = [c for c, e in tokenize_map.items() if e == "account_id"]

        if mode == "full":
            # Full mode: the whole table in one batch, and the output is always
            # overwritten - the clone replaces the previous clone, so a re-run never
            # piles up duplicated rows. A full run is always big, so identity staging
            # goes through the heavy loader.
            BULK_STAGING = True
            output = run_gate(spark.read.table(fq_source))
            if DRY_RUN:
                print(f"dry run: nothing written to {target}")
                output.show(10, truncate=False)
            else:
                output.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(target)
                print(f"wrote {target} (overwrite)")
        else:
            # Incremental mode: read only the commits added to the source since the last
            # run. The streaming checkpoint is the bookmark: it stores how far this table
            # has been processed, and it only moves forward when a batch finishes cleanly.
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {STATE_CATALOG}.{TARGET_SCHEMA}.gate_checkpoints")
            checkpoint = f"/Volumes/{STATE_CATALOG}/{TARGET_SCHEMA}/gate_checkpoints/{fq_source}"
            if DRY_RUN:
                # A dry run must not consume the pending commits: a batch that finishes
                # cleanly advances the bookmark even if nothing was written. So it gets a
                # throwaway checkpoint, removed at the end, and the real bookmark stays
                # untouched.
                checkpoint = f"/Volumes/{STATE_CATALOG}/{TARGET_SCHEMA}/gate_checkpoints/_dry_run/{uuid.uuid4()}"

            # No bookmark means this table was never processed, so this run reads it
            # whole - that is a big load, so identity staging goes through the heavy
            # loader. Later runs only carry the new rows and use the light one. (A dry
            # run always counts as a first run: its throwaway bookmark never exists,
            # and it does re-read the whole table.)
            FIRST_RUN = not path_exists(checkpoint)
            BULK_STAGING = FIRST_RUN
            print(f"staging: {'bulk (first run over this table)' if BULK_STAGING else 'driver-side (incremental)'}")

            # A fresh bookmark over a clone that already has rows (say, one written by
            # full mode) would append the whole initial load on top of them and duplicate
            # everything. Refuse: drop the clone first, or run LOAD_MODE=full.
            if not DRY_RUN and FIRST_RUN and spark.catalog.tableExists(target):
                assert not spark.table(target).limit(1).count(), (
                    f"FAILED: {target} already has rows but this table has no bookmark yet. "
                    "Appending the initial load would duplicate them: drop the clone first, "
                    "or run LOAD_MODE=full."
                )

            # The pair (txnAppId, txnVersion) is what dedups a retried batch, so it has to
            # be tied to THIS bookmark: after a checkpoint reset (replay) the batch ids
            # start again at 0, and a txnAppId that survived the reset would make Delta
            # silently skip the replayed batches as "already written". The epoch lives
            # inside the checkpoint directory, so a new bookmark always means a new
            # txnAppId.
            epoch_file = f"{checkpoint}/_gate_epoch"
            if path_exists(epoch_file):
                epoch = dbutils.fs.head(epoch_file)
            else:
                epoch = uuid.uuid4().hex
                dbutils.fs.put(epoch_file, epoch, True)
            txn_app = f"tokenize_gate::{target}::{epoch}"

            def gate_batch(batch_df, batch_id):
                output = run_gate(batch_df)
                if DRY_RUN:
                    print(f"dry run: batch {batch_id} not written to {target}")
                    output.show(10, truncate=False)
                else:
                    # txnAppId + txnVersion make the append idempotent: if this batch is
                    # retried after a failure, Delta recognises the pair and skips the
                    # duplicate write.
                    (output.write.format("delta")
                        .option("txnAppId", txn_app)
                        .option("txnVersion", batch_id)
                        .mode("append")
                        .saveAsTable(target))
                    print(f"wrote {target} (append, batch {batch_id})")

            # Serialized whole into the foreachBatch process - keep the logger's
            # wrapper off it (see stage_into_lakebase).
            gate_batch._is_profiled = True

            stream = (
                spark.readStream
                # Landing rows expire (retention deletes old ones). Those deletes are
                # commits too; skip them instead of failing - only newly added rows
                # matter here.
                .option("skipChangeCommits", "true")
                # Cap each micro-batch. This is the one knob that trades the two costs
                # against each other: every batch pays a fixed set of Lakebase round
                # trips (delete-me scan, staging load, resolution, read-back), so smaller
                # batches mean MORE total load on Lakebase - while bigger batches mean
                # more driver memory, because the vault step pulls the batch's distinct
                # values there. 512 MB keeps both bounded and turns a 31M-row table like
                # cgi_account into a handful of batches.
                .option("maxBytesPerTrigger", "512m")
                .table(fq_source)
            )
            query = (
                stream.writeStream
                .foreachBatch(gate_batch)
                # Process everything pending since the bookmark, then stop - no
                # always-on cluster.
                .trigger(availableNow=True)
                .option("checkpointLocation", checkpoint)
                .start()
            )
            query.awaitTermination()
            if DRY_RUN:
                dbutils.fs.rm(checkpoint, recurse=True)
                print(f"dry run: throwaway checkpoint removed, the real bookmark did not move")

        # 4. Remember how far this table was processed, so the next discover can skip it
        #    while nothing new is committed to it. Only after everything above finished
        #    cleanly: a run that failed leaves the old version in place and gets picked
        #    up again. Direct runs carry no version and record nothing, the same way a
        #    dry run does not move the streaming bookmark.
        if item["version"] is not None and not DRY_RUN:
            # The metadata table is created and owned by DISCOVER_LANDING_TABLES - the
            # only thing that ever queues a version - so by the time this runs the
            # table exists.
            spark.sql(f"""
                MERGE INTO {METADATA_TABLE} AS state
                USING (SELECT '{item['schema']}.{table}' AS source_table,
                              {item['version']} AS source_version,
                              current_timestamp() AS swept_at) AS run
                ON state.source_table = run.source_table
                WHEN MATCHED THEN UPDATE SET source_version = run.source_version, swept_at = run.swept_at
                WHEN NOT MATCHED THEN INSERT (source_table, source_version, swept_at)
                                      VALUES (run.source_table, run.source_version, run.swept_at)
            """)
            print(f"gate metadata: {item['schema']}.{table} processed up to version {item['version']}")

        print(f"done: {fq_source}")
        log_checkpoint(f"done: {fq_source}", iteration=position, total=len(work_list))
    except Exception as error:
        failed_tables.append(f"{item['schema']}.{table}")
        print(f"FAILED: {fq_source}: {error}")
        log_checkpoint(f"FAILED: {fq_source}", iteration=position, total=len(work_list))

# Leave nothing behind in the staging tables.
ptk_execute("DELETE FROM public.gate_user_identifier")
ptk_execute("DELETE FROM public.gate_user_accounts")

# A failed table already kept its old version above; the run itself must still end red,
# so the failure is never silent.
assert not failed_tables, (
    f"FAILED: {len(failed_tables)} of {len(work_list)} tables did not pass the gate: "
    f"{', '.join(failed_tables)}"
)

print(f"done: {len(work_list)} tables processed")
log_checkpoint("gate run complete")
