# Runbook — manual purge of Landing data (incident path)

**When to use:** a "destroy this data NOW" situation (legal order, incident response) that cannot
wait for auto-TTL, or auto-TTL verified as not running. Auto-TTL cannot be triggered manually —
this is the documented alternative (ADR "Landing Shape and Retention", Decision 2).

**Who:** requires MODIFY on the affected tables (in practice: the platform team or the
landing-catalog-owner service principal). The compliance monitor's principal CANNOT do this —
it is read-only by design.

## Steps

1. **Logical delete** of the affected rows (or all expired rows):

```sql
DELETE FROM <catalog>.<schema>.<table>
WHERE _ingested_at < current_date() - INTERVAL <retention_days> DAYS;
-- or a tighter predicate for a specific subject/incident
```

2. **Physical rewrite** — with deletion vectors, DELETE alone removes nothing from storage:

```sql
REORG TABLE <catalog>.<schema>.<table> APPLY (PURGE);
```

3. **Remove the old files:**

```sql
VACUUM <catalog>.<schema>.<table>;
```

> Default VACUUM retention applies (7 days). For an incident that requires immediate physical
> removal, the retention check must be lowered explicitly and consciously — involve the platform
> team; do not script this step blindly.

4. **Record it:** append a row to the evidence log
   (`<landing_catalog>._compliance.retention_evidence`) with `check = 'manual_purge'`, the
   incident/ticket id in `detail`, and who executed it.

5. **Verify:** `SELECT min(_ingested_at) FROM <table>` is within the window, and the next daily
   `LANDING_RETENTION` run comes back green.

## Notes

- The `_compliance.retention_evidence` table is append-only evidence for auditors — never
  update or delete rows in it.
- If this runbook is being used because auto-TTL silently stopped, that is exactly the failure
  mode the monitor exists to catch — check the monitor's FAIL rows first, then open an incident
  with the platform team (predictive optimization owns the delete cycle).
