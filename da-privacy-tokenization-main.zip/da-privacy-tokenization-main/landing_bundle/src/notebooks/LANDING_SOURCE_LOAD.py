# Databricks notebook source
# Loads new rows from each live source table into Landing, one watermarked batch at a time.
import yaml
from datetime import datetime, timezone

# Degrade to printing when lakebase_utils is missing: a manual run cannot read the wheel Volume.
try:
    from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
    STRUCTURED_LOG = True
except ImportError:
    STRUCTURED_LOG = False

    def start_global_notebook_logger():
        print("lakebase_utils not installed: checkpoints print to the notebook only, "
              "no structured log is written for this run.")

    def log_checkpoint(message, **kwargs):
        print("checkpoint: " + str(message))

start_global_notebook_logger()

dbutils.widgets.text("landing_catalog", "")
dbutils.widgets.text("config_path", "")          # workspace path to landing_sources.yml
dbutils.widgets.text("shapes_path", "")          # workspace path to landing_shapes.yml
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "Dry run (no writes)")
dbutils.widgets.text("only_source", "")          # limit to one source system, for a targeted run
dbutils.widgets.text("only_tables", "")          # comma separated table names, for a targeted run

CATALOG = dbutils.widgets.get("landing_catalog").strip()
CONFIG_PATH = dbutils.widgets.get("config_path").strip()
SHAPES_PATH = dbutils.widgets.get("shapes_path").strip()
DRY_RUN = dbutils.widgets.get("dry_run") == "true"
ONLY_SOURCE = dbutils.widgets.get("only_source").strip()
ONLY_TABLES = {t.strip().lower() for t in dbutils.widgets.get("only_tables").split(",") if t.strip()}
assert CATALOG and CONFIG_PATH and SHAPES_PATH, "Set landing_catalog, config_path and shapes_path."
log_checkpoint(f"variables creation: catalog={CATALOG} dry_run={DRY_RUN}")

with open(CONFIG_PATH, encoding="utf-8") as f:
    cfg = yaml.safe_load(f)

# Producer shapes come from the versioned contract file, not a live DESCRIBE against prod_raw.
with open(SHAPES_PATH, encoding="utf-8") as f:
    SHAPES = (yaml.safe_load(f) or {}).get("shapes") or {}
log_checkpoint(f"{len(SHAPES)} producer shape(s) loaded from the contract file")

DEFAULTS = cfg["defaults"]
CTRL = cfg["control"]
STAMP_COL = DEFAULTS["ingested_at_column"]
CONTROL_SCHEMA = f"{CATALOG}.`{CTRL['schema']}`"
STATE_TABLE = f"{CONTROL_SCHEMA}.`{CTRL['state_table']}`"
LOG_TABLE = f"{CONTROL_SCHEMA}.`{CTRL['log_table']}`"

# metadata Landing adds itself, on top of the source system's own columns
META = [(STAMP_COL, "TIMESTAMP"), ("_source_system", "STRING"), ("_source_object", "STRING")]
META_NAMES = {c.lower() for c, _ in META}
# columns the live lakehouse copy adds that are not part of the source system
DROP_COLS = {"crt_dttm", "partition_column", "_rescued_data",
             # prod_raw's own ingest columns: they describe that load, not the producer, so Landing drops them.
             "_ingest_run_id"}

# -- validation gate: a malformed entry stops the whole run before anything is written --
errors, work = [], []
n_src = len(cfg["sources"])
for i, (system, scfg) in enumerate(cfg["sources"].items(), start=1):
    for entry in (scfg or {}).get("tables", []):
        name = entry.get("table")
        if not name or not entry.get("source") or not entry.get("shape_from"):
            errors.append(f"{system}: entry missing table/source/shape_from: {entry}")
            continue
        if entry.get("mode") not in ("incremental", "full_refresh"):
            errors.append(f"{system}.{name}: mode must be incremental or full_refresh")
            continue
        if entry["mode"] == "incremental" and not entry.get("watermark"):
            errors.append(f"{system}.{name}: incremental requires a watermark column")
            continue
        if entry["mode"] == "incremental":
            work.append((system, entry))
    log_checkpoint(f"validated source system {system}", iteration=i, total=n_src)
if errors:
    log_checkpoint(f"branch: config invalid = True ({len(errors)} error(s), nothing written)")
    raise ValueError("landing_sources.yml rejected:\n  " + "\n  ".join(errors))
log_checkpoint(f"branch: config invalid = False ({len(work)} incremental tables queued)")

if ONLY_SOURCE:
    work = [(s, e) for s, e in work if s == ONLY_SOURCE]
if ONLY_TABLES:
    work = [(s, e) for s, e in work if e["table"].lower() in ONLY_TABLES]
log_checkpoint(f"{len(work)} table(s) in scope after filters")

# Control tables live in the catalog, and this job only checks them: PROVISION_TARGETS owns all DDL.
if not DRY_RUN:
    for t in (STATE_TABLE, LOG_TABLE):
        if not spark.catalog.tableExists(t.replace("`", "")):
            raise RuntimeError(
                f"{t} does not exist. Run LANDING_PROVISION_TARGETS first: this job writes to "
                f"tables it does not create.")
    log_checkpoint("control tables present")

state = {}
if not DRY_RUN:
    for r in spark.sql(f"SELECT source_system, table_name, watermark FROM {STATE_TABLE}").collect():
        state[(r.source_system, r.table_name)] = r.watermark
log_checkpoint(f"{len(state)} stored watermark(s) loaded")

RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

# DESCRIBE TABLE, not information_schema: the latter drops type parameters like decimal(19,4).
def describe(fqn):
    cols = []
    for r in spark.sql(f"DESCRIBE TABLE {fqn}").collect():
        nm = (r[0] or "").strip()
        if not nm or nm.startswith("#"):
            break                              # partition info and footer start here
        cols.append((nm, (r[1] or "").strip()))
    return cols

# The producer shape from the contract file; a missing entry is fatal, never silently skipped.
def shape_of(fqn):
    cols = SHAPES.get(fqn)
    if not cols:
        raise KeyError(
            f"no shape captured for {fqn}. Capture it with DESCRIBE TABLE and add it to "
            f"landing_shapes.yml, or fix the shape_from value in landing_sources.yml.")
    return [(c[0], c[1]) for c in cols]

# Read the live copy, keep the faithful shape: cast what exists, typed NULL for what does not.
def projection(shape_cols, live_cols):
    live = {c.lower(): c for c, _ in live_cols}
    out, filled, nulled = [], 0, []
    for col, typ in shape_cols:
        if col.lower() in META_NAMES or col.lower() in DROP_COLS:
            continue
        src = live.get(col.lower())
        if src:
            out.append(f"CAST(`{src}` AS {typ}) AS `{col}`")
            filled += 1
        else:
            out.append(f"CAST(NULL AS {typ}) AS `{col}`")
            nulled.append(col)
    return out, filled, nulled

def log_row(system, table, status, selected=None, loaded=None,
            wm_from=None, wm_to=None, detail=None):
    if DRY_RUN:
        return
    spark.sql(f"""INSERT INTO {LOG_TABLE} VALUES (
        '{RUN_ID}', '{system}', '{table}', '{status}',
        {selected if selected is not None else 'NULL'},
        {loaded if loaded is not None else 'NULL'},
        {"'" + str(wm_from) + "'" if wm_from else 'NULL'},
        {"'" + str(wm_to) + "'" if wm_to else 'NULL'},
        {"'" + str(detail).replace("'", "")[:400] + "'" if detail else 'NULL'},
        current_timestamp())""")

loaded_ok = nothing_new = failed = 0
n_work = len(work)

for i, (system, entry) in enumerate(work, start=1):
    table = entry["table"]
    src_fqn = entry["source"]
    shape_fqn = entry["shape_from"]
    target = f"{CATALOG}.`{system}`.`{table}`"
    wcol = entry["watermark"]
    cap = int(entry.get("cap", DEFAULTS["cap"]))
    lookback = int(entry.get("first_run_lookback_hours", DEFAULTS["first_run_lookback_hours"]))
    max_lag = entry.get("max_lag_hours")

    try:
        shape_cols = shape_of(shape_fqn)      # the contract file, not a live DESCRIBE
        live_cols = describe(src_fqn)         # the live copy still has to be inspected
        select_list, filled, nulled = projection(shape_cols, live_cols)
        if not filled:
            log_checkpoint(f"branch: {table} shares no column with its shape = True (skipped)")
            log_row(system, table, "no_overlap", detail=f"shape {shape_fqn}")
            failed += 1
            continue

        # This job writes but never creates: a missing target means LANDING_PROVISION_TARGETS has not run.
        if not spark.catalog.tableExists(f"{CATALOG}.{system}.{table}"):
            failed += 1
            log_row(system, table, "target_missing",
                    detail="run LANDING_PROVISION_TARGETS first")
            log_checkpoint(f"branch: {table} target exists = False (refused, nothing written)")
            print(f"{table:<34} REFUSED  target does not exist, run LANDING_PROVISION_TARGETS")
            continue

        last = state.get((system, table))
        # A watermark further behind than the ceiling would crawl through history; skip to the recent window.
        if last and max_lag:
            behind = spark.sql(
                f"SELECT timestampdiff(HOUR, timestamp('{last}'), current_timestamp())"
            ).collect()[0][0]
            if int(behind) > int(max_lag):
                log_checkpoint(f"branch: {table} lag {behind}h over {max_lag}h = True (skipping ahead)")
                log_row(system, table, "skipped_ahead", wm_from=last, detail=f"{behind}h behind")
                last = None

        if last:
            pred = f"`{wcol}` > '{last}'"
        elif entry.get("first_load") == "full":
            # Take the whole table once: rows older than the window would otherwise never reach Landing at all.
            pred = "1 = 1"
            log_checkpoint(f"branch: {table} first load = full (whole table, once)")
        else:
            # Resolve the floor ONCE; current_timestamp() inside the predicate moves between count and insert.
            floor = spark.sql(
                f"SELECT date_format(current_timestamp() - INTERVAL {lookback} HOURS,"
                f" \"yyyy-MM-dd'T'HH:mm:ss\")").collect()[0][0]
            pred = f"`{wcol}` >= '{floor}'"

        pending = spark.sql(f"SELECT COUNT(*) FROM {src_fqn} WHERE {pred}").collect()[0][0]
        if pending == 0:
            nothing_new += 1
            log_checkpoint(f"branch: {table} has new rows = False", iteration=i, total=n_work)
            continue
        log_checkpoint(f"branch: {table} has new rows = True ({pending:,} pending)")

        # Stop strictly below the last watermark value so a batch-stamped group is never cut in half.
        load_pred = pred
        if pending > cap:
            boundary = spark.sql(
                f"SELECT MAX(`{wcol}`) FROM (SELECT `{wcol}` FROM {src_fqn} "
                f"WHERE {pred} ORDER BY `{wcol}` LIMIT {cap})").collect()[0][0]
            load_pred = f"{pred} AND `{wcol}` < '{boundary}'"
            if spark.sql(f"SELECT COUNT(*) FROM {src_fqn} WHERE {load_pred}").collect()[0][0] == 0:
                log_checkpoint(f"branch: {table} single watermark value over cap = True (refused)")
                log_row(system, table, "watermark_group_exceeds_cap",
                        selected=pending, detail=f"value {boundary} alone exceeds cap {cap}")
                failed += 1
                continue

        batch_sql = (f"SELECT {', '.join(select_list)} FROM {src_fqn} "
                     f"WHERE {load_pred} ORDER BY `{wcol}` LIMIT {cap}")
        selected = spark.sql(f"SELECT COUNT(*) FROM ({batch_sql})").collect()[0][0]
        new_wm = spark.sql(f"SELECT MAX(`{wcol}`) FROM (SELECT `{wcol}` FROM {src_fqn} "
                           f"WHERE {load_pred} ORDER BY `{wcol}` LIMIT {cap})").collect()[0][0]

        if DRY_RUN:
            print(f"{table:<34} would load {selected:>9,}  wm -> {new_wm}"
                  + (f"  ({len(nulled)} col NULL)" if nulled else ""))
            log_checkpoint(f"dry run: {table} would load {selected:,}", iteration=i, total=n_work)
            continue

        # One stamp per batch, as a literal: it is also the only handle for taking the batch back out.
        stamp = spark.sql("SELECT date_format(current_timestamp(),"
                          " \"yyyy-MM-dd HH:mm:ss.SSS\")").collect()[0][0]
        before = spark.sql(f"SELECT COUNT(*) FROM {target}").collect()[0][0]
        spark.sql(f"""INSERT INTO {target} BY NAME
            SELECT *, TIMESTAMP '{stamp}' AS `{STAMP_COL}`,
                   '{system}' AS `_source_system`, '{table}' AS `_source_object`
            FROM ({batch_sql})""")
        after = spark.sql(f"SELECT COUNT(*) FROM {target}").collect()[0][0]
        landed = after - before

        if landed == selected:
            spark.sql(f"DELETE FROM {STATE_TABLE} WHERE source_system = '{system}' "
                      f"AND table_name = '{table}'")
            spark.sql(f"""INSERT INTO {STATE_TABLE} VALUES (
                '{system}', '{table}', '{src_fqn}', '{new_wm}', '{wcol}',
                {landed}, current_timestamp())""")
            loaded_ok += 1
            log_row(system, table, "ok", selected, landed, last, new_wm)
            print(f"{table:<34} loaded {landed:>9,}  wm -> {new_wm}")
            log_checkpoint(f"{table} loaded {landed:,} rows", iteration=i, total=n_work)
        else:
            # Roll the batch back before giving up, or the next run appends the same rows on top of it.
            spark.sql(f"DELETE FROM {target} WHERE `{STAMP_COL}` = TIMESTAMP '{stamp}'")
            removed = before - spark.sql(f"SELECT COUNT(*) FROM {target}").collect()[0][0]
            failed += 1
            log_row(system, table, "count_mismatch", selected, landed, last, new_wm,
                    detail=f"batch rolled back, table back to {before} rows")
            log_checkpoint(f"branch: {table} landed == selected = False "
                           f"(batch rolled back, watermark held)")
            if removed:
                log_checkpoint(f"branch: {table} rollback left {removed} row(s) unaccounted "
                               f"= True (inspect before rerunning)")

    except Exception as e:
        detail = " ".join(str(e).split())[:400]
        failed += 1
        log_row(system, table, "error", detail=detail)
        log_checkpoint(f"branch: {table} raised = True (continuing)")
        print(f"{table:<34} FAILED  {detail[:110]}")

print(f"\nRUN {RUN_ID}  loaded={loaded_ok}  "
      f"nothing_new={nothing_new}  failed={failed}")
log_checkpoint(f"run finished: loaded={loaded_ok} nothing_new={nothing_new} failed={failed}")
if failed:
    # surfaced after every table has had its turn, so one bad table does not hide the rest
    raise RuntimeError(f"{failed} table(s) did not load. See {LOG_TABLE} for run {RUN_ID}.")
