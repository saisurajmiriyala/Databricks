# Databricks notebook source
# LANDING_RETENTION_APPLY — declare auto-TTL on every operational Landing table (P1-03 / PRV-38).
# Reads the retention config (config-as-code), validates the windows, and applies
#   ALTER TABLE <t> DELETE ROWS <n> DAYS AFTER <timestamp_column>
# to every table of every configured landing schema. Idempotent: re-applying updates the
# declaration in place. REJECTS any window above max_retention_days — that is the ADR's
# ">30 days never reaches an environment" gate.
import yaml
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint

start_global_notebook_logger()

dbutils.widgets.text("landing_catalog", "dev_landing")
dbutils.widgets.text("config_path", "")   # workspace path to retention_config.yml (set by the job)

CATALOG = dbutils.widgets.get("landing_catalog").strip()
CONFIG_PATH = dbutils.widgets.get("config_path").strip()
assert CATALOG and CONFIG_PATH, "Set landing_catalog and config_path."
log_checkpoint(f"variables creation: catalog={CATALOG}")

with open(CONFIG_PATH, encoding="utf-8") as f:
    cfg = yaml.safe_load(f)

defaults = cfg["defaults"]
MAX_DAYS = int(cfg["max_retention_days"])
TS_COL_DEFAULT = defaults["timestamp_column"]
log_checkpoint(f"retention config loaded: {len(cfg['sources'])} sources, ceiling {MAX_DAYS}d")

# -- validation gate: nothing above the ceiling ever gets declared -----------------
errors = []
n_sources = len(cfg["sources"])
for i, (src, scfg) in enumerate(cfg["sources"].items(), start=1):
    days = int((scfg or {}).get("retention_days", defaults["retention_days"]))
    if days > MAX_DAYS:
        errors.append(f"{src}: retention_days={days} exceeds max {MAX_DAYS}")
        log_checkpoint(f"branch: {src} {days}d > ceiling {MAX_DAYS}d = True (rejected)")
    if days > int(defaults["retention_days"]) and (scfg or {}).get("replay_class") != "multi_day":
        errors.append(f"{src}: retention_days={days} above default requires replay_class: multi_day")
        log_checkpoint(f"branch: {src} {days}d above default without replay_class multi_day = True (rejected)")
    log_checkpoint(f"validated {src}: {days}d window", iteration=i, total=n_sources)
if errors:
    log_checkpoint(f"branch: config invalid = True ({len(errors)} error(s), nothing applied)")
    raise ValueError("Retention config rejected:\n  " + "\n  ".join(errors))
log_checkpoint("branch: config invalid = False (validation gate passed)")

# -- apply --------------------------------------------------------------------------
applied, missing_schema, failed = [], [], []
schemas = [r.databaseName for r in spark.sql(f"SHOW SCHEMAS IN {CATALOG}").collect()]
log_checkpoint(f"{len(schemas)} schemas listed in {CATALOG}")
for i, (src, scfg) in enumerate(cfg["sources"].items(), start=1):
    days = int((scfg or {}).get("retention_days", defaults["retention_days"]))
    ts_col = (scfg or {}).get("timestamp_column", TS_COL_DEFAULT)
    if src not in schemas:
        missing_schema.append(src)
        log_checkpoint(f"branch: {src} present in catalog = False (skipped, live ingestion pending)")
        continue
    log_checkpoint(f"branch: {src} present in catalog = True")
    tables = spark.sql(f"SHOW TABLES IN {CATALOG}.`{src}`").collect()
    for j, r in enumerate(tables, start=1):
        fqn = f"{CATALOG}.`{src}`.`{r.tableName}`"
        # A single bad table (view, permission, missing column) must not block the rest;
        # failures are collected and raised at the end, the monitor runs regardless (run_if ALL_DONE).
        try:
            spark.sql(f"ALTER TABLE {fqn} DELETE ROWS {days} DAYS AFTER `{ts_col}`")
            applied.append((fqn, days))
            print(f"TTL {days}d -> {fqn}")
        except Exception as e:
            failed.append((fqn, str(e)[:200]))
            log_checkpoint(f"branch: ALTER TABLE failed on {src}.{r.tableName} = True (continuing)")
        log_checkpoint(f"declared TTL {days}d on {src}.{r.tableName}", iteration=j, total=len(tables))
    log_checkpoint(f"schema {src} applied", iteration=i, total=n_sources)

print(f"\nAPPLY DONE: {len(applied)} tables declared")
if missing_schema:
    print(f"schemas in config but not present yet (waiting on live ingestion): {missing_schema}")
    log_checkpoint(f"schemas pending live ingestion: {missing_schema}")
log_checkpoint(f"apply finished: {len(applied)} declared, {len(failed)} failed, {len(missing_schema)} schemas pending")
if failed:
    for fqn, err in failed:
        print(f"  FAILED: {fqn}: {err}")
    raise Exception(f"{len(failed)} table(s) failed TTL declaration — see list above")
