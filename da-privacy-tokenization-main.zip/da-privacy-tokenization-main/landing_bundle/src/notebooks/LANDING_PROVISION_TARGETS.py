# Databricks notebook source
# Creates every Landing schema and table from the versioned shapes, with its retention TTL attached.
import yaml

try:
    from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
except ImportError:
    # Degrade to printing when lakebase_utils is missing: a manual run cannot read the wheel Volume.
    def start_global_notebook_logger():
        print("lakebase_utils not installed: checkpoints print to the notebook only.")

    def log_checkpoint(message, **kwargs):
        print("checkpoint: " + str(message))

start_global_notebook_logger()

dbutils.widgets.text("landing_catalog", "")
dbutils.widgets.text("config_path", "")            # workspace path to landing_sources.yml
dbutils.widgets.text("shapes_path", "")            # workspace path to landing_shapes.yml
dbutils.widgets.text("retention_path", "")         # workspace path to retention_config.yml
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "Dry run (no DDL)")
dbutils.widgets.text("only_source", "")            # limit to one source system

CATALOG = dbutils.widgets.get("landing_catalog").strip()
CONFIG_PATH = dbutils.widgets.get("config_path").strip()
SHAPES_PATH = dbutils.widgets.get("shapes_path").strip()
RETENTION_PATH = dbutils.widgets.get("retention_path").strip()
DRY_RUN = dbutils.widgets.get("dry_run") == "true"
ONLY_SOURCE = dbutils.widgets.get("only_source").strip()
assert CATALOG and CONFIG_PATH and SHAPES_PATH and RETENTION_PATH, (
    "Set landing_catalog, config_path, shapes_path and retention_path.")
log_checkpoint(f"variables creation: catalog={CATALOG} dry_run={DRY_RUN}")

with open(CONFIG_PATH, encoding="utf-8") as f:
    cfg = yaml.safe_load(f)
with open(SHAPES_PATH, encoding="utf-8") as f:
    SHAPES = (yaml.safe_load(f) or {}).get("shapes") or {}
with open(RETENTION_PATH, encoding="utf-8") as f:
    ret = yaml.safe_load(f)

DEFAULTS = cfg["defaults"]
STAMP_COL = DEFAULTS["ingested_at_column"]
CTRL = cfg["control"]

# These three must match LANDING_SOURCE_LOAD: it inserts BY NAME into what is created here.
META = [(STAMP_COL, "TIMESTAMP"), ("_source_system", "STRING"), ("_source_object", "STRING")]
META_NAMES = {c.lower() for c, _ in META}
DROP_COLS = {"crt_dttm", "partition_column", "_rescued_data", "_ingest_run_id"}

RET_DEFAULTS = ret["defaults"]
MAX_DAYS = int(ret["max_retention_days"])
RET_SOURCES = ret.get("sources") or {}
log_checkpoint(f"{len(SHAPES)} producer shape(s) and {len(RET_SOURCES)} retention window(s) loaded")

# -- validation gate: nothing is created until every entry checks out --------------------
errors, work = [], []
for system, node in (cfg.get("sources") or {}).items():
    if ONLY_SOURCE and system != ONLY_SOURCE:
        continue
    for entry in node.get("tables") or []:
        name = entry.get("table")
        shape = entry.get("shape_from")
        if not name or not shape:
            errors.append(f"{system}: an entry is missing table or shape_from")
            continue
        if shape not in SHAPES:
            errors.append(f"{system}.{name}: no shape captured for {shape}")
            continue
        # Only what the load writes: a full_refresh target would sit permanently empty in the PII zone.
        if entry.get("mode") != "incremental":
            continue
        work.append((system, name, shape))

    # A schema with no declared retention window would land PII the compliance monitor cannot account for.
    scfg = RET_SOURCES.get(system)
    days = int((scfg or {}).get("retention_days", RET_DEFAULTS["retention_days"]))
    if system not in RET_SOURCES:
        errors.append(f"{system}: no retention window in retention_config.yml")
    elif days > MAX_DAYS:
        errors.append(f"{system}: retention_days={days} exceeds max {MAX_DAYS}")
    elif days > int(RET_DEFAULTS["retention_days"]) and (scfg or {}).get("replay_class") != "multi_day":
        errors.append(f"{system}: retention_days={days} above default requires replay_class: multi_day")

if errors:
    log_checkpoint(f"branch: config invalid = True ({len(errors)} error(s), nothing created)")
    raise ValueError("refusing to create anything:\n  " + "\n  ".join(errors))
log_checkpoint(f"branch: config invalid = False ({len(work)} target(s) to ensure)")

def shape_of(fqn):
    """The producer shape, from the contract file. Same rule the load uses."""
    return [(c[0], c[1]) for c in SHAPES[fqn]
            if c[0].lower() not in META_NAMES and c[0].lower() not in DROP_COLS]

created = ttl_set = existed = failed = 0
systems_done = set()

for i, (system, table, shape_fqn) in enumerate(work, start=1):
    target = f"{CATALOG}.`{system}`.`{table}`"
    try:
        if system not in systems_done:
            if not DRY_RUN:
                spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.`{system}` "
                          f"COMMENT 'Landing zone for source system {system}. Raw PII, "
                          f"service principals only, retention enforced by auto-TTL.'")
            systems_done.add(system)
            log_checkpoint(f"schema {CATALOG}.{system} ensured")

        cols = shape_of(shape_fqn)
        body = ",\n  ".join(f"`{c}` {t}" for c, t in cols)
        meta = ",\n  ".join(f"`{c}` {t}" for c, t in META)
        exists = spark.catalog.tableExists(f"{CATALOG}.{system}.{table}")

        if DRY_RUN:
            print(f"{system}.{table:<34} {'exists' if exists else 'would create'}"
                  f"  {len(cols)} producer cols + {len(META)} meta")
            continue

        # CLUSTER BY AUTO: ADR Decision 2 asks for clustering and nobody has seen the query pattern yet.
        spark.sql(f"CREATE TABLE IF NOT EXISTS {target} (\n  {body},\n  {meta}\n) "
                  f"USING DELTA CLUSTER BY AUTO")
        if exists:
            existed += 1
        else:
            created += 1

        # The TTL goes on in the same breath as the table, which is the whole point of this notebook.
        scfg = RET_SOURCES.get(system) or {}
        days = int(scfg.get("retention_days", RET_DEFAULTS["retention_days"]))
        ts_col = scfg.get("timestamp_column", RET_DEFAULTS["timestamp_column"])
        spark.sql(f"ALTER TABLE {target} DELETE ROWS {days} DAYS AFTER `{ts_col}`")
        ttl_set += 1
        print(f"{system}.{table:<34} {'ok' if exists else 'created'}  ttl={days}d on {ts_col}")
        log_checkpoint(f"{system}.{table} ensured, ttl {days}d", iteration=i, total=len(work))

    except Exception as e:
        failed += 1
        detail = " ".join(str(e).split())[:300]
        print(f"{system}.{table:<34} FAILED  {detail}")
        log_checkpoint(f"branch: {system}.{table} ensure failed = True ({detail})")

# -- the load job's own control tables. No personal data, watermarks and run history only.
if not DRY_RUN:
    ctrl = f"{CATALOG}.`{CTRL['schema']}`"
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {ctrl} "
              f"COMMENT 'Landing load control. Watermarks and run history, no personal data.'")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {ctrl}.`{CTRL['state_table']}` (
        source_system STRING, table_name STRING, source_table STRING,
        watermark STRING, watermark_column STRING,
        rows_last_load BIGINT, updated_at TIMESTAMP
    ) USING DELTA COMMENT 'How far each Landing table has been loaded.'""")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {ctrl}.`{CTRL['log_table']}` (
        run_id STRING, source_system STRING, table_name STRING, status STRING,
        selected BIGINT, loaded BIGINT, watermark_from STRING, watermark_to STRING,
        detail STRING, logged_at TIMESTAMP
    ) USING DELTA COMMENT 'Append-only history of Landing load runs.'""")
    log_checkpoint("control schema and tables ensured")

print()
print(f"created={created}  already_existed={existed}  ttl_applied={ttl_set}  failed={failed}")
log_checkpoint(f"run finished: created={created} existed={existed} ttl={ttl_set} failed={failed}")
if failed:
    raise RuntimeError(f"{failed} target(s) could not be ensured. Nothing should be loaded "
                       f"into this catalog until they are.")
