# Databricks notebook source
# LANDING_COMPLIANCE_MONITOR — the ADR's independent retention watcher (P1-03 / PRV-38).
# Read-only over the PII zone (aggregate reads only, never row contents). Three checks:
#   A. ttl_declared    — every table in a configured landing schema carries the auto-TTL
#                        properties and they match the config
#   B. oldest_row_age  — no table's oldest row exceeds its window + lag allowance
#                        (proof deletion is actually happening)
#   C. unmanaged       — every schema in the landing catalog is either configured or exempted
#   D. gate_lag        — recorded as not_applicable until the Gate exists (P1-10/11)
# Every check appends a row to the evidence log; the run FAILS (alert) if any check fails,
# but only after all evidence is written.
import yaml
from datetime import datetime, timezone
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint

start_global_notebook_logger()

dbutils.widgets.text("landing_catalog", "dev_landing")
dbutils.widgets.text("config_path", "")

CATALOG = dbutils.widgets.get("landing_catalog").strip()
CONFIG_PATH = dbutils.widgets.get("config_path").strip()
assert CATALOG and CONFIG_PATH, "Set landing_catalog and config_path."
log_checkpoint(f"variables creation: catalog={CATALOG}")

with open(CONFIG_PATH, encoding="utf-8") as f:
    cfg = yaml.safe_load(f)

defaults = cfg["defaults"]
LAG = int(defaults.get("lag_allowance_days", 7))
EV_SCHEMA = cfg["evidence"]["schema"]
EV_TABLE = f"{CATALOG}.`{EV_SCHEMA}`.`{cfg['evidence']['table']}`"
log_checkpoint(f"config loaded: {len(cfg['sources'])} sources, lag allowance {LAG}d, evidence -> {EV_TABLE}")

# Evidence must stay auditor-grade: appendOnly blocks UPDATE/DELETE on the log itself.
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.`{EV_SCHEMA}`")
spark.sql(f"""CREATE TABLE IF NOT EXISTS {EV_TABLE} (
    checked_at TIMESTAMP, catalog STRING, schema STRING, table STRING,
    check STRING, status STRING, detail STRING) USING DELTA
    TBLPROPERTIES ('delta.appendOnly' = 'true')""")
log_checkpoint("evidence schema and append-only table ensured")

now = datetime.now(timezone.utc)
evidence = []   # (schema, table, check, status, detail)

def props(fqn):
    return {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {fqn}").collect()}

# -- A + B: configured schemas -------------------------------------------------------
schemas_in_catalog = [r.databaseName for r in spark.sql(f"SHOW SCHEMAS IN {CATALOG}").collect()]
log_checkpoint(f"{len(schemas_in_catalog)} schemas listed in {CATALOG}")
n_sources = len(cfg["sources"])
for i, (src, scfg) in enumerate(cfg["sources"].items(), start=1):
    days = int((scfg or {}).get("retention_days", defaults["retention_days"]))
    ts_col = (scfg or {}).get("timestamp_column", defaults["timestamp_column"])
    if src not in schemas_in_catalog:
        evidence.append((src, "", "ttl_declared", "PENDING", "schema not created yet (live ingestion pending)"))
        log_checkpoint(f"branch: {src} present in catalog = False (recorded PENDING)")
        continue
    log_checkpoint(f"branch: {src} present in catalog = True")
    tables = spark.sql(f"SHOW TABLES IN {CATALOG}.`{src}`").collect()
    for j, r in enumerate(tables, start=1):
        fqn = f"{CATALOG}.`{src}`.`{r.tableName}`"
        # A broken table must not abort the run: the guarantee is that ALL evidence is
        # written before any failure, so per-table errors become FAIL evidence rows.
        try:
            p = props(fqn)
            declared = p.get("autottl.expireInDays")
            col = p.get("autottl.timestampColumn")
            if declared == str(days) and col == ts_col:
                evidence.append((src, r.tableName, "ttl_declared", "PASS", f"{declared}d on {col}"))
                log_checkpoint(f"branch: ttl_declared matches config on {src}.{r.tableName} = True")
            else:
                evidence.append((src, r.tableName, "ttl_declared", "FAIL",
                                 f"expected {days}d on {ts_col}, found {declared} on {col}"))
                log_checkpoint(f"branch: ttl_declared matches config on {src}.{r.tableName} = False (FAIL)")
            age = spark.sql(f"SELECT datediff(current_date(), CAST(min(`{ts_col}`) AS DATE)) AS d FROM {fqn}").collect()[0].d
            if age is None:
                evidence.append((src, r.tableName, "oldest_row_age", "PASS", "empty table"))
                log_checkpoint(f"branch: oldest_row_age on {src}.{r.tableName} = empty table (PASS)")
            elif age <= days + LAG:
                evidence.append((src, r.tableName, "oldest_row_age", "PASS", f"oldest={age}d limit={days + LAG}d"))
                log_checkpoint(f"branch: oldest {age}d <= limit {days + LAG}d on {src}.{r.tableName} = True (PASS)")
            else:
                evidence.append((src, r.tableName, "oldest_row_age", "FAIL", f"oldest={age}d limit={days + LAG}d"))
                log_checkpoint(f"branch: oldest {age}d <= limit {days + LAG}d on {src}.{r.tableName} = False (FAIL)")
        except Exception as e:
            evidence.append((src, r.tableName, "check_error", "FAIL", str(e)[:200]))
            log_checkpoint(f"branch: check errored on {src}.{r.tableName} = True (recorded FAIL, continuing)")
        log_checkpoint(f"checked {src}.{r.tableName}", iteration=j, total=len(tables))
    log_checkpoint(f"schema {src} checked (A+B)", iteration=i, total=n_sources)

# -- C: unmanaged schemas --------------------------------------------------------------
exempt_names = {e["name"] for e in cfg.get("exempt_schemas", []) if "name" in e}
exempt_prefixes = [e["prefix"] for e in cfg.get("exempt_schemas", []) if "prefix" in e]
managed = set(cfg["sources"].keys()) | exempt_names | {EV_SCHEMA, "default", "information_schema"}
for i, s in enumerate(schemas_in_catalog, start=1):
    if s in managed or any(s.startswith(p) for p in exempt_prefixes):
        log_checkpoint(f"branch: {s} managed or exempt = True", iteration=i, total=len(schemas_in_catalog))
        continue
    evidence.append((s, "", "unmanaged_schema", "FAIL",
                     "schema is neither a configured landing source nor exempted in retention_config.yml"))
    log_checkpoint(f"branch: {s} managed or exempt = False (unmanaged, FAIL)",
                   iteration=i, total=len(schemas_in_catalog))
log_checkpoint("check C (unmanaged schemas) done")

# -- D: gate lag (placeholder until the Gate ships) -----------------------------------
evidence.append(("", "", "gate_lag", "NOT_APPLICABLE", "Gate not deployed yet (P1-10/11)"))

# -- write evidence, then alert --------------------------------------------------------
rows = [(now, CATALOG, s, t, c, st, d) for s, t, c, st, d in evidence]
spark.createDataFrame(rows, "checked_at TIMESTAMP, catalog STRING, schema STRING, table STRING, check STRING, status STRING, detail STRING") \
     .write.mode("append").saveAsTable(EV_TABLE.replace("`", ""))

fails = [e for e in evidence if e[3] == "FAIL"]
print(f"checks: {len(evidence)}  PASS: {sum(1 for e in evidence if e[3] == 'PASS')}  "
      f"FAIL: {len(fails)}  evidence -> {EV_TABLE}")
for e in fails:
    print("  FAIL:", e)
log_checkpoint(f"monitor finished: {len(evidence)} checks, {len(fails)} FAIL, evidence appended to {EV_TABLE}")
if fails:
    raise Exception(f"{len(fails)} retention compliance check(s) failed — see evidence log")
