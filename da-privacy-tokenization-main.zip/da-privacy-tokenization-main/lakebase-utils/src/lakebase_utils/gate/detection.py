"""Column treatment detection for the Tokenize+Generalize Gate (PRV-57).

Given a source table, decide per column whether the gate must tokenize it
(vault element), generalize it (PTK-35 transform) or pass it through.

Three signals, in order of precedence:

1. **UC tags** — classification tags on the column (assigned by PTK-36
   ``ASSIGN_COLUMN_TAGS`` from ``system.data_classification.results``).
2. **Column name** — regex per element, user id checked first. Names are
   matched on a lower snake_case view (``CreatedByUserId`` and
   ``createdbyuserid`` both read as ``created_by_user_id``), and the user /
   account id patterns accept a preceding word (``created_by_user_id`` is a
   user id even though it does not start with ``user``) — the value check is
   what keeps that from over-matching.
3. **Values** — a sample confirms (or refutes) the name signal, and catches
   PII in a column whose name says nothing.

**User ids are vendor-aware.** ``user_id`` means a different thing in every
source: in a myQ table it is the anchor (``myq_user_id``); in a Braze,
Salesforce or Firebase table it is that vendor's own id, which belongs in
``external_user_id`` under its vendor so the identity graph keeps the two
apart (``UNIQUE (identifier_type, vendor, identifier_value_hmac)``). The
vendor comes from the column name first, then from the table name /
``_source_system``. A column that explicitly says ``myq`` is always the anchor.

Anchor ids must look like a myQ id (UUID or number) to be accepted; vendor ids
only have to look like an opaque id (no spaces, no ``@``), because every vendor
mints its own format. When values refute the name, the column is logged and
skipped — never an error.

Device elements (``dvc_/mac_/gwy_/srl_``) are intentionally absent (PTK-60).
Person names pass through: they are masked read-side (PTK-36), not tokenized.
"""

from __future__ import annotations

import re

# Third-party systems whose user ids must NOT be confused with the myQ anchor.
# myQ is deliberately absent: it is the first-party system of record.
VENDOR_KEYWORDS = (
    "braze", "salesforce", "sfmc", "firebase", "tealium",
    "zuora", "recurly", "sap", "dataaxle", "segment",
)

# tag (substring of tag name/value, uppercase) -> (action, target). Order matters.
TAG_MAP = {
    "EMAIL": ("tokenize", "email"),
    "PHONE": ("tokenize", "phone"),
    "IP_ADDRESS": ("generalize", "ipv4_subnet24"),
    "DATE_OF_BIRTH": ("generalize", "birth_year"),
    "POSTAL_CODE": ("generalize", "zip3"),
    "ZIP": ("generalize", "zip3"),
    "NAME": ("pass", None),  # mask read-side (PTK-36)
}

# column-name regex -> (action, target). Checked in order against the snake_case
# view of the name; the user id goes FIRST and is then re-pointed at the right
# element by the vendor rules above. The user/account id patterns have no left
# anchor on purpose: audit-style names (created_by_user_id, createdonaccountid)
# hold real ids too, and the value confirmation below screens the false hits.
NAME_MAP = [
    (r"(?i)(myq_?)?user_?id($|_)", ("tokenize", "myq_user_id")),
    (r"(?i)(^|_)(first|last|middle|full)_?name($|_)", ("pass", None)),
    (r"(?i)e[-_]?mail", ("tokenize", "email")),
    (r"(?i)phone|mobile|msisdn", ("tokenize", "phone")),
    (r"(?i)(external|salesforce|firebase|braze).*(user_?)?id", ("tokenize", "external_user_id")),
    (r"(?i)account_?id($|_)", ("tokenize", "account_id")),
    (r"(?i)(^|_)(date_of_birth|birth_?date|dob)($|_)|birth", ("generalize", "birth_year")),
    (r"(?i)zip|postal", ("generalize", "zip3")),
    (r"(?i)(^|_)ip(_?address)?($|_)", ("generalize", "ipv4_subnet24")),
]

# value regex per element: confirms a name hit, and (email/ipv4) sweeps columns
# whose name says nothing. A myQ id is a UUID or a plain number; a vendor id is
# any opaque token; both exclude anything with a space or an '@'.
VALUE_RE = {
    "email": re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
    "phone": re.compile(r"^\+?1?[-. (]*\d{3}[-. )]*\d{3}[-. ]*\d{4}(\.0)?$"),
    "ipv4": re.compile(r"^\d{1,3}(\.\d{1,3}){3}$"),
    "myq_user_id": re.compile(
        r"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|\d{5,15}(\.0)?)$"
    ),
    "external_user_id": re.compile(r"^[A-Za-z0-9._:|-]{4,64}$"),
    "account_id": re.compile(r"^[A-Za-z0-9._:|-]{4,64}$"),
}

# tokenize elements whose name signal must be confirmed by the values.
_CONFIRM = {"email", "phone", "myq_user_id", "external_user_id", "account_id"}

# column types that count as number-shaped (a numeric user_id is myQ-shaped by type).
_NUMERIC_TYPES = ("bigint", "int", "smallint", "tinyint", "long", "double", "float", "decimal")

MATCH_THRESHOLD = 0.8


def _snake(name: str) -> str:
    """Lower snake_case view of a column name, so the name patterns see
    CamelCase and snake_case alike (``CreatedByUserId`` -> ``created_by_user_id``,
    ``SCACCode`` -> ``scac_code``). All-lowercase names pass through unchanged."""
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", name)
    s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", "_", s)
    return s.lower()


def classify_column(
    name: str, dtype: str, tags: list[str], samples: list[str], vendor: str | None = None
) -> dict:
    """Classify one column. Pure function (unit-testable, no Spark).

    ``tags`` are the column's UC tag names/values, ``samples`` a list of
    non-null string values (empty for non-string columns or empty tables) and
    ``vendor`` the table's vendor when the source is a third-party system.
    Returns ``{"column", "action", "target", "vendor", "signal", "match_ratio"}``
    with ``action`` in ``tokenize | generalize | pass``.
    """
    result = {"column": name, "action": "pass", "target": None, "vendor": "",
              "signal": "none", "match_ratio": None}

    upper_tags = " ".join(tags).upper()
    for key, (action, target) in TAG_MAP.items():
        if key in upper_tags:
            return {**result, "action": action, "target": target, "signal": f"uc_tag:{key}"}

    # Name scan. A confirmable element whose values do not look right is NOT an
    # error: it falls through to the next patterns and, if nothing else claims
    # the column, it is skipped (pass) with a name_unconfirmed signal so the
    # decision is visible in the detection log. Patterns match the snake_case
    # view; the vendor keyword checks keep using the raw lowered name, because
    # snake_casing can split a keyword in two (DataAxle -> data_axle).
    snake_name = _snake(name)
    fallback = None
    for pattern, (action, target) in NAME_MAP:
        if not re.search(pattern, snake_name):
            continue
        out_vendor = ""

        # A user id belongs to whoever minted it: the column's own vendor wins,
        # then the table's. A column that says "myq" is always the anchor.
        if target in ("myq_user_id", "external_user_id"):
            col_vendor = next((v for v in VENDOR_KEYWORDS if v in name.lower()), None)
            effective = None if "myq" in name.lower() else (col_vendor or vendor)
            if effective:
                target, out_vendor = "external_user_id", effective
            else:
                target = "myq_user_id"

        if action == "tokenize" and target in _CONFIRM:
            if samples:
                ratio = sum(bool(VALUE_RE[target].match(v.strip())) for v in samples) / len(samples)
                if ratio >= MATCH_THRESHOLD:
                    return {**result, "action": action, "target": target, "vendor": out_vendor,
                            "signal": f"name+content:{target}", "match_ratio": round(ratio, 3)}
                fallback = {**result, "signal": f"name_unconfirmed:{target}", "match_ratio": round(ratio, 3)}
                continue
            # no sampled values: a numeric id column is id-shaped by type; an
            # email/phone name on a string column is accepted (nothing to refute)
            if target in ("myq_user_id", "external_user_id", "account_id") and dtype.startswith(_NUMERIC_TYPES):
                return {**result, "action": action, "target": target, "vendor": out_vendor,
                        "signal": f"name+dtype:{target}"}
            if target in ("email", "phone") and dtype.startswith("string"):
                return {**result, "action": action, "target": target, "signal": f"name:{target}"}
            fallback = {**result, "signal": f"name_unconfirmed:{target}"}
            continue
        return {**result, "action": action, "target": target, "vendor": out_vendor,
                "signal": f"name:{target}"}

    # value sweep: an undetected column whose values look like PII is treated anyway
    if samples:
        for key, (action, target) in (("email", ("tokenize", "email")),
                                      ("ipv4", ("generalize", "ipv4_subnet24"))):
            ratio = sum(bool(VALUE_RE[key].match(v.strip())) for v in samples) / len(samples)
            if ratio >= MATCH_THRESHOLD:
                return {**result, "action": action, "target": target,
                        "signal": f"content_only:{key}", "match_ratio": round(ratio, 3)}

    # nothing claimed the column: keep the unconfirmed-name trace if there was one
    return fallback or result


def detect_treatments(spark, fq_table: str, sample_rows: int = 1000) -> list[dict]:
    """Classify every column of ``fq_table`` (``catalog.schema.table``).

    Reads UC column tags, samples up to ``sample_rows`` rows for string columns,
    works out the table's vendor from its name and its ``_source_system`` values,
    and returns one :func:`classify_column` dict per column.
    """
    catalog, schema, table = fq_table.split(".")
    tag_rows = spark.sql(
        f"""SELECT column_name, tag_name, tag_value
            FROM {catalog}.information_schema.column_tags
            WHERE schema_name = '{schema}' AND table_name = '{table}'"""
    ).collect()
    tags: dict[str, list[str]] = {}
    for r in tag_rows:
        tags.setdefault(r["column_name"], []).extend([r["tag_name"] or "", r["tag_value"] or ""])

    df = spark.table(fq_table)
    string_cols = [f.name for f in df.schema.fields if f.dataType.simpleString() == "string"]
    # Random sample, not the head of the table: a sparse column (2% filled) can look
    # empty in the first N rows and dodge the value confirmation. Sort by a random
    # key and take the top N - one scan of the string columns, no full shuffle.
    if string_cols:
        from pyspark.sql import functions as F

        sampled = df.select(string_cols).orderBy(F.rand()).limit(sample_rows).toPandas()
    else:
        sampled = None

    # Vendor of the whole table: its qualified name plus whatever the rows say
    # they came from. Absent means first-party (myQ), so user ids are anchors.
    hint = fq_table.lower()
    if sampled is not None and "_source_system" in sampled.columns:
        hint += " " + " ".join(str(v).lower() for v in sampled["_source_system"].dropna().unique()[:5])
    vendor = next((v for v in VENDOR_KEYWORDS if v in hint), None)

    results = []
    for field in df.schema.fields:
        samples = []
        if sampled is not None and field.name in sampled.columns:
            samples = [str(v) for v in sampled[field.name].dropna().tolist() if str(v).strip()]
        results.append(
            classify_column(field.name, field.dataType.simpleString(), tags.get(field.name, []),
                            samples, vendor)
        )
    return results
