import hmac
import hashlib
import os
import re

from .normalize import normalize, normalize_or_none


_WORKSPACE_ID_TO_SCOPE: dict[str, str] = {
    "4042327885044706": "cgi-eus-dev-ada-kv",
    "1819088249724627": "cgi-eus-qa-ada-kv",
    "526483533147103": "cgi-eus-prod-ada-kv",
}


def _extract_workspace_id(host_or_url: str) -> str | None:
    """Extract Databricks workspace id from a host/url like adb-12345.x.azuredatabricks.net."""
    match = re.search(r"adb-(\d+)", host_or_url)
    if not match:
        return None
    return match.group(1)


def fetch_secret_scope() -> str:
    """Return the IDR secret scope for the current Databricks workspace.

    Resolution order:
    1. ``IDR_PEPPER_SECRET_SCOPE`` environment variable.
    2. Active Spark session config ``spark.databricks.workspaceUrl``.
    3. Databricks SDK ``WorkspaceClient().config.host``.
    """
    scope = os.environ.get("IDR_PEPPER_SECRET_SCOPE")
    if scope:
        return scope

    workspace_id = None
    try:
        from pyspark.sql import SparkSession  # type: ignore[import-not-found]

        spark = SparkSession.getActiveSession()
        if spark is not None:
            workspace_url = spark.conf.get("spark.databricks.workspaceUrl", None)
            if workspace_url:
                workspace_id = _extract_workspace_id(workspace_url)
    except Exception:
        workspace_id = None

    if workspace_id is None:
        try:
            from databricks.sdk import WorkspaceClient  # type: ignore[import-not-found]

            workspace_id = _extract_workspace_id(WorkspaceClient().config.host)
        except Exception:
            workspace_id = None

    if workspace_id is None:
        raise RuntimeError(
            "Could not determine Databricks workspace id. "
            "Set IDR_PEPPER_SECRET_SCOPE explicitly."
        )

    mapped_scope = _WORKSPACE_ID_TO_SCOPE.get(workspace_id)
    if mapped_scope is None:
        raise RuntimeError(
            f"No secret scope mapping found for workspace id {workspace_id}. "
            "Set IDR_PEPPER_SECRET_SCOPE explicitly or extend _WORKSPACE_ID_TO_SCOPE."
        )
    return mapped_scope


def compute_hmac(pepper: bytes, identifier_type: str, value: str) -> str:
    """Return hex-encoded HMAC-SHA256(pepper, normalize(value)).

    The pepper is held in process memory only — it is never sent to Postgres.
    This function is the sole place where raw identifier values are handled;
    all Postgres calls receive the finished hex digest.
    """
    normalized = normalize(identifier_type, value)
    digest = hmac.new(pepper, normalized.encode("utf-8"), hashlib.sha256).hexdigest()
    return digest


def compute_hmac_or_none(pepper: bytes, identifier_type: str, value: object) -> str | None:
    """Return an HMAC for normalizable values, or None for unusable source values."""
    normalized = normalize_or_none(identifier_type, value)
    if normalized is None:
        return None
    digest = hmac.new(pepper, normalized.encode("utf-8"), hashlib.sha256).hexdigest()
    return digest


def compute_hmac_with_context_or_none(
    pepper: bytes, identifier_type: str, value: object, *, context: str
) -> str | None:
    """Nullable variant of :func:`compute_hmac_with_context`."""
    normalized = normalize_or_none(identifier_type, value)
    if normalized is None:
        return None
    message = f"{context}:{normalized}"
    digest = hmac.new(pepper, message.encode("utf-8"), hashlib.sha256).hexdigest()
    return digest