"""Identity Resolution (IDR) — Spark-native find-or-mint engine.

The whole resolution flow lives in :mod:`lakebase_utils.idr.resolution`:
compute HMACs in Spark, diff the source against the existing identity tables in
Lakebase, mint new canonicals deterministically, bulk-write only the new rows,
and left-join the canonical back onto the source.

Usage::

    from lakebase_utils.postgres.connection import ptk_connect
    from lakebase_utils.idr import resolve_users, resolve_accounts, link_user_accounts

    ptk_connect(host=..., db=..., user=..., password=...)   # once, at startup
    users = resolve_users(source_df, spark=spark)
    accts = resolve_accounts(users, spark=spark)
    link_user_accounts(accts, spark=spark)
"""
from .resolution import (
    resolve_users,
    resolve_accounts,
    link_user_accounts,
    USER_ANCHOR_TYPE,
    ACCOUNT_ANCHOR_TYPE,
)

__all__ = [
    # Spark API
    "resolve_users",
    "resolve_accounts",
    "link_user_accounts",
    # Constants
    "USER_ANCHOR_TYPE",
    "ACCOUNT_ANCHOR_TYPE",
]
