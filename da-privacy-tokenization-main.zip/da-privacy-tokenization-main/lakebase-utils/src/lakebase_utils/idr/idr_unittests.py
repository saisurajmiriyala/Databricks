"""Consolidated unit tests for the IDR package (lakebase_utils.idr).

Combines the former tests/idr/ modules into a single file:
  * normalize   — normalization/HMAC correctness (no DB or infra required)
  * pepper      — PepperProvider configuration resolution
  * resolution  — Spark-native IDR engine (pyspark required; Lakebase mocked)
"""
import uuid
from contextlib import contextmanager
from unittest.mock import patch

import pytest

from lakebase_utils.idr.normalize import is_null_identifier_value, normalize, normalize_or_none
from lakebase_utils.idr.hmac_util import compute_hmac
from lakebase_utils.idr.pepper import PepperProvider


# ===========================================================================
# normalize
# ===========================================================================
#
# Normalization bugs mint duplicate identities silently, so this is the
# highest-value test section in the package.

# ---------------------------------------------------------------------------
# null identifier handling
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "value",
    [None, "", " ", "null", " NULL ", "None", "nan", float("nan")],
)
def test_null_identifier_values_are_detected(value):
    assert is_null_identifier_value(value)


def test_null_like_substrings_are_not_treated_as_nulls():
    assert not is_null_identifier_value("null@example.com")


@pytest.mark.parametrize("identifier_type", ["email", "phone", "myq_user_id", "external_user_id"])
def test_normalize_rejects_null_identifier_values(identifier_type):
    with pytest.raises(ValueError, match="Cannot normalize null identifier value"):
        normalize(identifier_type, "null")


# ---------------------------------------------------------------------------
# email
# ---------------------------------------------------------------------------

class TestEmailNormalizer:
    def test_casefold_local_and_domain(self):
        assert normalize("email", "Alice@Example.COM") == normalize("email", "alice@example.com")

    def test_leading_trailing_whitespace(self):
        assert normalize("email", "  alice@example.com  ") == normalize("email", "alice@example.com")

    def test_mixed_case_unicode(self):
        assert normalize("email", "ALICE@EXAMPLE.COM") == "alice@example.com"

    def test_nfc_normalization(self):
        # é as precomposed (U+00E9) vs. decomposed (e + U+0301)
        precomposed = "café@example.com"
        decomposed  = "café@example.com"
        assert normalize("email", precomposed) == normalize("email", decomposed)

    def test_same_hmac_different_casing(self):
        pepper = b"test-pepper"
        h1 = compute_hmac(pepper, "email", "Alice@Example.com")
        h2 = compute_hmac(pepper, "email", "alice@example.com")
        assert h1 == h2

    def test_different_emails_different_hmac(self):
        pepper = b"test-pepper"
        h1 = compute_hmac(pepper, "email", "alice@example.com")
        h2 = compute_hmac(pepper, "email", "bob@example.com")
        assert h1 != h2


# ---------------------------------------------------------------------------
# stubs — pass-through only, normalization not yet implemented
# ---------------------------------------------------------------------------

class TestPhoneNormalizer:
    def test_plain_10_digit(self):
        assert normalize("phone", "7194448455") == "719-444-8455"

    def test_dashed(self):
        assert normalize("phone", "801-400-0003") == "801-400-0003"

    def test_spaces(self):
        assert normalize("phone", "832 607 9887") == "832-607-9887"

    def test_parens_with_space(self):
        assert normalize("phone", "(508) 428-9293") == "508-428-9293"

    def test_parens_no_space(self):
        assert normalize("phone", "(403)280-2000") == "403-280-2000"

    def test_plus_prefix_stripped(self):
        assert normalize("phone", "+14783081228") == "478-308-1228"

    def test_11_digit_leading_1(self):
        assert normalize("phone", "14783081228") == "478-308-1228"

    def test_float_suffix(self):
        assert normalize("phone", "3128617834.0") == "312-861-7834"

    def test_leading_trailing_whitespace(self):
        assert normalize("phone", "  7194448455  ") == "719-444-8455"

    def test_same_number_different_formats_same_hmac(self):
        """Formatting differences must not produce duplicate identities."""
        formats = ["8014000003", "801-400-0003", "(801) 400-0003", "18014000003"]
        hashes = [compute_hmac(b"test-pepper", "phone", normalize("phone", f)) for f in formats]
        assert len(set(hashes)) == 1

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            normalize("phone", "1234")

    def test_invalid_nullable_returns_none(self):
        assert normalize_or_none("phone", "559403822#") is None


class TestStubs:
    def test_myq_user_id_uppercase(self):
        assert normalize("myq_user_id", "  23c085ce-7558-4875-9887-03e1709cafac  ") == (
            "23C085CE-7558-4875-9887-03E1709CAFAC"
        )

    def test_myq_user_id_same_hmac_different_casing(self):
        pepper = b"test-pepper"
        h1 = compute_hmac(pepper, "myq_user_id", "23c085ce-7558-4875-9887-03e1709cafac")
        h2 = compute_hmac(pepper, "myq_user_id", "23C085CE-7558-4875-9887-03E1709CAFAC")
        assert h1 == h2

    def test_external_user_id_passthrough(self):
        assert normalize("external_user_id", "0036R00003XwWuDQAV") == "0036R00003XwWuDQAV"

    def test_firebase_external_user_id_passthrough(self):
        assert normalize("external_user_id", "firebase_AbCdEf123") == "firebase_AbCdEf123"

    def test_account_id_passthrough(self):
        assert normalize("account_id", "ACC-001") == "ACC-001"

    def test_unknown_type_passthrough(self):
        assert normalize("unknown_type_xyz", "Hello") == "Hello"


# ---------------------------------------------------------------------------
# vendor='salesforce' email routing guard (documented contract, not normalizer)
# ---------------------------------------------------------------------------

class TestVendorEmailContract:
    def test_email_from_salesforce_and_generic_same_hmac(self):
        """email identifier MUST use the same normalizer regardless of source."""
        pepper = b"test-pepper"
        h_sf    = compute_hmac(pepper, "email", "alice@example.com")
        h_plain = compute_hmac(pepper, "email", "alice@example.com")
        assert h_sf == h_plain


# ===========================================================================
# pepper
# ===========================================================================

def test_idr_pepper_env_var_is_used_for_local_runs(monkeypatch):
    monkeypatch.setenv("IDR_PEPPER", "local-test-pepper")
    monkeypatch.delenv("IDR_PEPPER_SECRET_SCOPE", raising=False)
    monkeypatch.delenv("IDR_PEPPER_SECRET_KEY", raising=False)

    assert PepperProvider().get("email") == b"local-test-pepper"


def test_missing_pepper_configuration_raises_helpful_error(monkeypatch):
    monkeypatch.delenv("IDR_PEPPER", raising=False)
    monkeypatch.delenv("IDR_PEPPER_SECRET_SCOPE", raising=False)
    monkeypatch.delenv("IDR_PEPPER_SECRET_KEY", raising=False)

    with pytest.raises(RuntimeError, match="IDR pepper is not configured"):
        PepperProvider().get("email")


# ===========================================================================
# resolution
# ===========================================================================
#
# Requires pyspark; skipped where it is not installed. The Lakebase read/write
# (``ptk_read_dataframe`` / ``ptk_write_dataframe``) is mocked so no DB is
# needed: reads return in-memory pandas frames and writes are captured for
# assertions.

import pandas as pd

pyspark = pytest.importorskip("pyspark", reason="pyspark not installed")

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from lakebase_utils.idr import resolution
from lakebase_utils.idr.resolution import (
    resolve_users,
    resolve_accounts,
    link_user_accounts,
)

_PEPPER = b"test-pepper"


@pytest.fixture(scope="module")
def spark():
    try:
        return (
            SparkSession.builder.master("local[1]")
            .appName("test_idr_resolution")
            .config("spark.ui.enabled", "false")
            .config("spark.sql.shuffle.partitions", "1")
            .getOrCreate()
        )
    except Exception as exc:  # pragma: no cover - depends on local JVM
        pytest.skip(f"SparkSession unavailable (JVM missing?): {exc}")


@pytest.fixture(autouse=True)
def _pepper_env(monkeypatch):
    monkeypatch.setenv("IDR_PEPPER", _PEPPER.decode())
    # Reset the module-level pepper cache so the env value above is used.
    resolution._pepper_provider._cache.clear()


def _hmac(itype, value):
    return compute_hmac(_PEPPER, itype, value)


def _is_uuid4(value) -> bool:
    try:
        return uuid.UUID(str(value)).version == 4
    except (ValueError, TypeError, AttributeError):
        return False


_ID_COLS = ["identifier_type", "vendor", "identifier_value_hmac", "canonical"]


@contextmanager
def mock_db(user_rows=None, account_rows=None, edge_rows=None):
    """Patch the ptk_* helpers. ``*_rows`` are lists of dicts; writes are captured.

    ``user_rows`` / ``account_rows``: dicts with keys identifier_type, vendor,
    identifier_value_hmac, canonical. ``edge_rows``: (canonical_user_id,
    canonical_account_id) dicts.
    """
    writes: dict[str, list[dict]] = {}

    def _existing_pdf(rows):
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(
            [[r["identifier_type"], r["vendor"], r["identifier_value_hmac"], r["canonical"]] for r in rows]
        )

    def fake_read(sql, params=None):
        if "user_identifier" in sql:
            return _existing_pdf(user_rows)
        if "account_identifier" in sql:
            return _existing_pdf(account_rows)
        if "user_account_edge" in sql:
            if not edge_rows:
                return pd.DataFrame()
            return pd.DataFrame(
                [[r["canonical_user_id"], r["canonical_account_id"]] for r in edge_rows]
            )
        return pd.DataFrame()

    def fake_write(df, table):
        writes.setdefault(table, []).extend([row.asDict() for row in df.collect()])

    with patch.object(resolution, "ptk_read_dataframe", side_effect=fake_read), patch.object(
        resolution, "ptk_write_dataframe", side_effect=fake_write
    ):
        yield writes


# ---------------------------------------------------------------------------
# resolve_users
# ---------------------------------------------------------------------------

class TestResolveUsers:
    def test_new_anchor_mints_and_writes_parent_and_children(self, spark):
        df = spark.createDataFrame(
            [("USER-1", "alice@example.com")],
            schema="myq_user_id STRING, email STRING",
        )
        with mock_db() as writes:
            result = resolve_users(df, spark=spark, phone_col=None)
            row = result.collect()[0]

        canonical = row["canonical_user_id"]
        assert _is_uuid4(canonical)  # fresh random uuid4
        # Parent identity row written for exactly the minted canonical.
        parents = writes["identity.user_identity"]
        assert [p["canonical_user_id"] for p in parents] == [canonical]
        # Child identifier rows: anchor + email, both linked to the SAME canonical
        # the source row got (mint materialised once → consistent everywhere).
        children = writes["identity.user_identifier"]
        types = {c["identifier_type"] for c in children}
        assert types == {"myq_user_id", "email"}
        assert all(c["canonical_user_id"] == canonical for c in children)

    def test_new_ids_are_random_across_runs(self, spark):
        """With nothing pre-existing, independent runs mint different uuid4s."""
        df = spark.createDataFrame([("USER-R",)], schema="myq_user_id STRING")
        with mock_db():
            a = resolve_users(df, spark=spark, email_col=None, phone_col=None).collect()[0]
        with mock_db():
            b = resolve_users(df, spark=spark, email_col=None, phone_col=None).collect()[0]
        assert _is_uuid4(a["canonical_user_id"]) and _is_uuid4(b["canonical_user_id"])
        assert a["canonical_user_id"] != b["canonical_user_id"]

    def test_existing_anchor_hit_writes_no_new_parent(self, spark):
        existing = [
            {"identifier_type": "myq_user_id", "vendor": "", "identifier_value_hmac": _hmac("myq_user_id", "USER-1"), "canonical": "CANON-X"},
            {"identifier_type": "email", "vendor": "", "identifier_value_hmac": _hmac("email", "alice@example.com"), "canonical": "CANON-X"},
        ]
        df = spark.createDataFrame(
            [("USER-1", "alice@example.com")],
            schema="myq_user_id STRING, email STRING",
        )
        with mock_db(user_rows=existing) as writes:
            result = resolve_users(df, spark=spark, phone_col=None)
            row = result.collect()[0]

        assert row["canonical_user_id"] == "CANON-X"
        assert "identity.user_identity" not in writes  # nothing minted
        assert "identity.user_identifier" not in writes  # both identifiers already stored

    def test_secondary_conflict_is_skipped(self, spark):
        """An email already owned by a different canonical is not re-linked."""
        existing = [
            {"identifier_type": "email", "vendor": "", "identifier_value_hmac": _hmac("email", "shared@example.com"), "canonical": "CANON-OTHER"},
        ]
        df = spark.createDataFrame(
            [("USER-NEW", "shared@example.com")],
            schema="myq_user_id STRING, email STRING",
        )
        with mock_db(user_rows=existing) as writes:
            result = resolve_users(df, spark=spark, phone_col=None)
            row = result.collect()[0]

        # The row keeps its own (minted-from-anchor) canonical, not the email's.
        assert _is_uuid4(row["canonical_user_id"])
        assert row["canonical_user_id"] != "CANON-OTHER"
        # Only the anchor child is written; the conflicting email is skipped.
        children = writes["identity.user_identifier"]
        assert {c["identifier_type"] for c in children} == {"myq_user_id"}

    def test_null_anchor_with_email_mints_from_email(self, spark):
        df = spark.createDataFrame(
            [(None, "bob@example.com")],
            schema="myq_user_id STRING, email STRING",
        )
        with mock_db() as writes:
            result = resolve_users(df, spark=spark, phone_col=None)
            row = result.collect()[0]

        canonical = row["canonical_user_id"]
        assert _is_uuid4(canonical)
        parents = writes["identity.user_identity"]
        assert [p["canonical_user_id"] for p in parents] == [canonical]

    def test_null_anchor_no_secondary_stays_null(self, spark):
        df = spark.createDataFrame(
            [(None, None)], schema="myq_user_id STRING, email STRING"
        )
        with mock_db() as writes:
            result = resolve_users(df, spark=spark, phone_col=None)
            row = result.collect()[0]
        assert row["canonical_user_id"] is None
        assert "identity.user_identity" not in writes

    def test_source_columns_preserved(self, spark):
        df = spark.createDataFrame(
            [("USER-1", "alice@example.com", "extra")],
            schema="myq_user_id STRING, email STRING, extra_col STRING",
        )
        with mock_db():
            result = resolve_users(df, spark=spark, phone_col=None)
        assert "extra_col" in result.columns
        assert "canonical_user_id" in result.columns
        assert "_idr_anchor_hmac" not in result.columns
        assert result.count() == 1


# ---------------------------------------------------------------------------
# resolve_accounts
# ---------------------------------------------------------------------------

class TestResolveAccounts:
    def test_new_account_mints(self, spark):
        df = spark.createDataFrame([("ACC-1",)], schema="account_id STRING")
        with mock_db() as writes:
            result = resolve_accounts(df, spark=spark)
            row = result.collect()[0]
        canonical = row["canonical_account_id"]
        assert _is_uuid4(canonical)
        assert [p["canonical_account_id"] for p in writes["identity.account_identity"]] == [
            canonical
        ]

    def test_existing_account_hit(self, spark):
        existing = [
            {"identifier_type": "account_id", "vendor": "", "identifier_value_hmac": _hmac("account_id", "ACC-1"), "canonical": "ACANON"},
        ]
        df = spark.createDataFrame([("ACC-1",)], schema="account_id STRING")
        with mock_db(account_rows=existing) as writes:
            result = resolve_accounts(df, spark=spark)
            row = result.collect()[0]
        assert row["canonical_account_id"] == "ACANON"
        assert "identity.account_identity" not in writes

    def test_null_account_stays_null(self, spark):
        df = spark.createDataFrame([(None,)], schema="account_id STRING")
        with mock_db():
            row = resolve_accounts(df, spark=spark).collect()[0]
        assert row["canonical_account_id"] is None


# ---------------------------------------------------------------------------
# link_user_accounts
# ---------------------------------------------------------------------------

_U = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
_A1 = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
_A2 = "cccccccc-cccc-cccc-cccc-cccccccccccc"


class TestLinkUserAccounts:
    def test_new_edges_written(self, spark):
        df = spark.createDataFrame(
            [(_U, _A1), (_U, _A1), (_U, _A2)],
            schema="canonical_user_id STRING, canonical_account_id STRING",
        )
        with mock_db() as writes:
            count = link_user_accounts(df, spark=spark)
        assert count == 2  # distinct pairs
        pairs = {(e["canonical_user_id"], e["canonical_account_id"]) for e in writes["identity.user_account_edge"]}
        assert pairs == {(_U, _A1), (_U, _A2)}

    def test_existing_edge_is_diffed_out(self, spark):
        df = spark.createDataFrame(
            [(_U, _A1), (_U, _A2)],
            schema="canonical_user_id STRING, canonical_account_id STRING",
        )
        existing = [{"canonical_user_id": _U, "canonical_account_id": _A1}]
        with mock_db(edge_rows=existing) as writes:
            count = link_user_accounts(df, spark=spark)
        assert count == 1
        pairs = {(e["canonical_user_id"], e["canonical_account_id"]) for e in writes["identity.user_account_edge"]}
        assert pairs == {(_U, _A2)}

    def test_null_canonicals_skipped(self, spark):
        df = spark.createDataFrame(
            [(None, _A1), (_U, None)],
            schema="canonical_user_id STRING, canonical_account_id STRING",
        )
        with mock_db() as writes:
            count = link_user_accounts(df, spark=spark)
        assert count == 0
        assert "identity.user_account_edge" not in writes
