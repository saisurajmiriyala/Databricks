"""Per-identifier-type pepper loading via Databricks Secrets."""
import os
import threading

from .hmac_util import fetch_secret_scope


_SECRET_KEY_BY_TYPE: dict[str, str] = {
    "email":            "ptk-vault-email",
    "phone":            "ptk-vault-phone",
    "account_id":       "ptk-vault-account-id",
    "myq_user_id":      "ptk-vault-user-id",
    "external_user_id": "ptk-vault-external-user-id",
}


class PepperProvider:
    """Loads the HMAC pepper per identifier type and caches each for the process lifetime.

    Priority
    --------
    1. ``IDR_PEPPER`` env var (UTF-8 encoded) — same value for every type, used in local tests.
     2. Databricks Secrets at ``IDR_PEPPER_SECRET_SCOPE`` / <type-specific key> when provided.
     3. Workspace-derived Databricks secret scope via :func:`fetch_secret_scope`.
    """

    def __init__(self) -> None:
        self._cache: dict[str, bytes] = {}
        self._lock = threading.Lock()

    def get(self, identifier_type: str) -> bytes:
        try:
            return self._cache[identifier_type]
        except KeyError:
            pass
        with self._lock:
            if identifier_type not in self._cache:
                self._cache[identifier_type] = self._load(identifier_type)
            return self._cache[identifier_type]

    def _load(self, identifier_type: str) -> bytes:
        raw = os.environ.get("IDR_PEPPER")
        if raw:
            return raw.encode()

        try:
            scope = fetch_secret_scope()
        except RuntimeError as exc:
            raise RuntimeError(
                "IDR pepper is not configured. Set IDR_PEPPER for local tests, "
                "or provide IDR_PEPPER_SECRET_SCOPE / workspace mapping for Databricks runtime."
            ) from exc

        secret_key = _SECRET_KEY_BY_TYPE.get(identifier_type)
        if secret_key is None:
            raise RuntimeError(
                f"No secret key mapped for identifier_type {identifier_type!r}. "
                f"Known types: {sorted(_SECRET_KEY_BY_TYPE)}"
            )

        try:
            from databricks.sdk.runtime import dbutils  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError(
                "Databricks secret lookup requires databricks.sdk.runtime.dbutils. "
                "Set IDR_PEPPER for local runs outside Databricks."
            ) from exc

        return dbutils.secrets.get(scope, secret_key).encode()
