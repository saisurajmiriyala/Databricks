"""Spark-native identity resolution — the single IDR engine.

All find-or-mint compute runs in Spark.
For each namespace (user / account) and for the user↔account relationship we:

1. Compute the HMAC of every identifier value as a Spark column. The identity
   tables store only HMACs, never plaintext, so the existence-join must happen
   on the HMAC. Normalisation + HMAC reuse :mod:`normalize` / :mod:`hmac_util`;
   the per-type pepper is broadcast to executors.
2. Read the existing identifier table from Lakebase once, via
   :func:`lakebase_utils.postgres.queryhub.ptk_read_dataframe`.
3. Left-join source vs existing to classify HIT (existing canonical) vs NEW.
4. Mint a fresh random ``uuid4`` for every NEW anchor. Minting happens once on
   the driver — collect the new HMACs, mint in Python, and build a literal
   ``(hmac -> canonical)`` DataFrame — so the random value is baked into the
   plan as data. Every downstream Spark job (parent write, child write, source
   enrichment) then sees the identical UUID, with no double-minting (a random
   UDF would be recomputed to different values per job). Idempotency across runs
   comes from step 3: an identifier already in Lakebase keeps its stored
   canonical, so the mint only ever fires for genuinely new identifiers.
5. Bulk-write only the NEW parent (``*_identity``) then child
   (``*_identifier``) rows via
   :func:`lakebase_utils.postgres.queryhub.ptk_write_dataframe` (COPY), parent
   before child so the FK holds.
6. Left-join the canonical back onto every source row.

Connection: the engine reuses the existing ``ptk_*`` helpers, which talk to the
connection established by
:func:`lakebase_utils.postgres.connection.ptk_connect`. Call ``ptk_connect(...)``
once before invoking the resolvers (the bundle notebooks do this at startup).

Single-writer assumption: the diff-then-COPY has no atomic guard, so run one
batch writer at a time. Concurrency would need ON CONFLICT / re-read hardening.

Requires PySpark (``pip install lakebase-utils[spark]``).
"""
from __future__ import annotations

import logging
import os
import uuid as _uuid

import pandas as pd
from pyspark.sql import Column, DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, StructField, StructType
from pyspark.sql.functions import udf

from lakebase_utils.postgres.queryhub import ptk_read_dataframe, ptk_write_dataframe

from .hmac_util import compute_hmac_or_none
from .normalize import NULL_IDENTIFIER_TOKENS
from .pepper import PepperProvider

_logger = logging.getLogger("lakebase_utils.idr.resolution")

# ---------------------------------------------------------------------------
# Schema constants (see lakebase-db/migrations/V6__user_identity_graph.sql)
# ---------------------------------------------------------------------------
# Schema of the identity graph. Overridable via IDR_SCHEMA (set it BEFORE importing
# this module); the schema was renamed identity -> cg_identity in migration V40.
_SCHEMA = os.environ.get("IDR_SCHEMA") or "cg_identity"

USER_IDENTITY_TABLE = f"{_SCHEMA}.user_identity"
USER_IDENTIFIER_TABLE = f"{_SCHEMA}.user_identifier"
ACCOUNT_IDENTITY_TABLE = f"{_SCHEMA}.account_identity"
ACCOUNT_IDENTIFIER_TABLE = f"{_SCHEMA}.account_identifier"
USER_ACCOUNT_EDGE_TABLE = f"{_SCHEMA}.user_account_edge"

USER_ANCHOR_TYPE = "myq_user_id"
ACCOUNT_ANCHOR_TYPE = "account_id"

_IDENTIFIER_COLS = ("identifier_type", "vendor", "identifier_value_hmac")

# Shared, process-wide pepper provider (loads per-type peppers lazily on the
# driver; cached for the process lifetime).
_pepper_provider = PepperProvider()


# ---------------------------------------------------------------------------
# Column / UDF helpers
# ---------------------------------------------------------------------------

def _present(value_col: Column) -> Column:
    """True when a value is neither null nor a null-token (e.g. ``"null"``)."""
    normalized = F.lower(F.trim(value_col.cast("string")))
    return value_col.isNotNull() & (~normalized.isin(sorted(NULL_IDENTIFIER_TOKENS)))


def _temp_col(df: DataFrame, base: str) -> str:
    """Return a column name not already present in ``df``."""
    if base not in df.columns:
        return base
    i = 1
    while f"{base}_{i}" in df.columns:
        i += 1
    return f"{base}_{i}"


def _load_peppers(identifier_types: set[str]) -> dict[str, bytes]:
    """Load the per-type pepper bytes on the driver (from env / Databricks secret)."""
    return {itype: _pepper_provider.get(itype) for itype in identifier_types}


def _make_hmac_udf(peppers: dict[str, bytes], identifier_type: str):
    """Build a UDF that maps a raw value to hex HMAC(normalize(value)), or null.

    Delegates to :func:`compute_hmac_or_none` so the HMAC matches the historical
    (driver-side) path exactly: null/blank → null, phone that cannot be
    normalised → null. HMAC is a pure function, so the UDF is deterministic and
    safe under Spark task retries.
    """
    pepper = peppers[identifier_type]

    def _hmac(value):
        return compute_hmac_or_none(pepper, identifier_type, value)

    return udf(_hmac, StringType())


def _mint_new_map(
    spark: SparkSession,
    distinct_hmac_df: DataFrame,
    hmac_col: str,
    canonical_col: str,
) -> DataFrame:
    """Mint a random ``uuid4`` canonical for each distinct HMAC

    The HMACs are collected to the driver, a fresh ``uuid4`` is minted per HMAC
    in Python, and the ``(hmac -> canonical)`` mapping is returned as a literal
    Spark DataFrame. Because the values are baked into the plan as data (not a
    nondeterministic UDF), every downstream job that reads this frame — parent
    write, child write, source enrichment — sees the identical UUID.

    The caller must pass a DISTINCT frame of only the NEW HMACs (those not
    already in Lakebase); this is the sole place canonicals are minted.

    The driver round-trip is Arrow-backed (``toPandas`` /
    ``createDataFrame(pandas)``) — one columnar transfer instead of the
    row-by-row pickle path, which dominates runtime on large mints.
    """
    schema = StructType(
        [StructField(hmac_col, StringType()), StructField(canonical_col, StringType())]
    )
    pdf = (
        distinct_hmac_df.select(hmac_col)
        .where(F.col(hmac_col).isNotNull())
        .toPandas()
    )
    if pdf.empty:
        return spark.createDataFrame([], schema)
    pdf[canonical_col] = [str(_uuid.uuid4()) for _ in range(len(pdf))]
    return spark.createDataFrame(pdf, schema)


# ---------------------------------------------------------------------------
# Lakebase read / write (reuse the existing ptk_* helpers, no pool)
# ---------------------------------------------------------------------------

def _read_identifier_table(
    spark: SparkSession, table: str, canonical_col: str
) -> DataFrame:
    """Read the full active identifier table into a Spark DataFrame.

    An empty/first-run table yields a typed empty DataFrame via the explicit schema.
    """
    cols = [*_IDENTIFIER_COLS, canonical_col]
    schema = StructType([StructField(c, StringType()) for c in cols])
    col_list = ", ".join(cols)
    sql = (
        f"SELECT {col_list} FROM {table} "
        "WHERE deletion_status = 'active'"
    )
    pdf = ptk_read_dataframe(sql)
    if pdf is None or len(pdf) == 0:
        return spark.createDataFrame([], schema)
    # ptk_read_dataframe column labels depend on the driver's row factory; align
    # positionally to the SELECT order to be robust.
    pdf = pdf.copy()
    pdf.columns = cols
    pdf = pdf.astype(object).where(pd.notnull(pdf), None)
    return spark.createDataFrame(pdf, schema).cache()


def _write_new_rows(df: DataFrame, table: str, label: str) -> int:
    """COPY ``df`` into ``table`` (only rows the caller already diffed as new)."""
    count = df.count()
    if count == 0:
        _logger.info("IDR %s: nothing new to write", label)
        return 0
    ptk_write_dataframe(df, table)
    _logger.info("IDR %s: wrote %d new rows to %s", label, count, table)
    return count


# ---------------------------------------------------------------------------
# Shared find-or-mint core
# ---------------------------------------------------------------------------

def _anchor_lookup(
    existing: DataFrame, anchor_type: str, hmac_col: str, canonical_col: str
) -> DataFrame:
    """Existing (anchor hmac → canonical) rows for one namespace's anchor type."""
    return (
        existing.filter(
            (F.col("identifier_type") == anchor_type) & (F.col("vendor") == "")
        )
        .select(
            F.col("identifier_value_hmac").alias(hmac_col),
            F.col(canonical_col),
        )
        # UNIQUE(identifier_type, vendor, identifier_value_hmac) ⇒ already 1:1,
        # dropDuplicates is a cheap guard against any dirty data.
        .dropDuplicates([hmac_col])
    )


def _resolve_anchor(
    df: DataFrame,
    *,
    spark: SparkSession,
    existing: DataFrame,
    anchor_hmac_col: str,
    anchor_type: str,
    canonical_col: str,
) -> tuple[DataFrame, DataFrame]:
    """Attach ``canonical_col`` to every row of ``df`` and return the new anchors.

    Returns ``(df_with_canonical, new_anchor_df)`` where ``new_anchor_df`` holds
    the distinct ``(anchor_hmac_col, canonical_col)`` pairs minted this run (i.e.
    not already in ``existing``) — the parent + anchor-child write set. Existing
    anchors keep their stored canonical (from the join); only new ones are minted.
    """
    lookup = _anchor_lookup(existing, anchor_type, anchor_hmac_col, canonical_col)

    distinct_anchors = (
        df.select(anchor_hmac_col)
        .where(F.col(anchor_hmac_col).isNotNull())
        .distinct()
    )
    # Existing → keep stored canonical; new → mint a random uuid4 once (driver).
    matched = distinct_anchors.join(lookup, on=anchor_hmac_col, how="inner")
    new_hmacs = distinct_anchors.join(lookup, on=anchor_hmac_col, how="left_anti")
    new_anchor_df = _mint_new_map(spark, new_hmacs, anchor_hmac_col, canonical_col)

    anchor_map = matched.select(anchor_hmac_col, canonical_col).unionByName(new_anchor_df)
    df_with_canonical = df.join(anchor_map, on=anchor_hmac_col, how="left")
    return df_with_canonical, new_anchor_df


def _secondary_child_rows(
    df: DataFrame,
    *,
    canonical_col: str,
    secondaries: list[tuple[str, str, str]],  # (hmac_col, identifier_type, vendor)
) -> DataFrame | None:
    """Flatten present secondaries into (type, vendor, hmac, canonical) rows.

    Only rows with a canonical and a present HMAC are kept; the result is
    de-duplicated on the identifier key. Returns ``None`` when nothing applies.
    """
    parts: list[DataFrame] = []
    for hmac_col, identifier_type, vendor in secondaries:
        if hmac_col not in df.columns:
            continue
        parts.append(
            df.filter(
                F.col(canonical_col).isNotNull() & F.col(hmac_col).isNotNull()
            ).select(
                F.lit(identifier_type).alias("identifier_type"),
                F.lit(vendor).alias("vendor"),
                F.col(hmac_col).alias("identifier_value_hmac"),
                F.col(canonical_col),
            )
        )
    if not parts:
        return None
    out = parts[0]
    for nxt in parts[1:]:
        out = out.unionByName(nxt)
    return out.dropDuplicates(list(_IDENTIFIER_COLS))


def _diff_new_children(
    candidates: DataFrame, existing: DataFrame, canonical_col: str, label: str
) -> DataFrame:
    """Return candidate children whose identifier key is not already stored.

    Also logs how many candidates collide with an identifier already owned by a
    *different* canonical (deferred-merge policy, PTK-16: log, don't merge).
    """
    existing_keys = existing.select(*_IDENTIFIER_COLS, F.col(canonical_col).alias("_idr_existing_canonical"))
    joined = candidates.join(existing_keys, on=list(_IDENTIFIER_COLS), how="left")
    conflicts = joined.filter(
        F.col("_idr_existing_canonical").isNotNull()
        & (F.col("_idr_existing_canonical") != F.col(canonical_col))
    ).count()
    if conflicts:
        _logger.warning(
            "IDR secondary link conflicts skipped (identifier already owned by a "
            "different canonical); count=%d",
            conflicts,
        )
    return (
        joined.filter(F.col("_idr_existing_canonical").isNull())
        .select("identifier_type", "vendor", "identifier_value_hmac", canonical_col)
    )


# ---------------------------------------------------------------------------
# Composable building blocks (public) — for driving the pipeline explicitly
# ---------------------------------------------------------------------------
# These are the same pieces resolve_users/resolve_accounts are built from,
# exposed so a notebook can run the flow step by step:
#   1. add_anchor_hmac / add_secondary_hmac  → HMAC columns (the join keys)
#   2. read_identifiers / read_edges         → the existing Lakebase table(s)
#   3. join in Spark, mint_new_canonicals for the misses, then write_new_rows
#      → generate only what is missing
#
# CANONICALS ARE NEVER PRE-MINTED IN THE DATAFRAME. Minting is random uuid4, so
# a per-row column expression would produce different values each time Spark
# recomputes it. Always: join the anchor HMAC against the existing table, keep
# the stored canonical for hits, and call mint_new_canonicals ONLY for the
# left-anti misses — that materialises the random uuid4 once (on the driver) as
# a stable ``(hmac -> canonical)`` frame. Existing identities therefore keep
# their original stored UUID; only genuinely new ones get a fresh uuid4.

def load_peppers(identifier_types: set[str]) -> dict[str, bytes]:
    """Load the per-type pepper bytes on the driver (env / Databricks secret)."""
    return _load_peppers(identifier_types)


def hmac_udf(peppers: dict[str, bytes], identifier_type: str):
    """UDF: raw value → hex HMAC(normalize(value)), or null. See _make_hmac_udf."""
    return _make_hmac_udf(peppers, identifier_type)


def add_anchor_hmac(
    df: DataFrame,
    *,
    anchor_col: str,
    identifier_type: str,
    peppers: dict[str, bytes] | None = None,
    out_hmac_col: str = "anchor_hmac",
) -> DataFrame:
    """Add the anchor HMAC column (null when the anchor value is missing/blank).

    This is the join key against the existing identifier table. The canonical is
    NOT minted here — mint it after the join with :func:`mint_new_canonicals`.
    """
    peppers = peppers or load_peppers({identifier_type})
    return df.withColumn(
        out_hmac_col,
        F.when(
            _present(F.col(anchor_col)),
            hmac_udf(peppers, identifier_type)(F.col(anchor_col)),
        ),
    )


def mint_new_canonicals(
    spark: SparkSession,
    new_hmac_df: DataFrame,
    *,
    hmac_col: str = "anchor_hmac",
    canonical_col: str = "canonical_id",
) -> DataFrame:
    """Mint a random ``uuid4`` per distinct HMAC — once, on the driver.

    Pass ONLY the new HMACs (e.g. the left-anti of your source against the
    existing anchor rows). Returns a stable ``(hmac_col, canonical_col)``
    DataFrame safe to join back and to write as parents/children. See the
    section note on why this must not be a per-row column expression.
    """
    return _mint_new_map(spark, new_hmac_df, hmac_col, canonical_col)


def add_secondary_hmac(
    df: DataFrame,
    *,
    src_col: str,
    identifier_type: str,
    peppers: dict[str, bytes] | None = None,
    out_col: str,
) -> DataFrame:
    """Add an HMAC column for a secondary identifier (email/phone/external)."""
    peppers = peppers or load_peppers({identifier_type})
    return df.withColumn(out_col, hmac_udf(peppers, identifier_type)(F.col(src_col)))


def add_hmacs(
    df: DataFrame,
    specs: list[tuple[str, str, str]],
    *,
    peppers: dict[str, bytes] | None = None,
) -> DataFrame:
    """Add every identifier HMAC column in one call.

    ``specs`` is a list of ``(src_col, identifier_type, out_hmac_col)`` tuples
    (anchor and secondaries together). Each HMAC is deterministic
    (HMAC-SHA256(pepper, normalize(value))) and null when the source value is
    missing/blank/unnormalisable. Peppers for all involved types are loaded once
    unless provided.

    Example::

        prep = add_hmacs(source_df, [
            ("user_id", USER_ANCHOR_TYPE, "anchor_hmac"),
            ("email",   "email",          "email_hmac"),
        ])
    """
    peppers = peppers or load_peppers({itype for _src, itype, _out in specs})
    for src_col, identifier_type, out_col in specs:
        df = df.withColumn(
            out_col, hmac_udf(peppers, identifier_type)(F.col(src_col))
        )
    return df


def read_identifiers(
    spark: SparkSession, table: str, canonical_col: str
) -> DataFrame:
    """Read the full active identifier table."""
    return _read_identifier_table(spark, table, canonical_col)


def read_edges(spark: SparkSession) -> DataFrame:
    """Read the existing (canonical_user_id, canonical_account_id) edges."""
    return _read_edge_table(spark)


def anchor_lookup(
    existing: DataFrame, *, anchor_type: str, hmac_col: str, canonical_col: str
) -> DataFrame:
    """Existing (anchor hmac → canonical) rows for one namespace's anchor type.

    The HMAC column is aliased to ``hmac_col`` so you can left-join it straight
    onto a prepared DataFrame.
    """
    return _anchor_lookup(existing, anchor_type, hmac_col, canonical_col)


def write_new_rows(df: DataFrame, table: str, label: str = "rows") -> int:
    """COPY ``df`` into ``table`` (caller must pass only already-diffed new rows)."""
    return _write_new_rows(df, table, label)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def resolve_users(
    df: DataFrame,
    *,
    spark: SparkSession,
    anchor_col: str = "myq_user_id",
    email_col: str | None = "email",
    phone_col: str | None = "phone",
    external_user_id_cols: dict[str, str] | None = None,
    out_canonical_col: str = "canonical_user_id",
) -> DataFrame:
    """Resolve user anchors + secondaries in Spark, return df + ``out_canonical_col``.

    Anchor path (``anchor_col`` present): find-or-mint the canonical for the
    anchor HMAC, then attach every present secondary (email/phone/external) that
    is not already stored.

    Fallback path (``anchor_col`` null/blank): resolve from the first present
    secondary (email > phone); mint from it if it misses. Rows with no usable
    identifier get ``out_canonical_col = null``.

    New ``identity.user_identity`` parents are written before
    ``identity.user_identifier`` children (FK order).
    """
    external_user_id_cols = external_user_id_cols or {}
    identifier_types = {USER_ANCHOR_TYPE}
    if email_col:
        identifier_types.add("email")
    if phone_col:
        identifier_types.add("phone")
    if external_user_id_cols:
        identifier_types.add("external_user_id")
    peppers = _load_peppers(identifier_types)

    existing = _read_identifier_table(spark, USER_IDENTIFIER_TABLE, out_canonical_col)

    # -- HMAC columns for anchor + every present secondary --------------------
    anchor_hmac = _temp_col(df, "_idr_anchor_hmac")
    if anchor_col in df.columns:
        df = df.withColumn(
            anchor_hmac,
            F.when(
                _present(F.col(anchor_col)),
                _make_hmac_udf(peppers, USER_ANCHOR_TYPE)(F.col(anchor_col)),
            ),
        )
    else:
        df = df.withColumn(anchor_hmac, F.lit(None).cast("string"))

    secondaries: list[tuple[str, str, str]] = []  # (hmac_col, type, vendor)
    if email_col and email_col in df.columns:
        c = _temp_col(df, "_idr_email_hmac")
        df = df.withColumn(c, _make_hmac_udf(peppers, "email")(F.col(email_col)))
        secondaries.append((c, "email", ""))
    if phone_col and phone_col in df.columns:
        c = _temp_col(df, "_idr_phone_hmac")
        df = df.withColumn(c, _make_hmac_udf(peppers, "phone")(F.col(phone_col)))
        secondaries.append((c, "phone", ""))
    for vendor, src_col in external_user_id_cols.items():
        if src_col in df.columns:
            c = _temp_col(df, f"_idr_ext_{vendor}_hmac")
            df = df.withColumn(
                c, _make_hmac_udf(peppers, "external_user_id")(F.col(src_col))
            )
            secondaries.append((c, "external_user_id", vendor))

    # -- Split anchored vs fallback -------------------------------------------
    has_anchor = F.col(anchor_hmac).isNotNull()
    df_anchored = df.filter(has_anchor)
    df_fallback = df.filter(~has_anchor)

    # -- Anchor find-or-mint ---------------------------------------------------
    df_anchored, new_users = _resolve_anchor(
        df_anchored,
        spark=spark,
        existing=existing,
        anchor_hmac_col=anchor_hmac,
        anchor_type=USER_ANCHOR_TYPE,
        canonical_col=out_canonical_col,
    )

    # -- Fallback (anchor-less) resolution ------------------------------------
    df_fallback, fallback_parents = _resolve_user_fallback(
        df_fallback,
        spark=spark,
        existing=existing,
        secondaries=secondaries,
        out_canonical_col=out_canonical_col,
    )

    # -- Write new parents (identity) BEFORE children (identifier) ------------
    new_parents = (
        new_users.select(out_canonical_col)
        .unionByName(fallback_parents.select(out_canonical_col))
        .dropDuplicates([out_canonical_col])
    )
    _write_new_rows(new_parents, USER_IDENTITY_TABLE, "user_identity")

    # Anchor child rows (only the newly minted anchors).
    anchor_children = new_users.select(
        F.lit(USER_ANCHOR_TYPE).alias("identifier_type"),
        F.lit("").alias("vendor"),
        F.col(anchor_hmac).alias("identifier_value_hmac"),
        F.col(out_canonical_col),
    )

    # Secondary child rows from every resolved row (anchored + fallback).
    df_all = df_anchored.unionByName(df_fallback)
    secondary_children = _secondary_child_rows(
        df_all, canonical_col=out_canonical_col, secondaries=secondaries
    )

    children = anchor_children
    if secondary_children is not None:
        children = children.unionByName(secondary_children)
    new_children = _diff_new_children(
        children.dropDuplicates(list(_IDENTIFIER_COLS)),
        existing,
        out_canonical_col,
        "user_identifier",
    )
    _write_new_rows(new_children, USER_IDENTIFIER_TABLE, "user_identifier")

    # -- Attach canonical back onto the source rows ---------------------------
    temp_cols = [anchor_hmac] + [c for c, _t, _v in secondaries]
    return df_all.drop(*temp_cols)


def _resolve_user_fallback(
    df: DataFrame,
    *,
    spark: SparkSession,
    existing: DataFrame,
    secondaries: list[tuple[str, str, str]],
    out_canonical_col: str,
) -> tuple[DataFrame, DataFrame]:
    """Resolve anchor-less rows from secondaries (email > phone), minting on miss.

    Returns ``(df_with_canonical, minted_parents)`` where ``minted_parents`` are
    the distinct newly-minted canonicals (their child identifier rows are picked
    up by the shared secondary-children step in :func:`resolve_users`).
    """
    df = df.withColumn(out_canonical_col, F.lit(None).cast("string"))
    empty_parents = df.select(out_canonical_col).filter(F.lit(False))

    # Only email/phone participate in fallback (global secondaries).
    fallback_order = [
        (hmac_col, itype)
        for hmac_col, itype, _vendor in secondaries
        if itype in ("email", "phone")
    ]
    if not fallback_order:
        return df, empty_parents

    # 1) Look up existing canonicals for each secondary, in precedence order.
    for hmac_col, itype in fallback_order:
        sec_lookup = (
            existing.filter(
                (F.col("identifier_type") == itype) & (F.col("vendor") == "")
            )
            .select(
                F.col("identifier_value_hmac").alias(hmac_col),
                F.col(out_canonical_col).alias("_idr_sec_canonical"),
            )
            .dropDuplicates([hmac_col])
        )
        df = (
            df.join(sec_lookup, on=hmac_col, how="left")
            .withColumn(
                out_canonical_col,
                F.coalesce(F.col(out_canonical_col), F.col("_idr_sec_canonical")),
            )
            .drop("_idr_sec_canonical")
        )

    # 2) Still unresolved but a secondary is present → mint (email > phone).
    #    The mint HMAC (the first present secondary of a still-null row) is the
    #    key; mint a random uuid4 for each distinct new one on the driver so the
    #    value is stable across the enrichment join and the parent write.
    mint_hmac_col = _temp_col(df, "_idr_mint_hmac")
    coalesced_hmac = F.coalesce(*[F.col(hmac_col) for hmac_col, _itype in fallback_order])
    df = df.withColumn(
        mint_hmac_col,
        F.when(
            F.col(out_canonical_col).isNull() & coalesced_hmac.isNotNull(),
            coalesced_hmac,
        ),
    )
    distinct_new = (
        df.select(mint_hmac_col).where(F.col(mint_hmac_col).isNotNull()).distinct()
    )
    new_map = _mint_new_map(spark, distinct_new, mint_hmac_col, "_idr_fb_canonical")
    df = (
        df.join(new_map, on=mint_hmac_col, how="left")
        .withColumn(
            out_canonical_col,
            F.coalesce(F.col(out_canonical_col), F.col("_idr_fb_canonical")),
        )
        .drop("_idr_fb_canonical", mint_hmac_col)
    )
    minted_parents = new_map.select(F.col("_idr_fb_canonical").alias(out_canonical_col))
    return df, minted_parents


def resolve_accounts(
    df: DataFrame,
    *,
    spark: SparkSession,
    anchor_col: str = "account_id",
    out_canonical_col: str = "canonical_account_id",
) -> DataFrame:
    """Resolve account anchors in Spark, return df + ``out_canonical_col``.

    Single identifier type (``account_id``), no secondaries and no fallback:
    rows with a null/blank anchor get ``out_canonical_col = null``.
    """
    peppers = _load_peppers({ACCOUNT_ANCHOR_TYPE})
    existing = _read_identifier_table(
        spark, ACCOUNT_IDENTIFIER_TABLE, out_canonical_col
    )

    anchor_hmac = _temp_col(df, "_idr_account_hmac")
    df = df.withColumn(
        anchor_hmac,
        F.when(
            _present(F.col(anchor_col)),
            _make_hmac_udf(peppers, ACCOUNT_ANCHOR_TYPE)(F.col(anchor_col)),
        ),
    )

    df_with_canonical, new_accounts = _resolve_anchor(
        df,
        spark=spark,
        existing=existing,
        anchor_hmac_col=anchor_hmac,
        anchor_type=ACCOUNT_ANCHOR_TYPE,
        canonical_col=out_canonical_col,
    )

    _write_new_rows(
        new_accounts.select(out_canonical_col).dropDuplicates([out_canonical_col]),
        ACCOUNT_IDENTITY_TABLE,
        "account_identity",
    )
    anchor_children = new_accounts.select(
        F.lit(ACCOUNT_ANCHOR_TYPE).alias("identifier_type"),
        F.lit("").alias("vendor"),
        F.col(anchor_hmac).alias("identifier_value_hmac"),
        F.col(out_canonical_col),
    )
    new_children = _diff_new_children(
        anchor_children, existing, out_canonical_col, "account_identifier"
    )
    _write_new_rows(new_children, ACCOUNT_IDENTIFIER_TABLE, "account_identifier")

    return df_with_canonical.drop(anchor_hmac)


def link_user_accounts(
    df: DataFrame,
    *,
    spark: SparkSession,
    user_canonical_col: str = "canonical_user_id",
    account_canonical_col: str = "canonical_account_id",
    account_user_status_col: str | None = None,
) -> int:
    """Insert new user↔account edges; return the number of NEW edges written.

    Distinct non-null ``(user_canonical_col, account_canonical_col)`` pairs are
    diffed against ``identity.user_account_edge`` and only the new pairs are
    written. Requires ``resolve_users`` / ``resolve_accounts`` to have committed
    their parents first (both columns are FKs).

    ``account_user_status_col`` names an optional source column carrying
    ``account_user_status``; when omitted only the two canonical columns are
    written (the DB column is nullable).

    Note: this returns *new* edges only — idempotent re-runs return 0.
    """
    both_present = (
        F.col(user_canonical_col).isNotNull()
        & F.col(account_canonical_col).isNotNull()
    )
    has_status = bool(account_user_status_col and account_user_status_col in df.columns)

    # Normalise to the edge table's own column names up front so the anti-join
    # and COPY work regardless of the caller's source column names.
    select_cols = [
        F.col(user_canonical_col).alias("canonical_user_id"),
        F.col(account_canonical_col).alias("canonical_account_id"),
    ]
    if has_status:
        select_cols.append(F.col(account_user_status_col).alias("account_user_status"))

    pairs = (
        df.filter(both_present)
        .select(*select_cols)
        .dropDuplicates(["canonical_user_id", "canonical_account_id"])
    )

    existing_edges = _read_edge_table(spark)
    new_edges = pairs.join(
        existing_edges,
        on=["canonical_user_id", "canonical_account_id"],
        how="left_anti",
    )
    return _write_new_rows(new_edges, USER_ACCOUNT_EDGE_TABLE, "user_account_edge")


def _read_edge_table(spark: SparkSession) -> DataFrame:
    """Read existing (canonical_user_id, canonical_account_id) edges."""
    schema = StructType(
        [
            StructField("canonical_user_id", StringType()),
            StructField("canonical_account_id", StringType()),
        ]
    )
    sql = (
        "SELECT canonical_user_id, canonical_account_id "
        f"FROM {USER_ACCOUNT_EDGE_TABLE}"
    )
    pdf = ptk_read_dataframe(sql)
    if pdf is None or len(pdf) == 0:
        return spark.createDataFrame([], schema)
    pdf = pdf.copy()
    pdf.columns = ["canonical_user_id", "canonical_account_id"]
    pdf = pdf.astype(object).where(pd.notnull(pdf), None)
    return spark.createDataFrame(pdf, schema)
