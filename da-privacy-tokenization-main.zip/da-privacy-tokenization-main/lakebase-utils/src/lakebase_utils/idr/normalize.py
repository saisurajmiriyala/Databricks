import unicodedata
from typing import Protocol


NULL_IDENTIFIER_TOKENS = frozenset({"", "null", "none", "nan"})


def is_null_identifier_value(value: object) -> bool:
    """Return True when a source value represents a missing identifier."""
    if value is None:
        return True
    try:
        if value != value:  # NaN from pandas/Spark/numeric source columns.
            return True
    except Exception:
        pass
    if isinstance(value, str):
        return value.strip().casefold() in NULL_IDENTIFIER_TOKENS
    return False


class Normalizer(Protocol):
    def normalize(self, value: str) -> str: ...


class EmailNormalizer:
    def normalize(self, value: str) -> str:
        return unicodedata.normalize("NFC", value.strip()).casefold()


class PhoneNormalizer:
    def normalize(self, value: str) -> str:
        """Normalize a NANP phone number to XXX-XXX-XXXX.

        Handles the input formats found across source tables:

            "8053000851"       -> "805-300-0851"  # plain 10-digit
            "801-400-0003"     -> "801-400-0003"  # already dashed
            "832 607 9887"     -> "832-607-9887"  # spaces
            "(508) 428-9293"   -> "508-428-9293"  # parentheses + space
            "(403)280-2000"    -> "403-280-2000"  # parentheses, no space
            "+14783081228"     -> "478-308-1228"  # E.164 with +1
            "14783081228"      -> "478-308-1228"  # 11-digit with leading 1
            "3128617834.0"     -> "312-861-7834"  # float suffix from numeric columns

        Raises ValueError for values that cannot be reduced to 10 NANP digits.
        """
        raw = str(value).strip()

        if raw.endswith(".0"):
            raw = raw[:-2]

        digits = "".join(c for c in raw if c.isdigit())

        if len(digits) == 11 and digits.startswith("1"):
            digits = digits[1:]

        if len(digits) == 10:
            return f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"

        raise ValueError(f"Cannot normalize phone number: {value!r}")


class ExternalUserIdNormalizer:
    """Stub — vendor-specific normalization not yet implemented."""
    def normalize(self, value: str) -> str:
        return value


class UpperNormalizer:
    def normalize(self, value: str) -> str:
        return value.strip().upper()


class _StubNormalizer:
    def normalize(self, value: str) -> str:
        return value


_stub = _StubNormalizer()
_upper = UpperNormalizer()

_REGISTRY: dict[str, Normalizer] = {
    "email":            EmailNormalizer(),
    "myq_user_id":      _upper,
    "phone":            PhoneNormalizer(),
    "external_user_id": ExternalUserIdNormalizer(),
    "account_id":       _stub,
}


def normalize(identifier_type: str, value: str) -> str:
    if is_null_identifier_value(value):
        raise ValueError(f"Cannot normalize null identifier value for {identifier_type!r}")
    return _REGISTRY.get(identifier_type, _stub).normalize(value)


def normalize_or_none(identifier_type: str, value: object) -> str | None:
    """Normalize an identifier value, returning None when it is unusable.

    This is the nullable variant for batch ingestion paths where one malformed
    source value should behave like a missing identifier instead of aborting the
    full DB batch.
    """
    if is_null_identifier_value(value):
        return None
    try:
        return normalize(identifier_type, str(value))
    except ValueError:
        return None
