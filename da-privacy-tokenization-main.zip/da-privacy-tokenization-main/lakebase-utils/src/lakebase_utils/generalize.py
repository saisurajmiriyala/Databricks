"""Generalization library for quasi-identifiers.

The Tokenize+Generalize Gate blurs quasi-identifiers on the way from Landing to
Raw so they keep analytical value but can no longer pinpoint a person:

    date_of_birth -> birth_year        2000-05-17        -> 2000
    postal_code   -> zip3              "60156" / +4      -> "601"
    ip_address    -> ipv4_subnet24     "10.1.2.33"       -> "10.1.2.0/24"

Full precision exists only in Landing; every transform here replaces the value,
never copies it. Values that don't parse generalize to NULL — dropping a value
is privacy-safe, passing it through raw is not (IPv6 is explicitly out of scope
and generalizes to NULL).

Each transform exists in two forms: a pure Spark ``Column`` expression (no
UDFs, so batch and streaming ``foreachBatch`` produce the identical plan) and a
plain-Python scalar (``*_value``) that defines the reference semantics and
tests without Spark.

Per-source overrides (e.g. zip5 for ad-campaign attribution) are governance
gated: an override is only expressible as a dict carrying a non-empty
``approval_ref`` pointing at the documented approval, otherwise
:func:`effective_treatments` raises :class:`GovernanceError`.

Usage::

    from lakebase_utils.generalize import DEFAULT_GENERALIZATION_COLUMNS, apply_generalization

    df = apply_generalization(df, DEFAULT_GENERALIZATION_COLUMNS)

    # with a governed per-source override
    treatments = effective_treatments(
        source="ads_source",
        overrides=[{"source": "ads_source", "column": "postal_code",
                    "transform": "zip5", "approval_ref": "PTK-123"}],
    )
    df = apply_generalization(df, treatments)
"""
from __future__ import annotations

import datetime as _dt
import logging
import re

try:  # Spark is optional (pip install lakebase-utils[spark]); scalars work without it.
    from pyspark.sql import functions as F
    from pyspark.sql import Column, DataFrame
except ImportError:  # pragma: no cover
    F = None

logger = logging.getLogger(__name__)


class GovernanceError(ValueError):
    """A generalization override is missing its documented governance approval."""


# ---------------------------------------------------------------------------
# Transforms — Spark Column form + scalar reference form
# ---------------------------------------------------------------------------

# Accepted postal formats: "601", "60156", "601561234", "60156-1234". Anything
# else (short, alphanumeric, non-US) -> NULL.
_OCTET = r"(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])"
_IPV4_PREFIX_RE = rf"^({_OCTET}\.{_OCTET}\.{_OCTET})\.{_OCTET}$"


def _zip_re(prefix_len: int) -> str:
    """US ZIP regex keeping the first ``prefix_len`` digits as group 1.

    ``prefix_len=3`` and ``prefix_len=5`` reproduce the original zip3/zip5
    patterns exactly — they only differed in how many digits form the prefix.
    """
    return rf"^(\d{{{prefix_len}}})(\d{{{5 - prefix_len}}}(\d{{4}}|-\d{{4}})?)?$"


_YEAR_RE = r"^\d{4}$"

# Date formats tried in order for birth_year, after a bare year and native ISO
# parsing. Only the YEAR is extracted, so day/month ambiguity (US vs day-first)
# is harmless — every listed format pins the 4-digit year unambiguously. Each
# entry pairs the Spark datetime pattern with the equivalent Python strptime
# pattern so both code paths accept exactly the same strings. Month names assume
# English (Spark default locale is US; Python's default C locale is English).
_DATE_FORMATS = (
    ("MM/dd/yyyy", "%m/%d/%Y"),      # 05/17/2000  (US)
    ("dd/MM/yyyy", "%d/%m/%Y"),      # 17/05/2000  (day-first)
    ("MM-dd-yyyy", "%m-%d-%Y"),      # 05-17-2000
    ("dd-MM-yyyy", "%d-%m-%Y"),      # 17-05-2000
    ("yyyy/MM/dd", "%Y/%m/%d"),      # 2000/05/17
    ("yyyyMMdd",   "%Y%m%d"),        # 20000517    (compact)
    ("MMMM d, yyyy", "%B %d, %Y"),   # May 17, 2000
    ("MMM d, yyyy",  "%b %d, %Y"),   # Jan 5, 2000  (abbreviated month)
    ("d MMMM yyyy",  "%d %B %Y"),    # 17 May 2000
    ("dd-MMM-yyyy",  "%d-%b-%Y"),    # 17-May-2000
)


def birth_year(col: "Column") -> "Column":
    """date/timestamp/string date-of-birth -> int year (unparseable -> NULL).

    Accepts a bare 4-digit year ("1963"), ISO dates/timestamps
    ("1900-01-01 00:00:00"), and the formats in :data:`_DATE_FORMATS` (US and
    day-first numeric, ``yyyy/MM/dd``, compact ``yyyyMMdd``, and English
    month-name forms). Only the year is kept.
    """
    str_val = F.trim(col.cast("string"))
    years = [F.when(str_val.rlike(_YEAR_RE), str_val.cast("int"))]  # bare year "1963"
    years.append(F.year(F.try_to_timestamp(str_val)))               # native ISO date / timestamp
    # The format has to be a literal column: try_to_timestamp reads a plain string
    # as a column name, unlike to_timestamp, and then fails to resolve it.
    years += [F.year(F.try_to_timestamp(str_val, F.lit(fmt))) for fmt, _ in _DATE_FORMATS]
    return F.coalesce(*years)


def birth_year_value(value) -> int | None:
    if isinstance(value, (_dt.date, _dt.datetime)):
        return value.year
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    if re.fullmatch(_YEAR_RE, raw):          # bare year "1963"
        return int(raw)
    try:                                     # native ISO (date-only or with time)
        return _dt.datetime.fromisoformat(raw).year
    except ValueError:
        pass
    for _, py_fmt in _DATE_FORMATS:
        try:
            return _dt.datetime.strptime(raw, py_fmt).year
        except ValueError:
            continue
    return None


def zip3(col: "Column") -> "Column":
    """US postal code -> first 3 digits ("60156-1234" -> "601"); else NULL."""
    str_val = F.trim(col.cast("string"))
    hit = F.regexp_extract(str_val, _zip_re(3), 1)
    return F.when(hit != "", hit)


def zip3_value(value) -> str | None:
    if value is None:
        return None
    match = re.match(_zip_re(3), str(value).strip())
    return match.group(1) if match else None


def zip5(col: "Column") -> "Column":
    """Governed variant: full 5-digit ZIP. Only reachable via an approved override."""
    str_val = F.trim(col.cast("string"))
    hit = F.regexp_extract(str_val, _zip_re(5), 1)
    return F.when(hit != "", hit)


def zip5_value(value) -> str | None:
    if value is None:
        return None
    match = re.match(_zip_re(5), str(value).strip())
    return match.group(1) if match else None


def ipv4_subnet24(col: "Column") -> "Column":
    """IPv4 -> /24 subnet ("10.1.2.33" -> "10.1.2.0/24"). IPv6/malformed -> NULL."""
    str_val = F.trim(col.cast("string"))
    hit = F.regexp_extract(str_val, _IPV4_PREFIX_RE, 1)
    prefix = F.when(hit != "", hit)
    return F.concat(prefix, F.lit(".0/24"))


def ipv4_subnet24_value(value) -> str | None:
    if value is None:
        return None
    match = re.match(_IPV4_PREFIX_RE, str(value).strip())
    return f"{match.group(1)}.0/24" if match else None


TRANSFORMS = {
    "birth_year": birth_year,
    "zip3": zip3,
    "zip5": zip5,
    "ipv4_subnet24": ipv4_subnet24,
}

# Transforms that weaken the default privacy posture; only an override carrying
# a documented governance approval may select them.
GOVERNED_TRANSFORMS = frozenset({"zip5"})

DEFAULT_GENERALIZATION_COLUMNS = {
    "date_of_birth": "birth_year",
    "postal_code": "zip3",
    "ip_address": "ipv4_subnet24",
}


# ---------------------------------------------------------------------------
# Governance-gated per-source overrides
# ---------------------------------------------------------------------------

def effective_treatments(
    source: str,
    overrides: list[dict] | None = None,
    defaults: dict[str, str] = DEFAULT_GENERALIZATION_COLUMNS,
) -> dict[str, str]:
    """Resolve the column->transform map for one source.

    ``overrides`` items are dicts with keys ``source``, ``column``,
    ``transform`` and a non-empty ``approval_ref`` (Jira/Confluence reference
    of the documented governance approval). Raises :class:`GovernanceError`
    when the approval is missing and ``ValueError`` for unknown transforms.
    """
    governed_defaults = {c: t for c, t in defaults.items() if t in GOVERNED_TRANSFORMS}
    if governed_defaults:
        raise GovernanceError(
            f"Governed transforms are only reachable via an approved override, "
            f"not as defaults: {governed_defaults!r}"
        )
    treatments = dict(defaults)
    for override in overrides or []:
        transform = override.get("transform", "")
        if transform not in TRANSFORMS:
            raise ValueError(f"Unknown generalization transform: {transform!r}")
        if not str(override.get("approval_ref", "")).strip():
            raise GovernanceError(
                "Per-source generalization overrides require a documented "
                f"governance approval (missing approval_ref): {override!r}"
            )
        if override.get("source") != source:
            continue
        column = override["column"]
        treatments[column] = transform
        logger.info(
            "generalize: override applied source=%s column=%s transform=%s approval_ref=%s",
            source, column, transform, override["approval_ref"],
        )
    return treatments


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------

def apply_generalization(df: "DataFrame", treatments: dict[str, str]) -> "DataFrame":
    """Replace each treated column in place with its generalized value.

    The original full-precision value never survives the call. Columns absent
    from ``df`` are skipped with a warning. Only column names are logged,
    never values.
    """
    for column, transform in treatments.items():
        if transform not in TRANSFORMS:
            raise ValueError(f"Unknown generalization transform: {transform!r}")
        if column not in df.columns:
            logger.warning("generalize: column %s not in dataframe, skipped", column)
            continue
        df = df.withColumn(column, TRANSFORMS[transform](F.col(column)))
        logger.info("generalize: %s applied to column %s", transform, column)
    return df
