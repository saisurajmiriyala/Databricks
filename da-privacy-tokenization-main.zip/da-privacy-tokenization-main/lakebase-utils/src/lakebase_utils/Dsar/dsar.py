import requests
import time
from lakebase_utils.idr.hmac_util import fetch_secret_scope
from pyspark.sql.types import (
    StructType, StructField, StringType, BooleanType, ArrayType
)
from pyspark.sql.functions import to_timestamp
from IPython import get_ipython
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

def get_dsar_requests(
    account: str,
    language: str = "en-us",
    page_size: int = 2000,
):
    """
    Authenticates with OneTrust, extracts all DSAR requests, and returns them
    as a Spark DataFrame with an explicit schema and parsed timestamp columns.
    """
    
    shell = get_ipython()
    spark = shell.user_ns.get("spark") if shell else None

    dbutils = shell.user_ns.get("dbutils") if shell else None
    if not dbutils:
        from pyspark.dbutils import DBUtils
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        dbutils = DBUtils(spark)
    
    scope = fetch_secret_scope()
    
    onetrust_hostname = "app.onetrust.com"

    if account == "sandbox":
        client_id     = dbutils.secrets.get(scope=scope, key="ONETRUST-CLIENTID-SANDBOX")
        client_secret = dbutils.secrets.get(scope=scope, key="ONETRUST-CLIENTSECRET-SANDBOX")
    elif account == "production":
        client_id     = dbutils.secrets.get(scope=scope, key="ONETRUST-CLIENTID-PROD")
        client_secret = dbutils.secrets.get(scope=scope, key="ONETRUST-CLIENTSECRET-PROD")
    
    token_url = f"https://{onetrust_hostname}/api/access/v1/oauth/token"
    base_api_url = f"https://{onetrust_hostname}/api"

    # ── Token fetch (single-use within this function call) ──
    token_response = requests.post(
        token_url,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        },
    )
    token_response.raise_for_status()
    access_token = token_response.json()["access_token"]

    # ── Paginated extraction ──
    all_requests = []
    page = 0

    while True:
        headers = {"Authorization": f"Bearer {access_token}"}
        params = {"page": page, "size": page_size}
        url = f"{base_api_url}/datasubject/v2/requestqueues/{language}"

        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        result = response.json()

        items = result.get("content", [])
        if not items:
            break

        all_requests.extend(items)

        if result.get("last", True) or len(items) < page_size:
            break

        page += 1

    # ── Convert to Spark DataFrame ──
    schema = StructType([
        StructField("requestQueueRefId", StringType(), True),
        StructField("requestQueueId", StringType(), True),
        StructField("firstName", StringType(), True),
        StructField("lastName", StringType(), True),
        StructField("organization", StringType(), True),
        StructField("status", StringType(), True),
        StructField("requestTypes", ArrayType(StringType()), True),
        StructField("deadline", StringType(), True),
        StructField("isExtended", BooleanType(), True),
        StructField("dateCreated", StringType(), True),
        StructField("dateUpdated", StringType(), True),
        StructField("subjectTypes", ArrayType(StringType()), True),
        StructField("approver", StringType(), True),
        StructField("language", StringType(), True),
        StructField("countryCode", StringType(), True),
        StructField("countryName", StringType(), True),
        StructField("email", StringType(), True),
        StructField("workflow", StringType(), True),
        StructField("webform", StringType(), True),
        StructField("dateCompleted", StringType(), True),
        StructField("resolution", StringType(), True),
        StructField("remainingDaysForMaxDeadline", StringType(), True),
        StructField("maxDeadlineExtensionDate", StringType(), True),
        StructField("assignedToGroup", BooleanType(), True),
        StructField("additionalStatuses", StringType(), True),
    ])

    df = spark.createDataFrame(all_requests, schema=schema)

    df = (
        df.withColumn("dateCreated", to_timestamp("dateCreated", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
          .withColumn("dateUpdated", to_timestamp("dateUpdated", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
          .withColumn("dateCompleted", to_timestamp("dateCompleted", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
    )

    if scope == 'cgi-eus-dev-ada-kv': 
        env = 'dev'
    elif scope == 'cgi-eus-qa-ada-kv': 
        env = 'qa'
    elif scope == 'cgi-eus-prod-ada-kv': 
        env = 'prod'
    
    target_table = f"{env}_audit_log.privacy.prv_dsar_requests"
    df.write.mode("overwrite").saveAsTable(target_table)
