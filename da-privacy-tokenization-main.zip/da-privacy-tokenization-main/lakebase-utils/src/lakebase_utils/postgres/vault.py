"""Vault tokenization and find-or-insert logic."""

import pandas as pd
from typing import Union

from lakebase_utils.idr.hmac_util import compute_hmac_with_context_or_none
from lakebase_utils.idr.normalize import normalize_or_none
from lakebase_utils.idr.pepper import PepperProvider
from lakebase_utils.postgres.connection import _ptk_get_connection


_VAULT_HMAC_CONTEXT_PREFIX = "vault:v1"


def _vault_hmac_context(identifier_type: str) -> str:
    return f"{_VAULT_HMAC_CONTEXT_PREFIX}:{identifier_type}"


def _normalized_vault_candidates(
    df: pd.DataFrame, identifier_type: str, *, single_mode: bool
) -> pd.DataFrame:
    df = df.copy()
    df["real_value"] = df["real_value"].map(
        lambda value: normalize_or_none(identifier_type, value)
    )

    if single_mode:
        if df["real_value"].isna().any() or (df["real_value"] == "").any():
            raise ValueError("real_value cannot be None or empty")
        return df

    df = df.dropna(subset=["real_value"])
    df = df[df["real_value"] != ""]
    return df.drop_duplicates(subset=["canonical_internal_id", "real_value"])


def normalize_real_value(identifier_type_col, value_col):
    """Column of normalize(real_value) per identifier_type, null when unusable.

    The vault stores the same form the token is minted from. generate_token normalizes
    internally, so without this the column keeps the source spelling while the token
    belongs to the normalized one: a phone lands as 8053000851 next to a token minted
    from 805-300-0851, and nobody re-hashing the stored value can reproduce it. One
    formatting per source also means one vault row per formatting of the same identifier.

    Calls the same normalizer the HMACs and vault_find_or_insert use, rather than
    restating its rules here - a second implementation drifts, and lower() is not
    casefold(). A value it cannot normalize comes back null, for the caller to filter.

    Batched rather than row-at-a-time: the historical load normalizes five identifiers
    for every user, and a plain UDF pays the per-row round trip on each one.

    This belongs in the wheel, not in the notebook that uses it. Spark serializes a UDF
    together with the globals it reads, and a UDF written in a notebook reads the
    notebook namespace - which start_global_notebook_logger fills with wrappers that
    hold a logging.Logger, and a Logger owns a lock that cannot be pickled. Here the UDF
    reads this module's namespace instead, which nothing rewrites.
    """
    from pyspark.sql.functions import pandas_udf
    from pyspark.sql.types import StringType

    @pandas_udf(StringType())
    def _normalize(identifier_types: pd.Series, values: pd.Series) -> pd.Series:
        # dtype is pinned: a batch where every value is missing infers float64, and the
        # column then arrives as a double where a string is expected.
        return pd.Series(
            [normalize_or_none(t, v) for t, v in zip(identifier_types, values)],
            dtype="object",
        )

    return _normalize(identifier_type_col, value_col)


def generate_token(prefix_or_map, value_or_df, *, identifier_type: str = None):
    """
    Single mode:   generate_token(prefix: str, value: str, identifier_type=...) -> str
    Spark mode:    generate_token(prefix_map: dict, df: DataFrame) -> DataFrame
                   df must have 'identifier_type' and 'real_value' columns.
                   Returns df with a new 'token' column added.
    """
    from pyspark.sql.types import StringType

    def _build_token(itype: str, raw_value: str, prefix_map: dict) -> str:
        pepper_provider = PepperProvider()
        digest = compute_hmac_with_context_or_none(
            pepper_provider.get(itype),
            itype,
            raw_value,
            context=_vault_hmac_context(itype),
        )
        if digest is None:
            raise ValueError("real_value cannot be null/blank when generating vault token")
        return prefix_map[itype] + digest[:32]

    # Spark DataFrame check (duck typing - has withColumn method)
    if hasattr(value_or_df, 'withColumn'):
        import pandas as pd
        from pyspark.sql.functions import pandas_udf, col

        prefix_map = prefix_or_map
        if "identifier_type" not in value_or_df.columns or "real_value" not in value_or_df.columns:
            raise ValueError("DataFrame mode requires 'identifier_type' and 'real_value' columns")

        # Load peppers once in driver (where dbutils is available). A missing pepper
        # raises here, before a single token is written: a token computed with the wrong
        # key is indistinguishable from a correct one and cannot be recomputed later.
        pepper_provider = PepperProvider()
        itype_rows = value_or_df.select("identifier_type").distinct().collect()
        peppers = {}
        for row in itype_rows:
            itype = row.identifier_type
            if itype:
                peppers[itype] = pepper_provider.get(itype).decode()

        @pandas_udf(StringType())
        def compute_token_spark_udf(itype_series, val_series):
            tokens = []
            for itype, val in zip(itype_series, val_series):
                if val is None or val == "":
                    tokens.append(None)
                else:
                    pepper = peppers.get(itype)
                    if pepper is None:
                        # Never fall back to an empty key. RuntimeError is deliberately
                        # not in the except below, so this fails the task instead of
                        # writing a token nobody can tell apart from a real one.
                        raise RuntimeError(
                            f"No pepper loaded for identifier_type {itype!r}. "
                            f"Loaded types: {sorted(peppers)}"
                        )
                    try:
                        digest = compute_hmac_with_context_or_none(
                            pepper.encode(),
                            itype,
                            val,
                            context=_vault_hmac_context(itype),
                        )
                        if digest is None:
                            tokens.append(None)
                        else:
                            tokens.append(prefix_map[itype] + digest[:32])
                    except (ValueError, KeyError):
                        tokens.append(None)
            return pd.Series(tokens)

        return value_or_df.withColumn("token", compute_token_spark_udf(col("identifier_type"), col("real_value")))

    # Single mode (string value)
    if not identifier_type:
        raise ValueError("identifier_type is required in single mode")

    return _build_token(identifier_type, value_or_df, {identifier_type: prefix_or_map})


def vault_find_or_insert(
    vault_table: str,
    identifier_type: str,
    token_prefix: str,
    canonical_id: str = None,
    real_value: str = None,
    df_candidates: pd.DataFrame = None,
    source_system: str = None,
    pepper: bytes = None,
) -> Union[str, pd.DataFrame]:
    """
    Race-safe find-or-insert for vault tables.

    Call in single-row mode (returns str token):
        vault_find_or_insert(
            vault_table, identifier_type, token_prefix,
            canonical_id=..., real_value=...
        )

    Call in bulk mode (returns DataFrame with columns canonical_internal_id, real_value, token, identifier_type):
        vault_find_or_insert(
            vault_table, identifier_type, token_prefix,
            df_candidates=pd.DataFrame({"canonical_internal_id": [...], "real_value": [...]})
        )

    Both modes share the same three-step logic:
      1. FIND   — check vault for existing tokens (ANY(%s))
      2. INSERT — generate tokens, one set-based INSERT, ON CONFLICT DO NOTHING
      3. RE-READ — return committed tokens (race-condition safe)

    pepper: the HMAC pepper bytes for identifier_type. Optional in a notebook, where
    it is loaded from Databricks Secrets on demand. Callers running outside the
    notebook process (the gate's foreachBatch) MUST pass it in: the secret lookup
    needs the notebook context and fails with a credentials error without it.
    """
    # -- Build a uniform DataFrame regardless of call mode ---
    single_mode = df_candidates is None

    if single_mode:
        if not real_value or real_value.strip() == "":
            raise ValueError("real_value cannot be None or empty")
        df = pd.DataFrame({
            "canonical_internal_id": [canonical_id],
            "real_value": [real_value],
        })
    else:
        df = df_candidates.copy()
        if df.empty:
            return pd.DataFrame(
                columns=["canonical_internal_id", "real_value", "token", "identifier_type"]
            )

    df = _normalized_vault_candidates(df, identifier_type, single_mode=single_mode)
    if df.empty:
        return pd.DataFrame(
            columns=["canonical_internal_id", "real_value", "token", "identifier_type"]
        )

    conn_obj = _ptk_get_connection()
    real_values = df["real_value"].tolist()

    # -- STEP 1: FIND existing tokens ---
    with conn_obj.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT real_value, token
                FROM   {vault_table}
                WHERE  real_value = ANY(%s) AND deletion_status = 'active'
                """,
                (real_values,),
            )
            existing_rows = cur.fetchall()

    df_existing_tokens = (
        pd.DataFrame(existing_rows) if existing_rows
        else pd.DataFrame(columns=["real_value", "token"])
    )

    already_tokenized = set(df_existing_tokens["real_value"]) if not df_existing_tokens.empty else set()
    df_new = df[~df["real_value"].isin(already_tokenized)].copy()

    # -- STEP 2: generate tokens and INSERT new rows ---
    if not df_new.empty:
        # Tokens are minted the same way everywhere: HMAC of the value with the
        # per-type pepper, never a bare hash - a bare hash of an email or a phone
        # can be reversed by hashing candidate values, the peppered HMAC cannot.
        # The pepper and context are fetched once per call, not once per value.
        if pepper is None:
            pepper = PepperProvider().get(identifier_type)
        context = _vault_hmac_context(identifier_type)

        def _mint(value):
            digest = compute_hmac_with_context_or_none(
                pepper, identifier_type, value, context=context
            )
            if digest is None:
                raise ValueError("real_value cannot be null/blank when generating vault token")
            return token_prefix + digest[:32]

        df_new["token"] = df_new["real_value"].apply(_mint)

        # One INSERT for the whole set, not one per row: the values travel as three arrays
        # and Postgres expands them with unnest. executemany here meant a statement per
        # value, which is what made a bulk load of millions of identifiers unusable.
        with conn_obj.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    INSERT INTO {vault_table}
                        (canonical_internal_id, identifier_type, real_value, token,
                         source_system, match_method, match_confidence, dsar_request_id, audit_id)
                    SELECT new.canonical_internal_id::uuid, %s, new.real_value, new.token,
                           %s, 'Deterministic', NULL, NULL, NULL
                    FROM unnest(%s::text[], %s::text[], %s::text[])
                         AS new(canonical_internal_id, real_value, token)
                    ON CONFLICT DO NOTHING
                    """,
                    (
                        identifier_type,
                        source_system,
                        df_new["canonical_internal_id"].astype(str).tolist(),
                        df_new["real_value"].tolist(),
                        df_new["token"].tolist(),
                    ),
                )
                conn.commit()

        # -- STEP 3: RE-READ committed tokens (race-condition safe) ---
        with conn_obj.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    SELECT real_value, token
                    FROM   {vault_table}
                    WHERE  real_value = ANY(%s) AND deletion_status = 'active'
                    """,
                    (df_new["real_value"].tolist(),),
                )
                new_rows = cur.fetchall()

        df_new_tokens = (
            pd.DataFrame(new_rows) if new_rows
            else pd.DataFrame(columns=["real_value", "token"])
        )
        df_new = df_new[["canonical_internal_id", "real_value"]].merge(
            df_new_tokens, on="real_value", how="left"
        )
    else:
        df_new = pd.DataFrame(columns=["canonical_internal_id", "real_value", "token"])

    df_existing = df[df["real_value"].isin(already_tokenized)].merge(
        df_existing_tokens, on="real_value", how="left"
    )

    df_resolved = pd.concat([df_existing, df_new], ignore_index=True)
    df_resolved["identifier_type"] = identifier_type

    if single_mode:
        token = df_resolved["token"].iloc[0]
        if token is None:
            raise RuntimeError(f"Token for {real_value} not found after insert; this should not happen")
        return token

    return df_resolved[["canonical_internal_id", "real_value", "token", "identifier_type"]]
