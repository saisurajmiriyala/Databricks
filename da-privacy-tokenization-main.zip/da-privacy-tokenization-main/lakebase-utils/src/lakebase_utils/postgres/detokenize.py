"""
Detokenization functions with automatic audit logging (PRV-44).

These functions convert tokens back to real values and automatically
log the operation to the immutable audit trail. Each function:

1. Queries the vault for the real value
2. Logs the detokenization event (with hashed values)
3. Returns the real value to the caller

Usage:
    from lakebase_utils.postgres.detokenize import detokenize_email

    email = detokenize_email(
        token="abc123def456...",
        requester="alice@chamberlain.com",
        reason_code="CUSTOMER_SUPPORT"
    )
    # Automatically logs to audit trail
"""

import hashlib
from typing import Optional
from lakebase_utils.postgres.queryhub import ptk_execute


def _hash_sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest().lower()


def _log_detokenize(
    requester: str,
    reason_code: str,
    element_type: str,
    token: str,
    real_value: str,
    approver: Optional[str] = None,
    request_status: str = "SUCCESS",
    error_message: Optional[str] = None,
) -> None:
    token_hash = _hash_sha256(token)
    value_hash = _hash_sha256(real_value)

    ptk_execute(f"""
    INSERT INTO cg_audit.detokenize_log (
        requester,
        approver,
        reason_code,
        element_type,
        token_hash,
        value_hash,
        request_status,
        error_message
    ) VALUES (
        '{requester}',
        {f"'{approver}'" if approver else 'NULL'},
        '{reason_code}',
        '{element_type}',
        '{token_hash}',
        '{value_hash}',
        '{request_status}',
        {f"'{error_message}'" if error_message else 'NULL'}
    )
    """)


def detokenize_email(
    token: str,
    requester: str,
    reason_code: str = "",
    approver: Optional[str] = None,
) -> str:
    """
    Detokenize an email token and log to audit trail.

    Args:
        token: Email token from vault
        requester: User requesting detokenization
        reason_code: Why detokenization is needed
        approver: Optional user who approved

    Returns:
        str: The real email address

    Raises:
        ValueError: If token not found in vault
    """
    result = ptk_execute(f"""
    SELECT real_value
    FROM cg_vault.vault_email
    WHERE token = '{token}'
    AND deletion_status = 'active'
    LIMIT 1
    """)

    if result is None or len(result) == 0:
        raise ValueError(f"Email token not found: {token}")

    real_value = result.iloc[0]["real_value"]

    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type="email",
        token=token,
        real_value=real_value,
    )

    return real_value


def detokenize_phone(
    token: str,
    requester: str,
    reason_code: str = "",
    approver: Optional[str] = None,
) -> str:
    """
    Detokenize a phone token and log to audit trail.

    Args:
        token: Phone token from vault
        requester: User requesting detokenization
        reason_code: Why detokenization is needed
        approver: Optional user who approved

    Returns:
        str: The real phone number

    Raises:
        ValueError: If token not found in vault
    """
    result = ptk_execute(f"""
    SELECT real_value
    FROM cg_vault.vault_phone
    WHERE token = '{token}'
    AND deletion_status = 'active'
    LIMIT 1
    """)

    if result is None or len(result) == 0:
        raise ValueError(f"Phone token not found: {token}")

    real_value = result.iloc[0]["real_value"]

    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type="phone",
        token=token,
        real_value=real_value,
    )

    return real_value


def detokenize_myq_user_id(
    token: str,
    requester: str,
    reason_code: str = "",
    approver: Optional[str] = None,
) -> str:
    """
    Detokenize a MyQ User ID token and log to audit trail.

    Args:
        token: MyQ User ID token from vault
        requester: User requesting detokenization
        reason_code: Why detokenization is needed
        approver: Optional user who approved

    Returns:
        str: The real MyQ User ID

    Raises:
        ValueError: If token not found in vault
    """
    result = ptk_execute(f"""
    SELECT real_value
    FROM cg_vault.vault_myq_user_id
    WHERE token = '{token}'
    AND deletion_status = 'active'
    LIMIT 1
    """)

    if result is None or len(result) == 0:
        raise ValueError(f"MyQ User ID token not found: {token}")

    real_value = result.iloc[0]["real_value"]

    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type="myq_user_id",
        token=token,
        real_value=real_value,
    )

    return real_value


def detokenize_account_id(
    token: str,
    requester: str,
    reason_code: str = "",
    approver: Optional[str] = None,
) -> str:
    """
    Detokenize an Account ID token and log to audit trail.

    Args:
        token: Account ID token from vault
        requester: User requesting detokenization
        reason_code: Why detokenization is needed
        approver: Optional user who approved

    Returns:
        str: The real Account ID

    Raises:
        ValueError: If token not found in vault
    """
    result = ptk_execute(f"""
    SELECT real_value
    FROM cg_vault.vault_account_id
    WHERE token = '{token}'
    AND deletion_status = 'active'
    LIMIT 1
    """)

    if result is None or len(result) == 0:
        raise ValueError(f"Account ID token not found: {token}")

    real_value = result.iloc[0]["real_value"]

    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type="account_id",
        token=token,
        real_value=real_value,
    )

    return real_value


def detokenize_external_user_id(
    token: str,
    requester: str,
    reason_code: str = "",
    approver: Optional[str] = None,
) -> str:
    """
    Detokenize an External User ID token and log to audit trail.

    Args:
        token: External User ID token from vault
        requester: User requesting detokenization
        reason_code: Why detokenization is needed
        approver: Optional user who approved

    Returns:
        str: The real External User ID

    Raises:
        ValueError: If token not found in vault
    """
    result = ptk_execute(f"""
    SELECT real_value
    FROM cg_vault.vault_external_user_id
    WHERE token = '{token}'
    AND deletion_status = 'active'
    LIMIT 1
    """)

    if result is None or len(result) == 0:
        raise ValueError(f"External User ID token not found: {token}")

    real_value = result.iloc[0]["real_value"]

    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type="external_user_id",
        token=token,
        real_value=real_value,
    )

    return real_value


def detokenize_ip_address(
    token: str,
    requester: str,
    reason_code: str = "",
    approver: Optional[str] = None,
) -> str:
    """
    Detokenize an IP Address token and log to audit trail.

    Args:
        token: IP Address token from vault
        requester: User requesting detokenization
        reason_code: Why detokenization is needed
        approver: Optional user who approved

    Returns:
        str: The real IP Address

    Raises:
        ValueError: If token not found in vault
    """
    result = ptk_execute(f"""
    SELECT real_value
    FROM cg_vault.vault_ip_address
    WHERE token = '{token}'
    AND deletion_status = 'active'
    LIMIT 1
    """)

    if result is None or len(result) == 0:
        raise ValueError(f"IP Address token not found: {token}")

    real_value = result.iloc[0]["real_value"]

    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type="ip_address",
        token=token,
        real_value=real_value,
    )

    return real_value
