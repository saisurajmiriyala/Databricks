"""Tests for lakebase_utils.generalize (PTK-35)."""
import datetime as dt

import pytest

from lakebase_utils.generalize import (
    DEFAULT_GENERALIZATION_COLUMNS,
    GovernanceError,
    apply_generalization,
    birth_year_value,
    effective_treatments,
    ipv4_subnet24_value,
    zip3_value,
    zip5_value,
)


# ---------------------------------------------------------------------------
# Scalar reference semantics
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("value, expected", [
    (dt.date(2000, 5, 17), 2000),
    (dt.datetime(1991, 12, 31, 23, 59), 1991),
    ("2000-05-17", 2000),
    ("2000-05-17 10:30:00", 2000),
    ("1900-01-01 00:00:00", 1900),   # ISO timestamp
    ("2000-05-17T10:30:00", 2000),   # ISO with 'T'
    ("1940", 1940),                  # bare year
    ("1963", 1963),
    ("05/17/2000", 2000),            # US MM/dd/yyyy
    ("17/05/2000", 2000),            # day-first dd/MM/yyyy (year still unambiguous)
    ("05-17-2000", 2000),            # dashes
    ("2000/05/17", 2000),            # yyyy/MM/dd
    ("20000517", 2000),              # compact yyyyMMdd
    ("May 17, 2000", 2000),          # full month name
    ("Jan 5, 2000", 2000),           # abbreviated month name
    ("17 May 2000", 2000),
    ("17-May-2000", 2000),
    ("not-a-date", None),
    ("17/2000", None),               # incomplete
    ("", None),
    (None, None),
])
def test_birth_year_value(value, expected):
    assert birth_year_value(value) == expected


@pytest.mark.parametrize("value, expected", [
    ("60156", "601"),
    ("60156-1234", "601"),
    ("601561234", "601"),
    ("601", "601"),
    (" 60156 ", "601"),
    ("60", None),          # fewer than 3 digits -> null, never passthrough
    ("SW1A 1AA", None),    # non-US format -> null
    ("", None),
    (None, None),
])
def test_zip3_value(value, expected):
    assert zip3_value(value) == expected


@pytest.mark.parametrize("value, expected", [
    ("60156", "60156"),
    ("60156-1234", "60156"),
    ("601", None),
    (None, None),
])
def test_zip5_value(value, expected):
    assert zip5_value(value) == expected


@pytest.mark.parametrize("value, expected", [
    ("10.1.2.33", "10.1.2.0/24"),
    ("192.168.0.1", "192.168.0.0/24"),
    ("255.255.255.255", "255.255.255.0/24"),
    ("0.0.0.0", "0.0.0.0/24"),
    ("10.1.2.256", None),   # octet out of range
    ("10.1.2", None),
    ("2001:db8::1", None),  # IPv6 out of scope -> null
    ("garbage", None),
    ("", None),
    (None, None),
])
def test_ipv4_subnet24_value(value, expected):
    assert ipv4_subnet24_value(value) == expected


# ---------------------------------------------------------------------------
# Governance-gated overrides
# ---------------------------------------------------------------------------

def test_override_requires_approval_ref():
    with pytest.raises(GovernanceError):
        effective_treatments("ads", overrides=[
            {"source": "ads", "column": "postal_code", "transform": "zip5"},
        ])
    with pytest.raises(GovernanceError):
        effective_treatments("ads", overrides=[
            {"source": "ads", "column": "postal_code", "transform": "zip5",
             "approval_ref": "  "},
        ])


def test_approved_override_wins_over_default():
    treatments = effective_treatments("ads", overrides=[
        {"source": "ads", "column": "postal_code", "transform": "zip5",
         "approval_ref": "PTK-123"},
    ])
    assert treatments["postal_code"] == "zip5"
    assert treatments["date_of_birth"] == "birth_year"  # defaults untouched


def test_override_for_other_source_is_ignored():
    treatments = effective_treatments("docks", overrides=[
        {"source": "ads", "column": "postal_code", "transform": "zip5",
         "approval_ref": "PTK-123"},
    ])
    assert treatments == DEFAULT_GENERALIZATION_COLUMNS


def test_unknown_transform_rejected():
    with pytest.raises(ValueError, match="Unknown generalization transform"):
        effective_treatments("ads", overrides=[
            {"source": "ads", "column": "postal_code", "transform": "rot13",
             "approval_ref": "PTK-123"},
        ])


def test_governed_transform_rejected_as_default():
    with pytest.raises(GovernanceError):
        effective_treatments("ads", defaults={"postal_code": "zip5"})


# ---------------------------------------------------------------------------
# Spark parity — the Column form must match the scalar reference row for row
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def spark():
    pytest.importorskip("pyspark")
    from pyspark.sql import SparkSession
    try:
        session = (SparkSession.builder.master("local[2]")
                   .appName("test_generalize").getOrCreate())
    except Exception as exc:  # pragma: no cover - local env without a working JVM
        pytest.skip(f"local Spark unavailable: {exc}")
    yield session
    session.stop()


def test_spark_matches_scalars(spark):
    rows = [
        ("2000-05-17", "60156-1234", "10.1.2.33"),
        ("05/17/2000", "601561234", "255.255.255.255"),
        ("1963", "601", "0.0.0.0"),
        ("1900-01-01 00:00:00", "60156", "192.168.0.1"),
        ("17-May-2000", "60156", "192.168.0.1"),
        ("not-a-date", "SW1A 1AA", "2001:db8::1"),
        (None, None, None),
    ]
    df = spark.createDataFrame(rows, ["date_of_birth", "postal_code", "ip_address"])

    out = apply_generalization(df, DEFAULT_GENERALIZATION_COLUMNS).collect()

    for raw, got in zip(rows, out):
        assert got["date_of_birth"] == birth_year_value(raw[0])
        assert got["postal_code"] == zip3_value(raw[1])
        assert got["ip_address"] == ipv4_subnet24_value(raw[2])


def test_spark_birth_year_from_date_column(spark):
    df = spark.createDataFrame([(dt.date(1991, 12, 31),)], ["date_of_birth"])
    out = apply_generalization(df, {"date_of_birth": "birth_year"}).collect()
    assert out[0]["date_of_birth"] == 1991


def test_apply_skips_missing_columns(spark):
    df = spark.createDataFrame([("60156",)], ["postal_code"])
    out = apply_generalization(df, DEFAULT_GENERALIZATION_COLUMNS)
    assert out.columns == ["postal_code"]
    assert out.collect()[0]["postal_code"] == "601"


def test_apply_rejects_unknown_transform(spark):
    df = spark.createDataFrame([("60156",)], ["postal_code"])
    with pytest.raises(ValueError, match="Unknown generalization transform"):
        apply_generalization(df, {"postal_code": "rot13"})
