"""Unit tests for lakebase_utils.gate.detection (pure logic, no Spark)."""

from lakebase_utils.gate.detection import classify_column

EMAILS = ["a@x.com", "b@y.org", "c.d@z.co"]
PHONES = ["226-555-0191", "(312) 555-0142", "+1 773.555.0110"]
IPS = ["10.0.0.1", "192.168.1.20", "172.16.4.9"]
UUIDS = ["9f3c2b81-4d6a-4e2f-b7c1-0a5e8d9f1234", "a1b2c3d4-32d0-433d-b823-342cf51a338d"]
NUMERIC_IDS = ["153108827", "153108828", "153108829"]
# Braze / Mongo-style ObjectIds, the real shape in the Braze landing tables
BRAZE_IDS = ["5b2b1a1a1a1a1a1a1a1a1a1a", "63f0c9d2e4b0a1f2c3d4e5f6", "61a2b3c4d5e6f708192a3b4c"]


def test_uc_tag_wins_over_name_and_content():
    r = classify_column("contact", "string", ["class.EMAIL"], ["not-an-email"])
    assert (r["action"], r["target"]) == ("tokenize", "email")
    assert r["signal"] == "uc_tag:EMAIL"


def test_email_by_name_confirmed_by_content():
    r = classify_column("email_address", "string", [], EMAILS)
    assert (r["action"], r["target"]) == ("tokenize", "email")
    assert r["match_ratio"] == 1.0


def test_email_lookalike_boolean_degrades_to_pass():
    r = classify_column("email_verified", "boolean", [], [])
    assert r["action"] == "pass"
    assert r["signal"].startswith("name_unconfirmed")


def test_email_named_but_content_mismatch_degrades_to_pass():
    r = classify_column("email_status", "string", [], ["active", "bounced", "active"])
    assert r["action"] == "pass"
    assert r["signal"].startswith("name_unconfirmed")


def test_phone_by_name_and_content():
    r = classify_column("mobile_number", "string", [], PHONES)
    assert (r["action"], r["target"]) == ("tokenize", "phone")


# --- user id: the same column name means a different element per vendor -------

def test_user_id_is_myq_anchor_when_no_vendor():
    r = classify_column("user_id", "string", [], UUIDS)
    assert (r["action"], r["target"], r["vendor"]) == ("tokenize", "myq_user_id", "")
    assert classify_column("user_id", "string", [], NUMERIC_IDS)["target"] == "myq_user_id"


def test_user_id_is_vendor_id_when_table_has_a_vendor():
    r = classify_column("user_id", "string", [], BRAZE_IDS, vendor="braze")
    assert (r["action"], r["target"], r["vendor"]) == ("tokenize", "external_user_id", "braze")


def test_braze_shaped_user_id_without_vendor_is_skipped():
    # no vendor hint and the values are not myQ-shaped -> logged and skipped
    r = classify_column("user_id", "string", [], BRAZE_IDS)
    assert r["action"] == "pass"
    assert r["signal"] == "name_unconfirmed:myq_user_id"


def test_column_vendor_beats_table_vendor():
    r = classify_column("external_userid_salesforce", "string", [], BRAZE_IDS, vendor="braze")
    assert (r["target"], r["vendor"]) == ("external_user_id", "salesforce")


def test_explicit_myq_column_stays_the_anchor_inside_a_vendor_table():
    r = classify_column("myq_user_id", "string", [], UUIDS, vendor="braze")
    assert (r["target"], r["vendor"]) == ("myq_user_id", "")


def test_external_user_id_accepts_any_opaque_vendor_format():
    r = classify_column("external_user_id", "string", [], BRAZE_IDS, vendor="braze")
    assert (r["target"], r["vendor"]) == ("external_user_id", "braze")


def test_free_text_named_user_id_is_not_tokenized():
    r = classify_column("user_id_notes", "string", [], ["sent to the owner", "no id given"], vendor="braze")
    assert r["action"] == "pass"


def test_numeric_user_id_column_is_id_shaped_by_type():
    r = classify_column("user_id", "bigint", [], [])
    assert (r["action"], r["target"]) == ("tokenize", "myq_user_id")


def test_account_id_by_name_and_content():
    r = classify_column("account_id", "string", [], UUIDS)
    assert (r["action"], r["target"]) == ("tokenize", "account_id")


# --- CamelCase and concatenated audit-style names (myqbusinessdocks shapes) ---

def test_camelcase_audit_user_id_is_detected():
    # real shape in dev_landing.de_prod_myqbusinessdocks_sql.blocks and 6 other tables
    for name in ("CreatedByUserId", "LastUpdatedByUserId", "UserId"):
        r = classify_column(name, "string", [], UUIDS)
        assert (r["action"], r["target"]) == ("tokenize", "myq_user_id"), name


def test_lowercase_concatenated_user_id_is_detected():
    # trailerassignments.createdbyuserid: no underscores, no case boundaries
    r = classify_column("createdbyuserid", "string", [], UUIDS)
    assert (r["action"], r["target"]) == ("tokenize", "myq_user_id")


def test_camelcase_account_id_is_detected():
    # drivers.CreatedOnAccountId and the AccountId columns across the schema
    for name in ("CreatedOnAccountId", "AccountId", "createdonaccountid"):
        r = classify_column(name, "string", [], UUIDS)
        assert (r["action"], r["target"]) == ("tokenize", "account_id"), name


def test_camelcase_phone_is_detected():
    r = classify_column("MobileNumber", "string", [], PHONES)
    assert (r["action"], r["target"]) == ("tokenize", "phone")


def test_audit_user_id_with_unconfirmed_values_is_skipped():
    # the relaxed anchor must not tokenize on name alone: values still rule
    r = classify_column("CreatedByUserId", "string", [], ["system", "batch-job", "system"])
    assert r["action"] == "pass"
    assert r["signal"] == "name_unconfirmed:myq_user_id"


def test_id_lookalike_names_do_not_match():
    # neighbours in the same schema that must stay untouched
    for name in ("TouchPointId", "PartnerReferenceId", "TrailerAssignmentId",
                 "LaneId", "DriverId", "uniqueid", "poweruseridle"):
        r = classify_column(name, "string", [], UUIDS)
        assert r["action"] == "pass", name
        assert r["signal"] == "none", name


# --- generalize / pass / value sweep -----------------------------------------

def test_generalize_targets_by_name():
    assert classify_column("date_of_birth", "date", [], [])["target"] == "birth_year"
    assert classify_column("postal_code", "string", [], ["60601"])["target"] == "zip3"
    assert classify_column("ip_address", "string", [], IPS)["target"] == "ipv4_subnet24"
    assert classify_column("date_of_birth", "date", [], [])["action"] == "generalize"


def test_person_names_pass_through():
    r = classify_column("first_name", "string", [], ["Sarah", "Luis"])
    assert r["action"] == "pass"


def test_hidden_emails_tokenized_by_content():
    r = classify_column("channel_identifier", "string", [], EMAILS)
    assert (r["action"], r["target"]) == ("tokenize", "email")
    assert r["signal"] == "content_only:email"


def test_hidden_ips_generalized_by_content():
    r = classify_column("client_meta", "string", [], IPS)
    assert (r["action"], r["target"]) == ("generalize", "ipv4_subnet24")


def test_neutral_column_passes():
    r = classify_column("order_total", "decimal(10,2)", [], [])
    assert r["action"] == "pass"
    assert r["signal"] == "none"


def test_mixed_content_below_threshold_passes():
    values = EMAILS + ["plain text"] * 7  # 30% emails < 80% threshold
    r = classify_column("notes", "string", [], values)
    assert r["action"] == "pass"
