from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

@dataclass(frozen=True)
class ResolverEntry:
    prefix: str
    element_type: str
    resolver_name: str


# Keep prefixes aligned with vault token generation.
# Source: vault_bundle/src/notebooks/VAULT_INCREMENTAL.py
RESOLVER_TABLE: tuple[ResolverEntry, ...] = (
    ResolverEntry("eml_", "email", "detokenize_email"),
    ResolverEntry("phn_", "phone", "detokenize_phone"),
    ResolverEntry("usr_", "myq_user_id", "detokenize_myq_user_id"),
    ResolverEntry("xui_", "external_user_id", "detokenize_external_user_id"),
    ResolverEntry("acc_", "account_id", "detokenize_account_id"),
)


class UnsupportedTokenPrefixError(ValueError):
    pass


def _get_resolver(resolver_name: str) -> Callable[..., str]:
    """Import lakebase detokenize helpers lazily to avoid app boot crashes."""
    from DB_CLIENT import (
        detokenize_account_id,
        detokenize_email,
        detokenize_external_user_id,
        detokenize_myq_user_id,
        detokenize_phone,
    )

    resolver_map = {
        "detokenize_email": detokenize_email,
        "detokenize_phone": detokenize_phone,
        "detokenize_myq_user_id": detokenize_myq_user_id,
        "detokenize_external_user_id": detokenize_external_user_id,
        "detokenize_account_id": detokenize_account_id,
    }
    return resolver_map[resolver_name]


def resolve_token(
    *,
    token: str,
    requester: str,
    reason_code: str = "",
    approver: str | None = None,
) -> tuple[str, str]:
    """Resolve a token to its plaintext value based on prefix.

    Returns:
        (element_type, real_value)
    """
    normalized = (token or "").strip()
    if not normalized:
        raise ValueError("Token is required.")

    for entry in RESOLVER_TABLE:
        if normalized.startswith(entry.prefix):
            resolver = _get_resolver(entry.resolver_name)
            value = resolver(
                token=normalized,
                requester=requester,
                reason_code=reason_code,
                approver=approver,
            )
            return entry.element_type, value

    expected = ", ".join(e.prefix for e in RESOLVER_TABLE)
    raise UnsupportedTokenPrefixError(
        f"Unsupported token prefix for '{normalized}'. Expected one of: {expected}"
    )
