from __future__ import annotations

import csv
import io
import os
import re

import streamlit as st
from PIL import Image, ImageChops

from DB_CLIENT import (
    get_requester_daily_usage_count,
    log_find_token_events_bulk,
    find_tokens_from_real_values_batch,
    find_token_from_real_value,
    is_requester_authorized,
    init_connection,
    log_detokenize_failure,
    log_find_token_failure,
    log_find_token_success,
    log_resolve_token_events_bulk,
    resolve_tokens_batch,
)
from TOKEN_RESOLVER import UnsupportedTokenPrefixError, resolve_token


EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
BATCH_LIMIT = 100
STANDARD_DAILY_LIMIT = 10


def _rows_to_csv_bytes(rows: list[dict[str, str]], fieldnames: list[str]) -> bytes:
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fieldnames)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buffer.getvalue().encode("utf-8")


def _parse_list_input(uploaded_file, pasted_text: str) -> list[str]:
    values: list[str] = []

    payloads: list[str] = []
    if uploaded_file is not None:
        payloads.append(uploaded_file.getvalue().decode("utf-8", errors="ignore"))
    if (pasted_text or "").strip():
        payloads.append(pasted_text)

    for payload in payloads:
        reader = csv.reader(io.StringIO(payload))
        for row in reader:
            if not row:
                continue
            first = (row[0] or "").strip().strip('"').strip("'")
            if first:
                values.append(first)

    if values and values[0].strip().lower() in {"token", "real_value", "real value", "value"}:
        values = values[1:]

    return values


def _get_signed_in_user_email() -> str:
    headers = getattr(getattr(st, "context", None), "headers", {}) or {}
    for key in (
        "x-forwarded-email",
        "X-Forwarded-Email",
        "x-forwarded-preferred-username",
        "X-Forwarded-Preferred-Username",
        "x-forwarded-user",
        "X-Forwarded-User",
    ):
        value = headers.get(key)
        if value:
            return str(value).strip().lower()

    local_fallback = (os.environ.get("APP_REQUESTER") or "").strip().lower()
    if local_fallback:
        return local_fallback

    raise RuntimeError("Signed-in user identity is not available.")


def _infer_element_type(token: str) -> str:
    normalized = (token or "").strip().lower()
    prefix_map = {
        "eml_": "email",
        "phn_": "phone",
        "usr_": "myq_user_id",
        "xui_": "external_user_id",
        "acc_": "account_id",
    }
    for prefix, element_type in prefix_map.items():
        if normalized.startswith(prefix):
            return element_type
    return "unknown"


def _audit_failure(
    *,
    token: str,
    requester: str,
    reason_code: str,
    approver: str | None,
    error_message: str,
) -> None:
    """Best-effort failure audit logging; never breaks the UI flow."""
    try:
        init_lakebase_connection()
        log_detokenize_failure(
            token=token,
            requester=requester,
            reason_code=reason_code,
            approver=approver,
            element_type=_infer_element_type(token),
            error_message=error_message,
        )
    except Exception:
        # Do not block user response if audit logging fails.
        pass


def _has_unlimited_access(requester: str) -> bool:
    try:
        return is_requester_authorized(requester)
    except Exception:
        st.warning("Unlimited access lookup failed; applying the standard daily limit.")
    return False


def _validate_daily_limit(*, requester: str, requested_count: int) -> bool:
    used_today = get_requester_daily_usage_count(requester)
    remaining = STANDARD_DAILY_LIMIT - used_today
    if requested_count > remaining:
        st.error(
            f"Daily limit is {STANDARD_DAILY_LIMIT}. "
            f"Used today: {used_today}. Requested: {requested_count}. "
            f"Remaining: {max(remaining, 0)}."
        )
        return False
    st.warning(
        f"Daily limit is {STANDARD_DAILY_LIMIT}. "
        f"Used today: {used_today}. Requested: {requested_count}. "
        f"Remaining after this request: {remaining - requested_count}."
    )
    return True


def _validate_batch_limit(*, item_label: str, requested_count: int) -> bool:
    if requested_count > BATCH_LIMIT:
        st.error(f"{item_label} list limit is {BATCH_LIMIT}. Received {requested_count}.")
        return False
    return True


@st.cache_resource(show_spinner=False)
def init_lakebase_connection() -> None:
    """Initialize database connection from Databricks secrets."""
    try:
        init_connection()
    except Exception as exc:
        raise RuntimeError(
            f"Failed to initialize database connection from secret scope: {exc}\n"
            "Ensure the following secrets exist in the workspace secret scope:\n"
            "  - dbx-lakebase-dev-host\n"
            "  - dbx-lakebase-dev-db\n"
            "  - dbx-lakebase-dev-user\n"
            "  - dbx-lakebase-dev-password"
        ) from exc


@st.cache_data(show_spinner=False)
def _load_cropped_logo(path: str) -> Image.Image:
    """Load a logo image and trim outer white margins to reduce wasted space."""
    rgba = Image.open(path).convert("RGBA")
    # Composite transparency over white so transparent pixels don't become black.
    white_bg = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
    img = Image.alpha_composite(white_bg, rgba).convert("RGB")
    # Difference against white background highlights non-white logo pixels.
    bg = Image.new("RGB", img.size, (255, 255, 255))
    diff = ImageChops.difference(img, bg).convert("L")
    # Ignore near-white anti-aliased noise so margins trim tighter.
    mask = diff.point(lambda p: 255 if p > 10 else 0)
    bbox = mask.getbbox()
    if not bbox:
        return img

    cropped = img.crop(bbox)
    return cropped


def main() -> None:
    st.set_page_config(page_title="Re-identification Service", page_icon="🔐", layout="centered")

    # Chamberlain corporate colors theme on white background.
    st.markdown("""
    <style>
        .stApp {
            background-color: #FFFFFF !important;
            color: #0B3E75;
        }

        /* Keep sidebar in corporate navy */
        section[data-testid="stSidebar"] {
            background-color: #0B2E57 !important;
        }

        section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] * {
            color: #FFFFFF !important;
        }

        section[data-testid="stSidebar"] h1,
        section[data-testid="stSidebar"] h2,
        section[data-testid="stSidebar"] h3 {
            color: #FFFFFF !important;
        }

        section[data-testid="stSidebar"] label {
            color: #FFFFFF !important;
        }

        section[data-testid="stSidebar"] .stTextInput > div > div > input {
            background-color: #FFFFFF !important;
            color: #0B3E75 !important;
            border: 2px solid #0B5EA8 !important;
        }

        /* Button styling in corporate blue */
        .stButton > button {
            background-color: #0B5EA8;
            color: #FFFFFF;
            border: 2px solid #0B5EA8;
            border-radius: 8px;
            padding: 12px 24px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .stButton > button:hover {
            background-color: #094E8B;
            border-color: #094E8B;
        }

        /* Inputs on white background */
        .stTextInput > div > div > input {
            background-color: #FFFFFF;
            color: #0F172A;
            border: 2px solid #0B5EA8;
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 15px;
        }

        .stTextInput > div > div > input::placeholder {
            color: #6B7280;
        }

        .stTextInput > div > div > input:focus {
            border-color: #0B5EA8;
            box-shadow: 0 0 0 3px rgba(11, 94, 168, 0.18);
            background-color: #FFFFFF;
            color: #0F172A;
        }

        /* Labels styling */
        .stTextInput > label,
        .stSelectbox > label,
        .stTextArea > label {
            color: #0B3E75;
            font-weight: 600;
        }

        /* Main title styling */
        h1 {
            color: #0B3E75;
            font-weight: 700;
            margin-top: -14px;
            margin-bottom: 8px;
        }

        /* Caption styling */
        .stMarkdown p {
            font-size: 16px;
            color: #334155;
        }

        /* Success message */
        .stSuccess {
            background-color: #ECFDF3;
            border: 1px solid #22C55E;
            color: #166534;
        }

        /* Error message */
        .stError {
            background-color: #FEF2F2;
            border: 1px solid #EF4444;
            color: #991B1B;
        }

        /* Warning message */
        .stWarning {
            background-color: #FFF7ED;
            border: 1px solid #F59E0B;
            color: #9A3412;
        }

    </style>
    """, unsafe_allow_html=True)

    left, center, right = st.columns([1, 2, 1])
    with center:
        st.image(_load_cropped_logo("assets/chamberlain-logo.png"), width=270)

    st.title("Re-identification Service")
    st.caption("Resolve tokens to real values or find tokens from real values")

    try:
        signed_in_user_email = _get_signed_in_user_email()
    except RuntimeError as exc:
        st.error(str(exc))
        return

    with st.sidebar:
        st.header("Audit Context")
        st.text_input(
            "Signed-in User",
            value=signed_in_user_email,
            disabled=True,
            help="Authenticated Databricks User",
        )
        reason_code = st.text_input(
            "Reason Code",
            value="",
            help="Business reason for access.",
        )
        approver = st.text_input(
            "Approver (optional)",
            value="",
            help="Manager or security approver email when required by policy. Leave blank if not required.",
        )

    action = st.radio(
        "Action Selector",
        ["Resolve Token", "Find Token"],
        horizontal=True,
        label_visibility="collapsed",
    )

    if action == "Resolve Token":
        resolve_mode = st.radio(
            "Input Mode",
            ["Single", f"List (up to {BATCH_LIMIT})"],
            horizontal=True,
            key="resolve_mode",
        )

        if resolve_mode == "Single":
            token = st.text_input("Token", placeholder="eml_... / phn_... / usr_... / xui_... / acc_...")
            submitted = st.button("Resolve Token", type="primary")
            raw_tokens = [token]
        else:
            uploaded_tokens = st.file_uploader(
                "Upload token list (.txt or .csv)",
                type=["txt", "csv"],
                help="The file must contain one token per line.",
                key="resolve_tokens_file",
            )
            pasted_tokens = st.text_area(
                "Or paste tokens (one per line)",
                height=120,
                help="Enter one token per line.",
                key="resolve_tokens_text",
            )
            submitted = st.button("Resolve Token List", type="primary")
            raw_tokens = _parse_list_input(uploaded_tokens, pasted_tokens)

        if submitted:
            requester_clean = signed_in_user_email
            reason_code_clean = reason_code.strip()
            approver_clean = approver.strip() or None
            audit_token = ""
            if raw_tokens:
                audit_token = (raw_tokens[0] or "").strip()

            if not requester_clean:
                st.error("Requester is required for audit logging.")
                return

            if not EMAIL_PATTERN.match(requester_clean):
                message = "The requester is not a valid email address."
                _audit_failure(
                    token=audit_token,
                    requester=requester_clean,
                    reason_code=reason_code_clean,
                    approver=approver_clean,
                    error_message=message,
                )
                st.error(message)
                return

            unlimited_access = _has_unlimited_access(requester_clean)

            tokens = [t.strip() for t in raw_tokens if (t or "").strip()]
            if not tokens:
                if resolve_mode == "Single":
                    st.error("Provide the token.")
                else:
                    st.error("Provide at least one token.")
                return
            if not _validate_batch_limit(item_label="Token", requested_count=len(tokens)):
                return

            try:
                init_lakebase_connection()
            except Exception as exc:
                message = f"Resolution failed: {exc}"
                st.error(message)
                return

            if not unlimited_access and not _validate_daily_limit(
                requester=requester_clean,
                requested_count=len(tokens),
            ):
                return

            if resolve_mode == "Single":
                token_clean = tokens[0]
                try:
                    element_type, real_value = resolve_token(
                        token=token_clean,
                        requester=requester_clean,
                        reason_code=reason_code_clean,
                        approver=approver_clean,
                    )
                except UnsupportedTokenPrefixError as exc:
                    message = str(exc)
                    _audit_failure(
                        token=token_clean,
                        requester=requester_clean,
                        reason_code=reason_code_clean,
                        approver=approver_clean,
                        error_message=message,
                    )
                    st.warning(message)
                    return
                except ValueError as exc:
                    message = str(exc)
                    _audit_failure(
                        token=token_clean,
                        requester=requester_clean,
                        reason_code=reason_code_clean,
                        approver=approver_clean,
                        error_message=message,
                    )
                    if "not found" in message.lower():
                        st.error("Token not found")
                    else:
                        st.error(message)
                    return

                st.success("Token resolved")
                st.write("Element type:", element_type)
                st.code(real_value, language="text")
            else:
                rows: list[dict[str, str]] = []
                found_count = 0
                audit_events: list[dict[str, str | None]] = []

                batch_results = resolve_tokens_batch(tokens=tokens)

                for result in batch_results:
                    token_item = str(result["token"])
                    element_type = str(result["element_type"] or "unknown")
                    real_value = result["real_value"]
                    status = str(result["status"])

                    if status == "FOUND" and real_value:
                        audit_events.append(
                            {
                                "token": token_item,
                                "element_type": element_type,
                                "real_value": str(real_value),
                                "status": "FOUND",
                                "error_message": None,
                            }
                        )
                        rows.append({"Token": token_item, "Real Value": str(real_value)})
                        found_count += 1
                    else:
                        audit_events.append(
                            {
                                "token": token_item,
                                "element_type": element_type,
                                "real_value": None,
                                "status": "NOT_FOUND",
                                "error_message": "Token not found",
                            }
                        )
                        rows.append({"Token": token_item, "Real Value": "Not found"})

                try:
                    log_resolve_token_events_bulk(
                        requester=requester_clean,
                        reason_code=reason_code_clean,
                        approver=approver_clean,
                        events=audit_events,
                    )
                except Exception:
                    # Do not block response rendering if audit write fails.
                    pass

                st.success(f"Processed {len(rows)} tokens. Found {found_count}.")
                st.dataframe(rows, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download CSV",
                    data=_rows_to_csv_bytes(rows, ["Token", "Real Value"]),
                    file_name="resolved_tokens.csv",
                    mime="text/csv",
                    key="download_resolve_csv",
                )
    else:
        find_mode = st.radio(
            "Input Mode",
            ["Single", f"List (up to {BATCH_LIMIT})"],
            horizontal=True,
            key="find_mode",
        )

        if find_mode == "Single":
            identifier_type = st.selectbox(
                "Identifier Type",
                ["email", "phone", "myq_user_id", "external_user_id", "account_id"],
                key="find_single_identifier_type",
                help="Select the exact type of the Real Value.",
            )
            real_value = st.text_input("Real Value", key="real_value_input")
            submitted = st.button("Find Token", type="primary")
            raw_values = [real_value]
        else:
            list_lookup_type = st.selectbox(
                "Identifier Type",
                [
                    "email",
                    "phone",
                    "myq_user_id",
                    "external_user_id",
                    "account_id",
                    "mixed",
                ],
                key="find_list_identifier_type",
                help="Choose a specific type when all values are the same. Use mixed only when the list contains different identifier types.",
            )
            uploaded_values = st.file_uploader(
                "Upload real value list (.txt or .csv)",
                type=["txt", "csv"],
                help="The file must contain one real value per line.",
                key="find_values_file",
            )
            pasted_values = st.text_area(
                "Or paste real values (one per line)",
                height=120,
                help="Enter one real value per line.",
                key="find_values_text",
            )
            submitted = st.button("Find Token List", type="primary")
            raw_values = _parse_list_input(uploaded_values, pasted_values)

        if submitted:
            requester_clean = signed_in_user_email
            reason_code_clean = reason_code.strip()
            approver_clean = approver.strip() or None
            values = [v.strip() for v in raw_values if (v or "").strip()]

            if not requester_clean:
                st.error("Requester is required for audit logging.")
                return

            if not EMAIL_PATTERN.match(requester_clean):
                st.error("The requester is not a valid email address.")
                return

            unlimited_access = _has_unlimited_access(requester_clean)

            if not values:
                if find_mode == "Single":
                    st.error("Provide the real value")
                else:
                    st.error("Provide at least one real value.")
                return
            if not _validate_batch_limit(item_label="Real value", requested_count=len(values)):
                return

            try:
                init_lakebase_connection()
            except Exception as exc:
                st.error(f"Token lookup failed: {exc}")
                return

            if not unlimited_access and not _validate_daily_limit(
                requester=requester_clean,
                requested_count=len(values),
            ):
                return

            if find_mode == "Single":
                try:
                    found_token = find_token_from_real_value(
                        identifier_type=identifier_type,
                        real_value=values[0],
                    )
                    resolved_identifier_type = identifier_type
                    log_find_token_success(
                        requester=requester_clean,
                        reason_code=reason_code_clean,
                        approver=approver_clean,
                        identifier_type=resolved_identifier_type,
                        real_value=values[0],
                        token=found_token,
                    )
                except ValueError as exc:
                    message = str(exc)
                    if "not found" in message.lower():
                        log_find_token_failure(
                            requester=requester_clean,
                            reason_code=reason_code_clean,
                            approver=approver_clean,
                            identifier_type=identifier_type,
                            real_value=values[0],
                            error_message="Real value not found",
                        )
                        st.error("Real Value not found")
                    else:
                        st.error(message)
                    return
                except Exception as exc:
                    st.error(f"Token lookup failed: {exc}")
                    return

                st.success("Token found")
                st.write("Identifier type:", resolved_identifier_type)
                st.code(found_token, language="text")
            else:
                rows: list[dict[str, str]] = []
                found_count = 0
                audit_events: list[dict[str, str | None]] = []

                selected_lookup_type = None if list_lookup_type == "mixed" else list_lookup_type
                batch_results = find_tokens_from_real_values_batch(
                    real_values=values,
                    identifier_type=selected_lookup_type,
                )

                for result in batch_results:
                    value_item = str(result["real_value"])
                    status = str(result["status"])
                    matched_type = result["identifier_type"]
                    matched_token = result["token"]

                    if status == "FOUND" and matched_type and matched_token:
                        audit_events.append(
                            {
                                "status": "FOUND",
                                "identifier_type": str(matched_type),
                                "real_value": value_item,
                                "token": str(matched_token),
                                "error_message": None,
                            }
                        )
                        rows.append(
                            {
                                "Real Value": value_item,
                                "Identifier Type": str(matched_type),
                                "Token": str(matched_token),
                            }
                        )
                        found_count += 1
                    else:
                        audit_events.append(
                            {
                                "status": "NOT_FOUND",
                                "identifier_type": str(matched_type) if matched_type else selected_lookup_type,
                                "real_value": value_item,
                                "token": None,
                                "error_message": "Real value not found",
                            }
                        )
                        rows.append(
                            {
                                "Real Value": value_item,
                                "Identifier Type": "Not found",
                                "Token": "Not found",
                            }
                        )

                try:
                    log_find_token_events_bulk(
                        requester=requester_clean,
                        reason_code=reason_code_clean,
                        approver=approver_clean,
                        events=audit_events,
                    )
                except Exception:
                    # Do not block response rendering if audit write fails.
                    pass

                st.success(f"Processed {len(rows)} real values. Found {found_count}.")
                st.dataframe(rows, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download CSV",
                    data=_rows_to_csv_bytes(rows, ["Real Value", "Identifier Type", "Token"]),
                    file_name="found_tokens.csv",
                    mime="text/csv",
                    key="download_find_csv",
                )


if __name__ == "__main__":
    main()
