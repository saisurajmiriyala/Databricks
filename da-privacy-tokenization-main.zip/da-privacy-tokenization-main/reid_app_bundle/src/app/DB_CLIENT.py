from __future__ import annotations

import hashlib
import os
import re
import base64
import unicodedata
from contextlib import contextmanager
from typing import Optional
from urllib.parse import urlparse

import psycopg
from databricks.sdk import WorkspaceClient
from psycopg.rows import dict_row

_WORKSPACE_ID_TO_SCOPE: dict[str, str] = {
    "4042327885044706": "cgi-eus-dev-ada-kv",
    "1819088249724627": "cgi-eus-qa-ada-kv",
    "526483533147103": "cgi-eus-prod-ada-kv",
}

_TOKEN_PREFIX_BY_TYPE: dict[str, str] = {
    "email": "eml_",
    "phone": "phn_",
    "myq_user_id": "usr_",
    "external_user_id": "xui_",
    "account_id": "acc_",
}

_VAULT_TABLE_BY_TYPE: dict[str, str] = {
    "email": "cg_vault.vault_email",
    "phone": "cg_vault.vault_phone",
    "myq_user_id": "cg_vault.vault_myq_user_id",
    "external_user_id": "cg_vault.vault_external_user_id",
    "account_id": "cg_vault.vault_account_id",
}

_TYPE_BY_TOKEN_PREFIX: dict[str, str] = {
    prefix: identifier_type for identifier_type, prefix in _TOKEN_PREFIX_BY_TYPE.items()
}

AUTHORIZED_STAFF_TABLE = os.environ.get(
    "REID_AUTHORIZED_STAFF_TABLE",
    "dev_audit_log.privacy.reid_authorized_staff",
)

_IDENTIFIER_PRIORITY: tuple[str, ...] = (
    "email",
    "phone",
    "myq_user_id",
    "external_user_id",
    "account_id",
)

_CONN: Optional[psycopg.Connection] = None


def _extract_workspace_id(host_or_url: str) -> str | None:
    match = re.search(r"adb-(\d+)", host_or_url or "")
    if not match:
        return None
    return match.group(1)


def fetch_secret_scope() -> str:
    scope = (os.environ.get("IDR_PEPPER_SECRET_SCOPE") or "").strip()
    if scope:
        return scope

    workspace_id = None
    # Databricks Apps commonly provides workspace URL/host as env vars.
    for env_key in ("DATABRICKS_HOST", "DATABRICKS_WORKSPACE_URL", "DBX_HOST"):
        workspace_id = _extract_workspace_id(os.environ.get(env_key, ""))
        if workspace_id:
            break

    try:
        if workspace_id is None:
            workspace_id = _extract_workspace_id(WorkspaceClient().config.host)
    except Exception:
        pass

    if workspace_id is None:
        raise RuntimeError(
            "Could not determine Databricks workspace id. Set IDR_PEPPER_SECRET_SCOPE explicitly."
        )

    mapped_scope = _WORKSPACE_ID_TO_SCOPE.get(workspace_id)
    if mapped_scope is None:
        raise RuntimeError(
            f"No secret scope mapping found for workspace id {workspace_id}. "
            "Set IDR_PEPPER_SECRET_SCOPE explicitly."
        )
    return mapped_scope


def _normalize_host(raw_host: str) -> str:
    value = (raw_host or "").strip()
    if value.startswith("http://") or value.startswith("https://"):
        parsed = urlparse(value)
        return parsed.hostname or value
    return value.rstrip("/")


def _read_secret_value(client: WorkspaceClient, scope: str, key: str) -> str:
    """Read a Databricks secret and return plain text.

    The Secrets API can return base64-encoded values in SDK responses.
    """
    secret_obj = client.secrets.get_secret(scope=scope, key=key)
    raw_value = (secret_obj.value or "").strip()
    if not raw_value:
        raise RuntimeError(f"Secret '{key}' in scope '{scope}' is empty.")

    try:
        decoded = base64.b64decode(raw_value, validate=True).decode("utf-8").strip()
        if decoded:
            return decoded
    except Exception:
        pass

    return raw_value


def _connect() -> psycopg.Connection:
    scope = fetch_secret_scope()
    client = WorkspaceClient()

    host_key = os.environ.get("IDR_LAKEBASE_HOST_SECRET_KEY", "dbx-lakebase-dev-host")
    db_key = os.environ.get("IDR_LAKEBASE_DATABASE_SECRET_KEY", "dbx-lakebase-dev-db")
    user_key = os.environ.get("IDR_LAKEBASE_USERNAME_SECRET_KEY", "dbx-lakebase-dev-user")
    password_key = os.environ.get("IDR_LAKEBASE_PASSWORD_SECRET_KEY", "dbx-lakebase-dev-password")

    host = _normalize_host(_read_secret_value(client, scope, host_key))
    db = _read_secret_value(client, scope, db_key)
    user = _read_secret_value(client, scope, user_key)
    password = _read_secret_value(client, scope, password_key)

    conn_str = (
        f"host={host} "
        f"dbname={db} "
        f"user={user} "
        f"password={password} "
        "port=5432"
    )

    conn = psycopg.connect(conn_str, row_factory=dict_row)
    conn.autocommit = True
    return conn


def init_connection() -> None:
    global _CONN
    if _is_usable(_CONN):
        return
    _CONN = _connect()


def _is_usable(conn: Optional[psycopg.Connection]) -> bool:
    return conn is not None and not conn.closed and not conn.broken


def _get_connection() -> psycopg.Connection:
    global _CONN
    if not _is_usable(_CONN):
        # Lakebase recycles idle connections, so rebuild instead of failing the request.
        _CONN = _connect()
    return _CONN


@contextmanager
def _cursor():
    global _CONN
    try:
        with _get_connection().cursor() as cur:
            yield cur
    except psycopg.OperationalError:
        if _CONN is not None:
            try:
                _CONN.close()
            except Exception:
                pass
        _CONN = _connect()
        with _CONN.cursor() as cur:
            yield cur


def _hash_sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().lower()


def is_requester_authorized(requester: str) -> bool:
    warehouse_id = (os.environ.get("DATABRICKS_SQL_WAREHOUSE_ID") or "").strip()
    if not warehouse_id:
        raise RuntimeError("DATABRICKS_SQL_WAREHOUSE_ID is not configured.")

    requester_clean = (requester or "").strip().lower()
    requester_sql = requester_clean.replace("'", "''")
    statement = f"""
    SELECT 1
    FROM {AUTHORIZED_STAFF_TABLE}
    WHERE lower(email) = '{requester_sql}'
      AND enabled = true
    LIMIT 1
    """

    response = WorkspaceClient().statement_execution.execute_statement(
        warehouse_id=warehouse_id,
        statement=statement,
        wait_timeout="30s",
    )
    state = getattr(getattr(response, "status", None), "state", None)
    state_value = getattr(state, "value", str(state))
    if "SUCCEEDED" not in state_value:
        message = getattr(getattr(response, "status", None), "error", None) or state_value
        raise RuntimeError(f"Authorization lookup failed: {message}")

    data = getattr(getattr(response, "result", None), "data_array", None) or []
    return bool(data)


def get_requester_daily_usage_count(requester: str) -> int:
    requester_clean = (requester or "").strip().lower()
    query = """
    SELECT count(*) AS usage_count
    FROM cg_audit.detokenize_log
    WHERE lower(requester) = %(requester)s
          AND created_at >= date_trunc('day', now())
          AND created_at < date_trunc('day', now()) + interval '1 day'
    """

    with _cursor() as cur:
        cur.execute(query, {"requester": requester_clean})
        row = cur.fetchone()

    return int(row["usage_count"] if row else 0)


def _normalize_identifier_value(identifier_type: str, value: str) -> str:
    raw = (value or "").strip()
    if not raw:
        raise ValueError("Real value is required.")

    if identifier_type == "email":
        return unicodedata.normalize("NFC", raw).casefold()

    if identifier_type == "phone":
        if raw.endswith(".0"):
            raw = raw[:-2]
        digits = "".join(ch for ch in raw if ch.isdigit())
        if len(digits) == 11 and digits.startswith("1"):
            digits = digits[1:]
        if len(digits) != 10:
            raise ValueError("Phone value cannot be normalized to a 10-digit number.")
        return f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"

    if identifier_type == "myq_user_id":
        return raw.upper()

    if identifier_type in {"external_user_id", "account_id"}:
        return raw

    raise ValueError(f"Unsupported identifier_type: {identifier_type}")


def find_token_from_real_value(*, identifier_type: str, real_value: str) -> str:
    prefix = _TOKEN_PREFIX_BY_TYPE.get(identifier_type)
    table = _VAULT_TABLE_BY_TYPE.get(identifier_type)
    if prefix is None or table is None:
        raise ValueError(f"Unsupported identifier_type: {identifier_type}")

    normalized_value = _normalize_identifier_value(identifier_type, real_value)

    query = f"""
    SELECT token
    FROM {table}
    WHERE real_value = %(real_value)s
      AND token LIKE %(token_prefix)s
      AND deletion_status = 'active'
    LIMIT 1
    """

    with _cursor() as cur:
        cur.execute(
            query,
            {
                "real_value": normalized_value,
                "token_prefix": f"{prefix}%",
            },
        )
        row = cur.fetchone()

    if not row:
        raise ValueError(f"Real value not found in {table}: {normalized_value}")

    return str(row["token"])


def find_tokens_from_real_values_batch(
    *, real_values: list[str], identifier_type: str | None = None
) -> list[dict[str, str | None]]:
    """Batch token lookup using one SQL query with UNION ALL.

    Returns one result per input item in original order.
    """
    if not real_values:
        return []

    lookup_types = (identifier_type,) if identifier_type else _IDENTIFIER_PRIORITY
    for itype in lookup_types:
        if itype not in _VAULT_TABLE_BY_TYPE or itype not in _TOKEN_PREFIX_BY_TYPE:
            raise ValueError(f"Unsupported identifier_type: {itype}")

    # Build normalized candidates once per input and type.
    candidates: list[tuple[int, str, str, str, str]] = []
    seen_candidates: set[tuple[int, str, str, str]] = set()
    for idx, input_value in enumerate(real_values):
        raw = (input_value or "").strip()
        if not raw:
            continue
        for itype in lookup_types:
            try:
                normalized = _normalize_identifier_value(itype, raw)
            except ValueError:
                continue
            dedupe_key = (idx, itype, normalized, _TOKEN_PREFIX_BY_TYPE[itype])
            if dedupe_key in seen_candidates:
                continue
            seen_candidates.add(dedupe_key)
            candidates.append((idx, raw, itype, normalized, _TOKEN_PREFIX_BY_TYPE[itype]))

    if not candidates:
        return [
            {
                "real_value": value,
                "identifier_type": None,
                "token": None,
                "status": "NOT_FOUND",
            }
            for value in real_values
        ]

    values_sql = ",\n        ".join(["(%s, %s, %s, %s, %s)"] * len(candidates))
    params: list[str | int] = []
    for row in candidates:
        params.extend(row)

    union_queries: list[str] = []
    for itype in lookup_types:
        table = _VAULT_TABLE_BY_TYPE[itype]
        union_queries.append(
            f"""
            SELECT c.input_idx, c.input_value, c.identifier_type, v.token
            FROM input_candidates c
            JOIN {table} v
              ON c.identifier_type = '{itype}'
             AND v.real_value = c.normalized_value
             AND v.deletion_status = 'active'
                         AND left(v.token, length(c.token_prefix)) = c.token_prefix
            """
        )

    query = f"""
    WITH input_candidates (input_idx, input_value, identifier_type, normalized_value, token_prefix) AS (
        VALUES
        {values_sql}
    ),
    matches AS (
        {'UNION ALL'.join(union_queries)}
    )
    SELECT input_idx, input_value, identifier_type, token
    FROM matches
    """

    with _cursor() as cur:
        cur.execute(query, params)
        rows = cur.fetchall()

    matches_by_idx: dict[int, list[dict[str, str]]] = {}
    for row in rows:
        idx = int(row["input_idx"])
        matches_by_idx.setdefault(idx, []).append(
            {
                "identifier_type": str(row["identifier_type"]),
                "token": str(row["token"]),
            }
        )

    priority_rank = {itype: i for i, itype in enumerate(_IDENTIFIER_PRIORITY)}
    results: list[dict[str, str | None]] = []
    for idx, raw in enumerate(real_values):
        candidates_for_item = matches_by_idx.get(idx, [])
        if not candidates_for_item:
            results.append(
                {
                    "real_value": raw,
                    "identifier_type": None,
                    "token": None,
                    "status": "NOT_FOUND",
                }
            )
            continue

        selected = sorted(
            candidates_for_item,
            key=lambda item: (priority_rank.get(item["identifier_type"], 999), item["token"]),
        )[0]
        results.append(
            {
                "real_value": raw,
                "identifier_type": selected["identifier_type"],
                "token": selected["token"],
                "status": "FOUND",
            }
        )

    return results


def generate_token_from_real_value(*, identifier_type: str, real_value: str) -> str:
    """Backward-compatible wrapper; prefer find_token_from_real_value."""
    return find_token_from_real_value(identifier_type=identifier_type, real_value=real_value)


def _log_detokenize(
    requester: str,
    reason_code: str,
    element_type: str,
    token: str,
    real_value: str,
    approver: str | None = None,
    request_status: str = "SUCCESS",
    error_message: str | None = None,
) -> None:
    params = {
        "requester": requester,
        "approver": approver,
        "reason_code": reason_code,
        "element_type": element_type,
        "token_hash": _hash_sha256(token),
        "value_hash": _hash_sha256(real_value),
        "request_status": request_status,
        "error_message": error_message,
    }

    query = """
    INSERT INTO cg_audit.detokenize_log (
        requester,
        approver,
        reason_code,
        element_type,
        token_hash,
        value_hash,
        request_status,
        error_message
    ) VALUES (
        %(requester)s,
        %(approver)s,
        %(reason_code)s,
        %(element_type)s,
        %(token_hash)s,
        %(value_hash)s,
        %(request_status)s,
        %(error_message)s
    )
    """

    with _cursor() as cur:
        cur.execute(query, params)


def log_detokenize_failure(
    *,
    token: str,
    requester: str,
    reason_code: str,
    element_type: str,
    error_message: str,
    approver: str | None = None,
) -> None:
    """Write a failure event to detokenize_log without storing plaintext."""
    # value_hash remains a SHA-256, but fingerprints the failure metadata.
    failure_fingerprint = f"failure:{error_message}"
    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type=element_type,
        token=token,
        real_value=failure_fingerprint,
        request_status="FAILED",
        error_message=error_message,
    )


def log_resolve_token_events_bulk(
    *,
    requester: str,
    reason_code: str,
    approver: str | None,
    events: list[dict[str, str | None]],
) -> None:
    """Bulk insert Resolve Token audit events in one statement for list mode."""
    if not events:
        return

    values: list[tuple[str, str | None, str, str, str, str, str, str | None]] = []

    for event in events:
        token = str(event.get("token") or "")
        element_type = str(event.get("element_type") or "unknown")
        status = str(event.get("status") or "FAILED").upper()
        real_value = event.get("real_value")
        error_message = event.get("error_message")

        if status == "FOUND" and real_value:
            value_for_hash = str(real_value)
            request_status = "SUCCESS"
            error_message = None
        else:
            value_for_hash = f"failure:{error_message or 'Token not found'}"
            request_status = "FAILED"
            if not error_message:
                error_message = "Token not found"

        values.append(
            (
                requester,
                approver,
                reason_code,
                element_type,
                _hash_sha256(token),
                _hash_sha256(value_for_hash),
                request_status,
                str(error_message) if error_message else None,
            )
        )

    placeholders = ",\n        ".join(["(%s, %s, %s, %s, %s, %s, %s, %s)"] * len(values))
    params: list[str | None] = []
    for row in values:
        params.extend(row)

    query = f"""
    INSERT INTO cg_audit.detokenize_log (
        requester,
        approver,
        reason_code,
        element_type,
        token_hash,
        value_hash,
        request_status,
        error_message
    ) VALUES
        {placeholders}
    """

    with _cursor() as cur:
        cur.execute(query, params)


def log_find_token_success(
    *,
    requester: str,
    reason_code: str,
    identifier_type: str,
    real_value: str,
    token: str,
    approver: str | None = None,
) -> None:
    """Write a successful Find Token event using the same audit schema."""
    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type=identifier_type,
        token=token,
        real_value=real_value,
        request_status="SUCCESS",
        error_message=None,
    )


def log_find_token_failure(
    *,
    requester: str,
    reason_code: str,
    identifier_type: str | None,
    real_value: str,
    error_message: str,
    approver: str | None = None,
) -> None:
    """Write a failed Find Token event without storing plaintext values."""
    resolved_type = identifier_type if identifier_type in _TOKEN_PREFIX_BY_TYPE else "unknown"
    if resolved_type == "unknown":
        normalized_value = (real_value or "").strip()
    else:
        normalized_value = _normalize_identifier_value(resolved_type, real_value)

    token_fingerprint = f"find-token-miss:{resolved_type}:{normalized_value}"
    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type=resolved_type,
        token=token_fingerprint,
        real_value=normalized_value,
        request_status="FAILED",
        error_message=error_message,
    )


def log_find_token_events_bulk(
    *,
    requester: str,
    reason_code: str,
    approver: str | None,
    events: list[dict[str, str | None]],
) -> None:
    """Bulk insert Find Token audit events in one statement for list mode."""
    if not events:
        return

    values: list[tuple[str, str | None, str, str, str, str, str, str | None]] = []

    for event in events:
        status = str(event.get("status") or "FAILED").upper()
        real_value = str(event.get("real_value") or "")
        identifier_type = event.get("identifier_type")
        token = event.get("token")
        error_message = event.get("error_message")

        resolved_type = (
            str(identifier_type)
            if identifier_type in _TOKEN_PREFIX_BY_TYPE
            else "unknown"
        )

        if status == "FOUND" and token:
            token_for_hash = str(token)
            value_for_hash = real_value
            error_message = None
            request_status = "SUCCESS"
        else:
            if resolved_type == "unknown":
                normalized_value = (real_value or "").strip()
            else:
                normalized_value = _normalize_identifier_value(resolved_type, real_value)
            token_for_hash = f"find-token-miss:{resolved_type}:{normalized_value}"
            value_for_hash = normalized_value
            request_status = "FAILED"
            if not error_message:
                error_message = "Real value not found"

        values.append(
            (
                requester,
                approver,
                reason_code,
                resolved_type,
                _hash_sha256(token_for_hash),
                _hash_sha256(value_for_hash),
                request_status,
                str(error_message) if error_message else None,
            )
        )

    placeholders = ",\n        ".join(["(%s, %s, %s, %s, %s, %s, %s, %s)"] * len(values))
    params: list[str | None] = []
    for row in values:
        params.extend(row)

    query = f"""
    INSERT INTO cg_audit.detokenize_log (
        requester,
        approver,
        reason_code,
        element_type,
        token_hash,
        value_hash,
        request_status,
        error_message
    ) VALUES
        {placeholders}
    """

    with _cursor() as cur:
        cur.execute(query, params)


def _resolve_value(token: str, table: str) -> str:
    query = f"""
    SELECT real_value
    FROM {table}
    WHERE token = %(token)s
      AND deletion_status = 'active'
    LIMIT 1
    """

    with _cursor() as cur:
        cur.execute(query, {"token": token})
        row = cur.fetchone()

    if not row:
        raise ValueError(f"Token not found in {table}: {token}")

    return str(row["real_value"])


def resolve_tokens_batch(*, tokens: list[str]) -> list[dict[str, str | None]]:
    """Resolve tokens using one SQL query with UNION ALL across vault tables."""
    if not tokens:
        return []

    candidates: list[tuple[int, str, str]] = []
    for idx, token in enumerate(tokens):
        token_clean = (token or "").strip()
        matched_type = None
        for prefix, identifier_type in _TYPE_BY_TOKEN_PREFIX.items():
            if token_clean.startswith(prefix):
                matched_type = identifier_type
                break
        if matched_type:
            candidates.append((idx, token_clean, matched_type))

    if not candidates:
        return [
            {
                "token": token,
                "element_type": "unknown",
                "real_value": None,
                "status": "NOT_FOUND",
            }
            for token in tokens
        ]

    values_sql = ",\n        ".join(["(%s, %s, %s)"] * len(candidates))
    params: list[str | int] = []
    for row in candidates:
        params.extend(row)

    union_queries: list[str] = []
    for identifier_type in _IDENTIFIER_PRIORITY:
        table = _VAULT_TABLE_BY_TYPE[identifier_type]
        union_queries.append(
            f"""
            SELECT c.input_idx, c.token, c.element_type, v.real_value
            FROM input_tokens c
            JOIN {table} v
              ON c.element_type = '{identifier_type}'
             AND v.token = c.token
             AND v.deletion_status = 'active'
            """
        )

    query = f"""
    WITH input_tokens (input_idx, token, element_type) AS (
        VALUES
        {values_sql}
    ),
    matches AS (
        {'UNION ALL'.join(union_queries)}
    )
    SELECT input_idx, token, element_type, real_value
    FROM matches
    """

    with _cursor() as cur:
        cur.execute(query, params)
        rows = cur.fetchall()

    matches_by_idx: dict[int, dict[str, str]] = {}
    for row in rows:
        matches_by_idx[int(row["input_idx"])] = {
            "element_type": str(row["element_type"]),
            "real_value": str(row["real_value"]),
        }

    results: list[dict[str, str | None]] = []
    for idx, token in enumerate(tokens):
        token_clean = (token or "").strip()
        match = matches_by_idx.get(idx)
        if match:
            results.append(
                {
                    "token": token_clean,
                    "element_type": match["element_type"],
                    "real_value": match["real_value"],
                    "status": "FOUND",
                }
            )
        else:
            element_type = "unknown"
            for prefix, identifier_type in _TYPE_BY_TOKEN_PREFIX.items():
                if token_clean.startswith(prefix):
                    element_type = identifier_type
                    break
            results.append(
                {
                    "token": token_clean,
                    "element_type": element_type,
                    "real_value": None,
                    "status": "NOT_FOUND",
                }
            )

    return results


def _detokenize(
    *,
    token: str,
    requester: str,
    element_type: str,
    table: str,
    reason_code: str = "",
    approver: str | None = None,
) -> str:
    value = _resolve_value(token, table)
    _log_detokenize(
        requester=requester,
        approver=approver,
        reason_code=reason_code,
        element_type=element_type,
        token=token,
        real_value=value,
    )
    return value


def detokenize_email(
    *,
    token: str,
    requester: str,
    reason_code: str = "",
    approver: str | None = None,
) -> str:
    return _detokenize(
        token=token,
        requester=requester,
        reason_code=reason_code,
        approver=approver,
        element_type="email",
        table="cg_vault.vault_email",
    )


def detokenize_phone(
    *,
    token: str,
    requester: str,
    reason_code: str = "",
    approver: str | None = None,
) -> str:
    return _detokenize(
        token=token,
        requester=requester,
        reason_code=reason_code,
        approver=approver,
        element_type="phone",
        table="cg_vault.vault_phone",
    )


def detokenize_myq_user_id(
    *,
    token: str,
    requester: str,
    reason_code: str = "",
    approver: str | None = None,
) -> str:
    return _detokenize(
        token=token,
        requester=requester,
        reason_code=reason_code,
        approver=approver,
        element_type="myq_user_id",
        table="cg_vault.vault_myq_user_id",
    )


def detokenize_external_user_id(
    *,
    token: str,
    requester: str,
    reason_code: str = "",
    approver: str | None = None,
) -> str:
    return _detokenize(
        token=token,
        requester=requester,
        reason_code=reason_code,
        approver=approver,
        element_type="external_user_id",
        table="cg_vault.vault_external_user_id",
    )


def detokenize_account_id(
    *,
    token: str,
    requester: str,
    reason_code: str = "",
    approver: str | None = None,
) -> str:
    return _detokenize(
        token=token,
        requester=requester,
        reason_code=reason_code,
        approver=approver,
        element_type="account_id",
        table="cg_vault.vault_account_id",
    )
