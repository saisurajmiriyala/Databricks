# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
from lakebase_utils.idr.resolution import add_hmacs
from lakebase_utils.idr.hmac_util import fetch_secret_scope
from lakebase_utils.postgres.connection import ptk_connect,fetch_lakebase_credentials
from lakebase_utils.postgres.queryhub import ptk_execute, ptk_write_dataframe
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
from lakebase_utils.Dsar.dsar import get_dsar_requests

ptk_connect(**fetch_lakebase_credentials())

start_global_notebook_logger()


# extract all DSAR requests from One Trust
get_dsar_requests("production")

df = spark.sql(f"""select request_id as dsar_request_id, email, current_timestamp() as created_at from 
               dev_audit_log.privacy.prv_dsar_requests_status where approval_status = 'Approved'""")

log_checkpoint("source dataframe created")

ptk_execute("Truncate table public.deletion_request_emails")

#load temp table with new requests

ptk_write_dataframe(df, 'public.deletion_request_emails')

#Update the audit Table with deleted requests

ptk_execute(f"""
        MERGE INTO cg_audit.delete_request_audit AS tgt
        USING (
            SELECT 
                a.dsar_request_id, 
                a.email, 
                'not found in vault' AS status, 
                now() AS audit_ts
            FROM (select dsar_request_id, email from public.deletion_request_emails where dsar_request_id 
                  not in (select dsar_request_id from cg_audit.delete_request_audit)) a
            LEFT JOIN (
                SELECT canonical_internal_id, real_value 
                FROM cg_vault.vault_email 
                WHERE identifier_type = 'email'
            ) b
        ON a.email = b.real_value
        WHERE b.canonical_internal_id IS NULL
        ) AS src
        ON tgt.dsar_request_id = src.dsar_request_id

        WHEN NOT MATCHED THEN
        INSERT (dsar_request_id, email, deletion_status, created_at)
        VALUES (src.dsar_request_id, src.email, src.status, src.audit_ts)
""")

#update deltion status on vault_account_id

ptk_execute(f"""
          UPDATE cg_vault.vault_account_id a
          SET 
              deletion_status = 'tombstoned',
              deleted_at = now(),
              deletion_reason = 'one trust request',
              dsar_request_id = b.dsar_request_id
          FROM (
              SELECT 
                  b.canonical_internal_id,
                  a.dsar_request_id
              FROM (
                  SELECT dsar_request_id, email 
                  FROM public.deletion_request_emails 
                  WHERE dsar_request_id NOT IN (
                      SELECT dsar_request_id FROM cg_audit.delete_request_audit
                  )
              ) a
              LEFT JOIN (
                  SELECT canonical_internal_id, real_value 
                  FROM cg_vault.vault_email
                  WHERE identifier_type = 'email'
              ) b
              ON a.email = b.real_value
              WHERE b.canonical_internal_id IS NOT NULL
          ) b
          WHERE a.canonical_internal_id = b.canonical_internal_id         

""")

#update deltion status on vault_email

ptk_execute(f"""
          UPDATE cg_vault.vault_email a
          SET 
              deletion_status = 'tombstoned',
              deleted_at = now(),
              deletion_reason = 'one trust request',
              dsar_request_id = b.dsar_request_id
          FROM (
              SELECT 
                  b.canonical_internal_id,
                  a.dsar_request_id
              FROM (
                  SELECT dsar_request_id, email 
                  FROM public.deletion_request_emails 
                  WHERE dsar_request_id NOT IN (
                      SELECT dsar_request_id FROM cg_audit.delete_request_audit
                  )
              ) a
              LEFT JOIN (
                  SELECT canonical_internal_id, real_value 
                  FROM cg_vault.vault_email
                  WHERE identifier_type = 'email'
              ) b
              ON a.email = b.real_value
              WHERE b.canonical_internal_id IS NOT NULL
          ) b
          WHERE a.canonical_internal_id = b.canonical_internal_id     
            
""")

#update deltion status on vault_external_user_id

ptk_execute(f"""
          UPDATE cg_vault.vault_external_user_id a
          SET 
              deletion_status = 'tombstoned',
              deleted_at = now(),
              deletion_reason = 'one trust request',
              dsar_request_id = b.dsar_request_id
          FROM (
              SELECT 
                  b.canonical_internal_id,
                  a.dsar_request_id
              FROM (
                  SELECT dsar_request_id, email 
                  FROM public.deletion_request_emails 
                  WHERE dsar_request_id NOT IN (
                      SELECT dsar_request_id FROM cg_audit.delete_request_audit
                  )
              ) a
              LEFT JOIN (
                  SELECT canonical_internal_id, real_value 
                  FROM cg_vault.vault_email
                  WHERE identifier_type = 'email'
              ) b
              ON a.email = b.real_value
              WHERE b.canonical_internal_id IS NOT NULL
          ) b
          WHERE a.canonical_internal_id = b.canonical_internal_id                       
""")

#update deltion status on vault_myq_user_id

ptk_execute(f"""
          UPDATE cg_vault.vault_myq_user_id a
          SET 
              deletion_status = 'tombstoned',
              deleted_at = now(),
              deletion_reason = 'one trust request',
              dsar_request_id = b.dsar_request_id
          FROM (
              SELECT 
                  b.canonical_internal_id,
                  a.dsar_request_id
              FROM (
                  SELECT dsar_request_id, email 
                  FROM public.deletion_request_emails 
                  WHERE dsar_request_id NOT IN (
                      SELECT dsar_request_id FROM cg_audit.delete_request_audit
                  )
              ) a
              LEFT JOIN (
                  SELECT canonical_internal_id, real_value 
                  FROM cg_vault.vault_email
                  WHERE identifier_type = 'email'
              ) b
              ON a.email = b.real_value
              WHERE b.canonical_internal_id IS NOT NULL
          ) b
          WHERE a.canonical_internal_id = b.canonical_internal_id
""")


#update deltion status on vault_phone

ptk_execute(f"""
          UPDATE cg_vault.vault_phone a
          SET 
              deletion_status = 'tombstoned',
              deleted_at = now(),
              deletion_reason = 'one trust request',
              dsar_request_id = b.dsar_request_id
          FROM (
              SELECT 
                  b.canonical_internal_id,
                  a.dsar_request_id
              FROM (
                  SELECT dsar_request_id, email 
                  FROM public.deletion_request_emails 
                  WHERE dsar_request_id NOT IN (
                      SELECT dsar_request_id FROM cg_audit.delete_request_audit
                  )
              ) a
              LEFT JOIN (
                  SELECT canonical_internal_id, real_value 
                  FROM cg_vault.vault_email
                  WHERE identifier_type = 'email'
              ) b
              ON a.email = b.real_value
              WHERE b.canonical_internal_id IS NOT NULL
          ) b
          WHERE a.canonical_internal_id = b.canonical_internal_id            

""")

#update deltion status on account_identifier

ptk_execute(f"""
		UPDATE cg_identity.account_identifier a
		SET 
			deletion_status = 'tombstoned',
			deleted_at = now(),
			deletion_reason = 'one trust request',
			dsar_request_id = b.dsar_request_id
		FROM (
			SELECT 
				b.canonical_internal_id,
				a.dsar_request_id
			FROM (
				SELECT dsar_request_id, email 
				FROM public.deletion_request_emails 
				WHERE dsar_request_id NOT IN (
					SELECT dsar_request_id FROM cg_audit.delete_request_audit
				)
			) a
			LEFT JOIN (
				SELECT canonical_internal_id, real_value 
				FROM cg_vault.vault_email
				WHERE identifier_type = 'email'
			) b
			ON a.email = b.real_value
			WHERE b.canonical_internal_id IS NOT NULL
		) b
		WHERE a.canonical_account_id = b.canonical_internal_id
""")

#update deltion status on account_identity

ptk_execute(f"""
		UPDATE cg_identity.account_identity a
		SET 
			deletion_status = 'tombstoned',
			deleted_at = now(),
			deletion_reason = 'one trust request',
			dsar_request_id = b.dsar_request_id
		FROM (
			SELECT 
				b.canonical_internal_id,
				a.dsar_request_id
			FROM (
				SELECT dsar_request_id, email 
				FROM public.deletion_request_emails 
				WHERE dsar_request_id NOT IN (
					SELECT dsar_request_id FROM cg_audit.delete_request_audit
				)
			) a
			LEFT JOIN (
				SELECT canonical_internal_id, real_value 
				FROM cg_vault.vault_email
				WHERE identifier_type = 'email'
			) b
			ON a.email = b.real_value
			WHERE b.canonical_internal_id IS NOT NULL
		) b
		WHERE a.canonical_account_id = b.canonical_internal_id        
""")

#update deltion status on user_identifier

ptk_execute(f"""
		UPDATE cg_identity.user_identifier a
		SET 
			deletion_status = 'tombstoned',
			deleted_at = now(),
			deletion_reason = 'one trust request',
			dsar_request_id = b.dsar_request_id
		FROM (
			SELECT 
				b.canonical_internal_id,
				a.dsar_request_id
			FROM (
				SELECT dsar_request_id, email 
				FROM public.deletion_request_emails 
				WHERE dsar_request_id NOT IN (
					SELECT dsar_request_id FROM cg_audit.delete_request_audit
				)
			) a
			LEFT JOIN (
				SELECT canonical_internal_id, real_value 
				FROM cg_vault.vault_email
				WHERE identifier_type = 'email'
			) b
			ON a.email = b.real_value
			WHERE b.canonical_internal_id IS NOT NULL
		) b
		WHERE a.canonical_user_id = b.canonical_internal_id
""")

#update deltion status on user_identity
ptk_execute(f"""
		UPDATE cg_identity.user_identity a
		SET 
			deletion_status = 'tombstoned',
			deleted_at = now(),
			deletion_reason = 'one trust request',
			dsar_request_id = b.dsar_request_id
		FROM (
			SELECT 
				b.canonical_internal_id,
				a.dsar_request_id
			FROM (
				SELECT dsar_request_id, email 
				FROM public.deletion_request_emails 
				WHERE dsar_request_id NOT IN (
					SELECT dsar_request_id FROM cg_audit.delete_request_audit
				)
			) a
			LEFT JOIN (
				SELECT canonical_internal_id, real_value 
				FROM cg_vault.vault_email
				WHERE identifier_type = 'email'
			) b
			ON a.email = b.real_value
			WHERE b.canonical_internal_id IS NOT NULL
		) b
		WHERE a.canonical_user_id = b.canonical_internal_id
""")


#Update the audit Table with deleted requests
ptk_execute(f"""
        MERGE INTO cg_audit.delete_request_audit AS tgt
        USING (
            SELECT 
                a.dsar_request_id, 
                a.email, 
                'Deletion Successful' AS status, 
                now() AS audit_ts
            FROM (select dsar_request_id, email from public.deletion_request_emails where dsar_request_id 
                  not in (select dsar_request_id from cg_audit.delete_request_audit)) a
            LEFT JOIN (
                SELECT canonical_internal_id, real_value 
                FROM cg_vault.vault_email 
                WHERE identifier_type = 'email'
            ) b
        ON a.email = b.real_value
        WHERE b.canonical_internal_id IS NOT NULL
        ) AS src
        ON tgt.dsar_request_id = src.dsar_request_id

        WHEN NOT MATCHED THEN
        INSERT (dsar_request_id, email, deletion_status, created_at)
        VALUES (src.dsar_request_id, src.email, src.status, src.audit_ts)

""")