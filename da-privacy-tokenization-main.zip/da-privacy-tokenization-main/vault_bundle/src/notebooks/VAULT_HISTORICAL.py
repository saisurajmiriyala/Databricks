# Databricks notebook source
# COMMAND ----------

# PRV-53 -- historical load for all cg_vault tables.
#
# Counterpart to VAULT_INCREMENTAL.py. Key differences from incremental:
#   1. The whole population, not the rows changed in the last few days.
#   2. Staging uses load_uc_to_lakebase (distributed COPY) instead of ptk_write_dataframe.
#   3. TRUNCATE_TARGET empties all vault tables before loading, making reruns idempotent.
#
# Run once per environment per release, not on a schedule.

import os

from lakebase_utils.idr.resolution import add_hmacs
from lakebase_utils.idr.hmac_util import fetch_secret_scope
from lakebase_utils.postgres.bulkload import load_uc_to_lakebase
from lakebase_utils.postgres.connection import ptk_connect, fetch_lakebase_credentials
from lakebase_utils.postgres.queryhub import ptk_execute
from lakebase_utils.postgres.vault import generate_token, normalize_real_value
from lakebase_utils.logger.lakeflow import start_global_notebook_logger, log_checkpoint
from pyspark.sql import functions as F

start_global_notebook_logger()

dbutils.widgets.dropdown("TRUNCATE_TARGET", "yes", ["yes", "no"])
dbutils.widgets.text("STATEMENT_TIMEOUT_MS", "21600000")

VAULT_STAGE  = "public.vault_stage"
TIMEOUT_MS   = int(dbutils.widgets.get("STATEMENT_TIMEOUT_MS") or 21_600_000)
SECRET_SCOPE = fetch_secret_scope()

ptk_connect(**fetch_lakebase_credentials())

os.environ["IDR_PEPPER_SECRET_SCOPE"] = SECRET_SCOPE

if dbutils.widgets.get("TRUNCATE_TARGET") == "yes":
    for _t in ("vault_email", "vault_phone", "vault_myq_user_id", "vault_external_user_id", "vault_account_id"):
        ptk_execute(f"TRUNCATE TABLE cg_vault.{_t}")

# Legacy catalog holding the source tables, set per environment by the job.
dbutils.widgets.text("LEGACY_CATALOG", "", "Legacy catalog holding the source tables")
LEGACY_CATALOG = dbutils.widgets.get("LEGACY_CATALOG").strip()

# Root of the full-history extracts, in a dev-only volume. Same variable the IDR
# historical notebooks read. Only dev has a value, and that is what picks the source:
# without a path, query the real tables, with no day window — a historical load takes the
# whole population.
dbutils.widgets.text("IDR_HISTORICAL_SOURCE_ROOT", "", "Volume path holding the historical extracts")
SOURCE_ROOT = dbutils.widgets.get("IDR_HISTORICAL_SOURCE_ROOT").strip().rstrip("/")

if SOURCE_ROOT:
    df_users = spark.read.format("parquet").load(f"{SOURCE_ROOT}/users/")
    df_account_users = spark.read.format("parquet").load(f"{SOURCE_ROOT}/accounts_users/")
else:
    # The users feed. Same query in the other three notebooks that read it; they have to agree.
    # Raw f-string: the phone regex needs its backslashes to reach the SQL literal.
    df_users = spark.sql(rf"""
        WITH contact_current AS (
            SELECT Id, User_ID__c
            FROM (
                SELECT Id,
                       User_ID__c,
                       ROW_NUMBER() OVER (PARTITION BY Id ORDER BY SystemModstamp DESC, User_ID__c DESC) AS rn
                FROM {LEGACY_CATALOG}.silver_data_lake.salesforce_contact_stage
                WHERE NOT IsDeleted
            )
            WHERE rn = 1
        ),
        users AS (
            SELECT DISTINCT
                UPPER(TRIM(up.UserId)) AS UpperUserId,
                up.AnalyticsId         AS external_userid_firebase
            FROM {LEGACY_CATALOG}.myq_sql.cgi_usersprofile up
            JOIN {LEGACY_CATALOG}.myq_sql.cgi_accountuser cau
                ON up.UserId = cau.UserId
            JOIN {LEGACY_CATALOG}.myq_sql.cgi_account acc
                ON cau.AccountId = acc.AccountId
        ),
        membership AS (
            SELECT UpperUserId, Email
            FROM (
                SELECT
                    UPPER(TRIM(UserId)) AS UpperUserId,
                    Email,
                    ROW_NUMBER() OVER (
                        PARTITION BY UPPER(TRIM(UserId)) ORDER BY crt_dttm DESC, Email DESC
                    ) AS rn
                FROM {LEGACY_CATALOG}.myq_sql.aspnet_membership
                WHERE UserId IS NOT NULL AND TRIM(UserId) <> ''
            )
            WHERE rn = 1
        ),
        contact AS (
            SELECT
                UPPER(TRIM(User_ID__c)) AS UpperUserId,
                MAX(Id)                 AS external_user_id,
                COUNT(DISTINCT Id)      AS n_contacts
            FROM contact_current
            WHERE User_ID__c IS NOT NULL AND TRIM(User_ID__c) <> ''
            GROUP BY UPPER(TRIM(User_ID__c))
        ),
        user_email_sf AS (
            SELECT
                m.UpperUserId              AS myq_user_id,
                m.Email                    AS email,
                c.external_user_id         AS external_userid_salesforce,
                r.external_userid_firebase,
                c.n_contacts,
                CASE
                    WHEN m.Email IS NOT NULL AND TRIM(m.Email) <> ''
                     AND c.external_user_id IS NOT NULL AND TRIM(c.external_user_id) <> ''
                        THEN 'email_and_external'
                    WHEN m.Email IS NOT NULL AND TRIM(m.Email) <> ''
                        THEN 'email_only'
                    WHEN c.external_user_id IS NOT NULL AND TRIM(c.external_user_id) <> ''
                        THEN 'external_only'
                    ELSE 'none'
                END AS coverage
            FROM membership m
            JOIN users r ON m.UpperUserId = r.UpperUserId
            LEFT JOIN contact c ON m.UpperUserId = c.UpperUserId
        ),
        tmp_phones AS (
            SELECT
                UPPER(TRIM(upf.UserId)) AS userid,
                CASE
                    WHEN upf.MobilePhone IS NULL    THEN NULL
                    WHEN TRIM(upf.MobilePhone) = '' THEN NULL
                    ELSE REGEXP_REPLACE(TRIM(upf.MobilePhone), '[\\s\\(\\)\\-\\+]', '')
                END AS clean_phone
            FROM {LEGACY_CATALOG}.myq_sql.cgi_userpartnerfunctions upf
            JOIN {LEGACY_CATALOG}.myq_sql.aspnet_membership mem
                ON upf.UserId = mem.UserId
            WHERE upf.PartnerFunctionCode = 'AG'
              AND mem.IsActive
        ),
        v_users AS (
            SELECT DISTINCT * EXCEPT (n_contacts, coverage, userid)
            FROM user_email_sf AS u
            LEFT JOIN tmp_phones AS p ON u.myq_user_id = p.userid
            WHERE n_contacts = 1
              AND coverage = 'email_and_external'
              AND external_userid_firebase IS NOT NULL
        )
        SELECT * FROM v_users
    """)

    # Which user belongs to which account.
    df_account_users = spark.sql(rf"""
        SELECT DISTINCT
            acc.AccountId AS account_id,
            up.UserId     AS user_id
        FROM {LEGACY_CATALOG}.myq_sql.cgi_accountuser cau
        JOIN {LEGACY_CATALOG}.myq_sql.cgi_account acc
            ON cau.AccountId = acc.AccountId
        JOIN {LEGACY_CATALOG}.myq_sql.cgi_usersprofile up
            ON cau.UserId = up.UserId
        WHERE NOT cau.IsDeleted
    """)

log_checkpoint("source loaded")

df_hmacs = add_hmacs(df_users, [
    ("myq_user_id",                "myq_user_id",      "anchor_hmac"),
    ("email",                      "email",             "email_hmac"),
    ("external_userid_salesforce", "external_user_id",  "sf_hmac"),
    ("external_userid_firebase",   "external_user_id",  "firebase_hmac"),
    ("clean_phone",                "phone",             "phone_hmac"),
])

TOKEN_PREFIX = {"email": "eml_", "myq_user_id": "usr_", "external_user_id": "xui_", "phone": "phn_"}

# One key per person, and a source row carrying no usable identifier is dropped. The rows
# are not collapsed per key: the source hands the same person back once per phone row, and
# dropping an arbitrary copy loses the phone the other copy carries. Duplicates are handled
# where the IDR handles them, on the identifier itself - the (identifier_type, HMAC) dedup
# below leaves one row per identifier, whichever copies it arrived on.
df_persons = (
    df_hmacs
    .withColumn(
        "person_key",
        F.coalesce("anchor_hmac", "email_hmac", "sf_hmac", "firebase_hmac"),
    )
    .filter(F.col("person_key").isNotNull())
)

df_real_values = (
    df_persons
    .select(
        F.col("myq_user_id").alias("myq_user_id_val"),
        F.col("email").alias("email_val"),
        F.col("external_userid_salesforce").alias("sf_val"),
        F.col("external_userid_firebase").alias("firebase_val"),
        F.col("clean_phone").alias("phone_val"),
        "anchor_hmac", "email_hmac", "sf_hmac", "firebase_hmac", "phone_hmac",
    )
    .select(
        F.array(
            F.struct(F.col("anchor_hmac").alias("hmac"),   F.lit("myq_user_id").alias("identifier_type"),      F.col("myq_user_id_val").alias("real_value")),
            F.struct(F.col("email_hmac").alias("hmac"),    F.lit("email").alias("identifier_type"),             F.col("email_val").alias("real_value")),
            F.struct(F.col("sf_hmac").alias("hmac"),       F.lit("external_user_id").alias("identifier_type"), F.col("sf_val").alias("real_value")),
            F.struct(F.col("firebase_hmac").alias("hmac"), F.lit("external_user_id").alias("identifier_type"), F.col("firebase_val").alias("real_value")),
            F.struct(F.col("phone_hmac").alias("hmac"),    F.lit("phone").alias("identifier_type"),            F.col("phone_val").alias("real_value")),
        ).alias("pairs")
    )
    .select(F.explode("pairs").alias("p"))
    .select(
        F.col("p.hmac").alias("identifier_hmac_value"),
        F.col("p.identifier_type"),
        normalize_real_value(F.col("p.identifier_type"), F.col("p.real_value")).alias("real_value"),
    )
    .filter(
        F.col("identifier_hmac_value").isNotNull()
        & F.col("real_value").isNotNull()
        & (F.col("real_value") != "")
    )
    .dropDuplicates(["identifier_type", "identifier_hmac_value"])
)

df_stage_spark = generate_token(TOKEN_PREFIX, df_real_values)

rows_with_tokens = df_stage_spark.count()

log_checkpoint("user tokens generated")

load_uc_to_lakebase(
    "df_stage_spark",
    VAULT_STAGE,
    source_df=df_stage_spark.select(["identifier_type", "real_value", "identifier_hmac_value", "token"]),
    mode="truncate",
    statement_timeout_ms=TIMEOUT_MS,
)

ptk_execute(f"""
    INSERT INTO cg_vault.vault_email
        (canonical_internal_id, identifier_type, real_value, token,
         source_system, match_method, match_confidence, dsar_request_id, audit_id)
    SELECT DISTINCT
        ui.canonical_user_id::UUID, 'email', vs.real_value, vs.token,
        NULL, 'Deterministic', NULL::NUMERIC, NULL::UUID, NULL::BIGINT
    FROM {VAULT_STAGE} vs
    JOIN cg_identity.user_identifier ui
      ON ui.identifier_value_hmac = vs.identifier_hmac_value
     AND ui.identifier_type       = vs.identifier_type
     AND ui.deletion_status       = 'active'
    WHERE vs.identifier_type = 'email'
    ON CONFLICT DO NOTHING
""")

ptk_execute(f"""
    INSERT INTO cg_vault.vault_phone
        (canonical_internal_id, identifier_type, real_value, token,
         source_system, match_method, match_confidence, dsar_request_id, audit_id)
    SELECT DISTINCT
        ui.canonical_user_id::UUID, 'phone', vs.real_value, vs.token,
        NULL, 'Deterministic', NULL::NUMERIC, NULL::UUID, NULL::BIGINT
    FROM {VAULT_STAGE} vs
    JOIN cg_identity.user_identifier ui
      ON ui.identifier_value_hmac = vs.identifier_hmac_value
     AND ui.identifier_type       = vs.identifier_type
     AND ui.deletion_status       = 'active'
    WHERE vs.identifier_type = 'phone'
    ON CONFLICT DO NOTHING
""")

ptk_execute(f"""
    INSERT INTO cg_vault.vault_myq_user_id
        (canonical_internal_id, identifier_type, real_value, token,
         source_system, match_method, match_confidence, dsar_request_id, audit_id)
    SELECT DISTINCT
        ui.canonical_user_id::UUID, 'myq_user_id', vs.real_value, vs.token,
        NULL, 'Deterministic', NULL::NUMERIC, NULL::UUID, NULL::BIGINT
    FROM {VAULT_STAGE} vs
    JOIN cg_identity.user_identifier ui
      ON ui.identifier_value_hmac = vs.identifier_hmac_value
     AND ui.identifier_type       = vs.identifier_type
     AND ui.deletion_status       = 'active'
    WHERE vs.identifier_type = 'myq_user_id'
    ON CONFLICT DO NOTHING
""")

ptk_execute(f"""
    INSERT INTO cg_vault.vault_external_user_id
        (canonical_internal_id, identifier_type, real_value, token,
         source_system, match_method, match_confidence, dsar_request_id, audit_id)
    SELECT DISTINCT
        ui.canonical_user_id::UUID, 'external_user_id', vs.real_value, vs.token,
        NULL, 'Deterministic', NULL::NUMERIC, NULL::UUID, NULL::BIGINT
    FROM {VAULT_STAGE} vs
    JOIN cg_identity.user_identifier ui
      ON ui.identifier_value_hmac = vs.identifier_hmac_value
     AND ui.identifier_type       = vs.identifier_type
     AND ui.deletion_status       = 'active'
    WHERE vs.identifier_type = 'external_user_id'
    ON CONFLICT DO NOTHING
""")

df_hmacs_accounts = add_hmacs(df_account_users, [
    ("account_id", "account_id", "account_id_hmac"),
])

df_acct_real_values = (
    df_hmacs_accounts
    .select(
        F.col("account_id_hmac").alias("identifier_hmac_value"),
        normalize_real_value(F.lit("account_id"), F.col("account_id")).alias("real_value"),
    )
    .filter(F.col("real_value").isNotNull() & (F.col("real_value") != ""))
    .withColumn("identifier_type", F.lit("account_id"))
    .dropDuplicates(["identifier_type", "identifier_hmac_value"])
)

df_acct_stage_spark = generate_token({"account_id": "acc_"}, df_acct_real_values)

log_checkpoint("account_id tokens generated")

rows_with_tokens_acct = df_acct_stage_spark.count()

load_uc_to_lakebase(
    "df_acct_stage_spark",
    VAULT_STAGE,
    source_df=df_acct_stage_spark.select(["identifier_type", "real_value", "identifier_hmac_value", "token"]),
    mode="truncate",
    statement_timeout_ms=TIMEOUT_MS,
)

ptk_execute(f"""
    INSERT INTO cg_vault.vault_account_id
        (canonical_internal_id, identifier_type, real_value, token,
         source_system, match_method, match_confidence, dsar_request_id, audit_id)
    SELECT DISTINCT
        ai.canonical_account_id::UUID, 'account_id', vs.real_value, vs.token,
        NULL, 'Deterministic', NULL::NUMERIC, NULL::UUID, NULL::BIGINT
    FROM {VAULT_STAGE} vs
    JOIN cg_identity.account_identifier ai
      ON ai.identifier_value_hmac = vs.identifier_hmac_value
     AND ai.identifier_type       = 'account_id'
     AND ai.deletion_status       = 'active'
    ON CONFLICT DO NOTHING
""")