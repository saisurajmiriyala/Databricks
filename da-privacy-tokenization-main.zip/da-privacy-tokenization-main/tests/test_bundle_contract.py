"""Contract tests for the Databricks Asset Bundle CI/CD scaffold."""

from pathlib import Path
import os
import re
import subprocess


ROOT = Path(__file__).resolve().parents[1]

CHAMBERLAIN_EMAIL_RE = re.compile(r"@chamberlain(?:group)?\.com$", re.IGNORECASE)
CLAUDE_COAUTHOR_RE = re.compile(r"co-authored-by:.*claude", re.IGNORECASE)


def commit_range():
    base = os.environ.get("BUNDLE_CONTRACT_BASE_SHA", "origin/main")
    head = os.environ.get("BUNDLE_CONTRACT_HEAD_SHA", "HEAD")
    try:
        merge_base = subprocess.run(
            ["git", "merge-base", base, head],
            capture_output=True, text=True, cwd=ROOT, check=True,
        ).stdout.strip()
        if merge_base:
            return f"{merge_base}..{head}"
    except subprocess.CalledProcessError:
        pass
    return f"{base}..{head}"


def assert_range_is_non_empty(commit_range_):
    """Fail loudly if the range has no commits, so the checks can't no-op silently."""
    result = subprocess.run(
        ["git", "log", "--format=%H", commit_range_],
        capture_output=True, text=True, cwd=ROOT, check=True,
    )
    shas = [s for s in result.stdout.splitlines() if s.strip()]
    assert shas, (
        f"Commit range {commit_range_!r} resolved to zero commits; the contract "
        f"checks would pass without validating anything. Verify "
        f"BUNDLE_CONTRACT_BASE_SHA / BUNDLE_CONTRACT_HEAD_SHA."
    )


def test_git_author_emails_are_chamberlain():
    """Ensure every commit in this PR branch comes from a chamberlain email."""
    commit_range_ = commit_range()
    assert_range_is_non_empty(commit_range_)
    result = subprocess.run(
        ["git", "log", "--format=%ae", commit_range_],
        capture_output=True, text=True, cwd=ROOT, check=True,
    )
    emails = [e.strip() for e in result.stdout.splitlines() if e.strip()]
    for email in emails:
        assert CHAMBERLAIN_EMAIL_RE.search(email), (
            f"Commit authored by non-chamberlain email: {email}"
        )


def test_no_claude_coauthor_trailer_in_commits():
    """Ensure no Claude co-author trailer exists in any PR commit message."""
    commit_range_ = commit_range()
    assert_range_is_non_empty(commit_range_)
    result = subprocess.run(
        ["git", "log", "--format=%B", commit_range_],
        capture_output=True, text=True, cwd=ROOT, check=True,
    )
    assert not CLAUDE_COAUTHOR_RE.search(result.stdout), (
        "Found a Claude co-author trailer in PR commit history"
    )
